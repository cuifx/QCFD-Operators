"""
Second-order minmod+Rusanov scheme for the Lax shock tube, with the
minmod limiter and the Rusanov flux evaluated either by the fixed-point
emulation or by the pyqpanda circuits in quantum_circuits.py
(USE_REAL_CIRCUITS).  Compares classical second order, quantum second
order, and the exact solution.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from scipy.optimize import fsolve
import math
import time

import quantum_circuits as qc

matplotlib.use('Agg')

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# True: the quantum operator interfaces below route through the real
#       pyqpanda circuits in quantum_circuits.py (gate-level, slow).
# False: fixed-point classical emulation of the same circuits (fast;
#        verified against the circuits at low bit widths).
USE_REAL_CIRCUITS = False

# ============================================================
# Lax problem: exact solution
# ============================================================
# left state (0.445, 0.698, 3.528), right state (0.5, 0, 0.571)

GAMMA = 1.4

def lax_exact_solution(x, t, gamma=GAMMA):
    """Lax shock-tube exact solution using Newton-Raphson for p_star."""
    rhoL, uL, pL = 0.445, 0.698, 3.528
    rhoR, uR, pR = 0.5, 0.0, 0.571
    aL = np.sqrt(gamma * pL / rhoL)
    aR = np.sqrt(gamma * pR / rhoR)

    # Newton-Raphson for p_star
    AL = 2.0 / ((gamma + 1.0) * rhoL)
    AR = 2.0 / ((gamma + 1.0) * rhoR)
    BL = (gamma - 1.0) / (gamma + 1.0) * pL
    BR = (gamma - 1.0) / (gamma + 1.0) * pR

    p0 = 0.5 * (pL + pR)
    for _ in range(100):
        # f_L(p)
        if p0 > pL:  # shock
            fL = (p0 - pL) * np.sqrt(AL / (p0 + BL))
        else:  # rarefaction
            fL = 2.0 * aL / (gamma - 1.0) * ((p0 / pL)**((gamma - 1.0) / (2.0 * gamma)) - 1.0)
        # f_R(p)
        if p0 > pR:  # shock
            fR = (p0 - pR) * np.sqrt(AR / (p0 + BR))
        else:  # rarefaction
            fR = 2.0 * aR / (gamma - 1.0) * ((p0 / pR)**((gamma - 1.0) / (2.0 * gamma)) - 1.0)

        f = fL + fR + uR - uL

        # df/dp
        if p0 > pL:
            dfL = np.sqrt(AL / (p0 + BL)) * (1.0 - 0.5 * (p0 - pL) / (p0 + BL))
        else:
            dfL = 1.0 / (rhoL * aL) * (p0 / pL)**(-(gamma + 1.0) / (2.0 * gamma))
        if p0 > pR:
            dfR = np.sqrt(AR / (p0 + BR)) * (1.0 - 0.5 * (p0 - pR) / (p0 + BR))
        else:
            dfR = 1.0 / (rhoR * aR) * (p0 / pR)**(-(gamma + 1.0) / (2.0 * gamma))

        dp = -f / (dfL + dfR)
        p0 += dp
        if abs(dp) < 1e-12:
            break

    p_star = p0
    u_star = uL - fL

    # Post-shock/post-rarefaction densities
    if p_star > pL:  # left shock
        rhoL_star = rhoL * (p_star / pL + (gamma - 1.0) / (gamma + 1.0)) / \
                    ((gamma - 1.0) / (gamma + 1.0) * p_star / pL + 1.0)
    else:  # left rarefaction
        rhoL_star = rhoL * (p_star / pL)**(1.0 / gamma)

    if p_star > pR:  # right shock
        rhoR_star = rhoR * (p_star / pR + (gamma - 1.0) / (gamma + 1.0)) / \
                    ((gamma - 1.0) / (gamma + 1.0) * p_star / pR + 1.0)
    else:  # right rarefaction
        rhoR_star = rhoR * (p_star / pR)**(1.0 / gamma)

    aL_star = np.sqrt(gamma * p_star / rhoL_star)
    aR_star = np.sqrt(gamma * p_star / rhoR_star)

    # Wave speeds
    if p_star > pL:  # left shock
        S_L = uL - aL * np.sqrt((gamma + 1.0) / (2.0 * gamma) * p_star / pL + (gamma - 1.0) / (2.0 * gamma))
    else:
        S_L = uL - aL

    if p_star > pR:  # right shock
        S_R = uR + aR * np.sqrt((gamma + 1.0) / (2.0 * gamma) * p_star / pR + (gamma - 1.0) / (2.0 * gamma))
    else:
        S_R = uR + aR

    # Wave positions (centered at x=0.5)
    x_origin = 0.5
    if p_star > pL:
        x_shock_L = x_origin + S_L * t
        x_tail = x_shock_L
        x_head = x_origin + (uL - aL) * t
    else:
        x_head = x_origin + (uL - aL) * t
        x_tail = x_origin + (u_star - aL_star) * t

    x_contact = x_origin + u_star * t

    if p_star > pR:
        x_shock_R = x_origin + S_R * t
    else:
        x_shock_R = x_origin + (uR + aR) * t

    # Evaluate solution
    rho = np.zeros_like(x)
    u = np.zeros_like(x)
    p = np.zeros_like(x)

    for i, xi in enumerate(x):
        if xi <= x_head:
            # Left undisturbed
            rho[i], u[i], p[i] = rhoL, uL, pL
        elif xi <= x_tail:
            # Left rarefaction fan
            if p_star > pL:  # left shock — no fan
                rho[i], u[i], p[i] = rhoL, uL, pL
            else:
                # rarefaction fan from the Riemann invariants
                # → u = 2/(γ+1)*(aL + (x-x0)/t) + (γ-1)/(γ+1)*uL
                # → c = aL + (γ-1)/2*(uL - u)
                u_val = (2.0/(gamma+1.0))*(aL + (xi-x_origin)/t) + \
                        ((gamma-1.0)/(gamma+1.0))*uL
                a_val = aL + 0.5*(gamma-1.0)*(uL - u_val)
                rho[i] = rhoL * (a_val / aL)**(2.0/(gamma-1.0))
                p[i] = pL * (rho[i]/rhoL)**gamma
                u[i] = u_val
        elif xi <= x_contact:
            # Left star region
            rho[i], u[i], p[i] = rhoL_star, u_star, p_star
        elif xi <= x_shock_R:
            # Right star region
            rho[i], u[i], p[i] = rhoR_star, u_star, p_star
        else:
            # Right undisturbed
            rho[i], u[i], p[i] = rhoR, uR, pR

    return rho, u, p


# ============================================================
# Quantum minmod interface
# ============================================================

def preprocess_numbers(a, b, n_bits):
    """Scale floats into the n-bit signed integer range."""
    max_val = max(abs(a), abs(b))
    if max_val == 0:
        return 0, 0, 1.0

    max_integer = (1 << n_bits) - 1
    F = max_integer / max_val

    A = round(a * F)
    B = round(b * F)
    A_clamped = min(max(A, -max_integer), max_integer)
    B_clamped = min(max(B, -max_integer), max_integer)

    return A_clamped, B_clamped, F


def quantum_minmod_sim(a, b, n_bits=7):
    """Minmod through the real circuit (USE_REAL_CIRCUITS) or the
    fixed-point emulation; the two agree at low bit widths."""
    if USE_REAL_CIRCUITS:
        return qc.quantum_minmod(a, b, bit_num=n_bits)

    if a * b <= 0:
        return 0.0

    sign = np.sign(a)
    abs_a = abs(a)
    abs_b = abs(b)

    A_clamped, B_clamped, F = preprocess_numbers(abs_a, abs_b, n_bits)

    # min of the magnitudes
    min_val = min(A_clamped, B_clamped)

    result = sign * min_val / F
    return result


# Vector wrapper
def quantum_minmod_ip_vec(a_arr, b_arr, n_bits=7):
    """Vectorized quantum minmod over arrays of slopes."""
    c = np.zeros(len(a_arr))
    for i in range(len(a_arr)):
        c[i] = quantum_minmod_sim(a_arr[i], b_arr[i], n_bits)
    return c


# ============================================================
# Classical minmod
# ============================================================

def classical_minmod(a, b):
    """full-precision classical minmod."""
    if a * b <= 0:
        return 0.0
    return a if abs(a) < abs(b) else b


# ============================================================
# Quantum Rusanov flux interface
# ============================================================

def compute_rusanov_intermediates(UL, UR, gamma=GAMMA):
    """Euler fluxes and the maximal wave speed from conservative vars."""
    rhoL = max(UL[0], 1e-12)
    uL = UL[1] / rhoL
    eL = max(UL[2] - 0.5 * rhoL * uL**2, 1e-12) / rhoL
    pL = (gamma - 1.0) * rhoL * eL
    cL = np.sqrt(gamma * pL / rhoL)

    rhoR = max(UR[0], 1e-12)
    uR = UR[1] / rhoR
    eR = max(UR[2] - 0.5 * rhoR * uR**2, 1e-12) / rhoR
    pR = (gamma - 1.0) * rhoR * eR
    cR = np.sqrt(gamma * pR / rhoR)

    FL = np.array([rhoL * uL, rhoL * uL**2 + pL, uL * (UL[2] + pL)])
    FR = np.array([rhoR * uR, rhoR * uR**2 + pR, uR * (UR[2] + pR)])
    Smax = max(abs(uL) + cL, abs(uR) + cR)

    return FL, FR, Smax


def quantum_rusanov_flux_component(FL_k, FR_k, UL_k, UR_k, Smax, n_bits=8):
    """One flux component through the real circuit (USE_REAL_CIRCUITS)
    or the fixed-point emulation, from the same quantized integers."""
    if n_bits is None:
        return 0.5 * (FL_k + FR_k) - 0.5 * Smax * (UR_k - UL_k)

    max_abs = max(abs(FL_k), abs(FR_k), abs(UL_k), abs(UR_k), abs(Smax), 1e-12)
    int_max = 2**(n_bits - 1) - 1
    safe_max = int_max // 2              # headroom for fl + fr
    scale = safe_max / max_abs

    def to_int(x):
        return int(np.round(x * scale))

    def clamp(x):
        return max(min(x, int_max), -int_max)

    def from_int(x):
        return x / scale

    fl = clamp(to_int(FL_k))
    fr = clamp(to_int(FR_k))
    ul = clamp(to_int(UL_k))
    ur = clamp(to_int(UR_k))
    SM_FRAC_BITS = 0
    sm = int(np.round(Smax * (1 << SM_FRAC_BITS)))

    if USE_REAL_CIRCUITS:
        # real circuit interface
        return qc.quantum_rusanov(fl, fr, ul, ur, sm, n_bits) / scale

    # Step 1: FL + FR (safe within int_max due to safe_max)
    s1 = clamp(fl + fr)

    # Step 2: UR - UL
    d_raw = ur - ul
    d_neg = (d_raw < 0)
    d_mag = clamp(abs(d_raw))

    # Step 3: Smax * |UR-UL|
    raw_prod = sm * d_mag
    p_mag = clamp(raw_prod >> SM_FRAC_BITS)

    # division by two, truncated toward zero
    h1 = int(s1 / 2)
    h2 = int(p_mag / 2)

    # combine
    if d_neg:
        result_int = clamp(h1 + h2)
    else:
        result_int = clamp(h1 - h2)

    return from_int(result_int)


def quantum_rusanov_flux_reduced(FL, FR, UL, UR, Smax, n_bits=8):
    """Reduced-input Rusanov flux, component-wise."""
    F_quantum = np.zeros(3)
    for k in range(3):
        F_quantum[k] = quantum_rusanov_flux_component(
            FL[k], FR[k], UL[k], UR[k], Smax, n_bits
        )
    return F_quantum


# ============================================================
# Euler solver with switchable operators
# ============================================================

class EulerSolver:
    """1D Euler solver with switchable limiter and flux."""

    def __init__(self, gamma=GAMMA, small_rho=1e-12, small_p=1e-12):
        self.gamma = gamma
        self.small_rho = small_rho
        self.small_p = small_p
        self.step_count = 0

    def conserved_to_primitive(self, U):
        rho = max(U[0], self.small_rho)
        u = U[1] / rho
        k = 0.5 * rho * u**2
        e = max(U[2] - k, 1e-12) / rho
        p = (self.gamma - 1.0) * rho * e
        p = max(p, self.small_p)
        return rho, u, p

    def primitive_to_conserved(self, rho, u, p):
        rho = max(rho, self.small_rho)
        p = max(p, self.small_p)
        e = p / ((self.gamma - 1.0) * rho)
        E = rho * (e + 0.5 * u**2)
        return np.array([rho, rho * u, E])

    def flux(self, U):
        rho, u, p = self.conserved_to_primitive(U)
        mom = rho * u
        E = U[2]
        return np.array([mom, mom * u + p, u * (E + p)])

    def rusanov_flux(self, UL, UR):
        FL = self.flux(UL)
        FR = self.flux(UR)
        rhoL, uL, pL = self.conserved_to_primitive(UL)
        rhoR, uR, pR = self.conserved_to_primitive(UR)
        cL = np.sqrt(self.gamma * pL / rhoL)
        cR = np.sqrt(self.gamma * pR / rhoR)
        Smax = max(abs(uL) + cL, abs(uR) + cR)
        return 0.5 * (FL + FR) - 0.5 * Smax * (UR - UL)

    def minmod(self, a, b):
        """classical minmod."""
        if a * b <= 0:
            return 0.0
        return a if abs(a) < abs(b) else b

    def reconstruct(self, U_im1, U_i, U_ip1, U_ip2, minmod_func=None):
        """MUSCL reconstruction at the i+1/2 interface: left state from
        the slope of cell i, right state from the slope of cell i+1."""
        if minmod_func is None:
            minmod_func = self.minmod

        rho_im1, u_im1, p_im1 = self.conserved_to_primitive(U_im1)
        rho_i,   u_i,   p_i   = self.conserved_to_primitive(U_i)
        rho_ip1, u_ip1, p_ip1 = self.conserved_to_primitive(U_ip1)
        rho_ip2, u_ip2, p_ip2 = self.conserved_to_primitive(U_ip2)

        # slope of cell i
        drho_i = minmod_func(rho_i - rho_im1, rho_ip1 - rho_i)
        du_i   = minmod_func(u_i   - u_im1,   u_ip1   - u_i)
        dp_i   = minmod_func(p_i   - p_im1,   p_ip1   - p_i)

        # slope of cell i+1
        drho_ip1 = minmod_func(rho_ip1 - rho_i, rho_ip2 - rho_ip1)
        du_ip1   = minmod_func(u_ip1   - u_i,   u_ip2   - u_ip1)
        dp_ip1   = minmod_func(p_ip1   - p_i,   p_ip2   - p_ip1)

        # interface values
        rhoL = rho_i   + 0.5 * drho_i
        uL   = u_i     + 0.5 * du_i
        pL   = p_i     + 0.5 * dp_i
        rhoR = rho_ip1 - 0.5 * drho_ip1
        uR   = u_ip1   - 0.5 * du_ip1
        pR   = p_ip1   - 0.5 * dp_ip1

        UL = self.primitive_to_conserved(rhoL, uL, pL)
        UR = self.primitive_to_conserved(rhoR, uR, pR)
        return UL, UR

    def apply_bc(self, U):
        """Zero-order extrapolation (transmissive) boundaries."""
        nx = U.shape[1]
        U_bc = np.zeros((3, nx + 2))
        U_bc[:, 1:-1] = U
        U_bc[:, 0] = U_bc[:, 1]
        U_bc[:, -1] = U_bc[:, -2]
        return U_bc

    def compute_dt(self, U, dx, CFL):
        max_lambda = 0.0
        for i in range(U.shape[1]):
            rho, u, p = self.conserved_to_primitive(U[:, i])
            c = np.sqrt(self.gamma * p / rho)
            max_lambda = max(max_lambda, abs(u) + c)
        if max_lambda < 1e-12:
            max_lambda = 1e-12
        return CFL * dx / max_lambda



    def solve_classical_1st(self, x, U0, t_final, CFL=0.5):
        """Classical first-order Rusanov."""
        return self._solve_generic(x, U0, t_final, CFL,
                                   order=1, use_quantum_minmod=False,
                                   use_quantum_flux=False)

    def solve_classical_2nd(self, x, U0, t_final, CFL=0.5,
                            minmod_func=None):
        """Classical second-order minmod+Rusanov."""
        if minmod_func is None:
            minmod_func = self.minmod
        return self._solve_generic(x, U0, t_final, CFL,
                                   order=2, use_quantum_minmod=False,
                                   use_quantum_flux=False,
                                   minmod_func=minmod_func)

    def solve_quantum_hybrid(self, x, U0, t_final, CFL=0.5,
                             minmod_n_bits=7, flux_n_bits=8):
        """Second-order scheme with both operators from the quantum
        interfaces."""
        def q_minmod(a, b):
            return quantum_minmod_sim(a, b, n_bits=minmod_n_bits)

        return self._solve_generic(x, U0, t_final, CFL,
                                   order=2, use_quantum_minmod=True,
                                   use_quantum_flux=True,
                                   minmod_func=q_minmod,
                                   minmod_n_bits=minmod_n_bits,
                                   flux_n_bits=flux_n_bits)

    def _solve_generic(self, x, U0, t_final, CFL,
                       order=1, use_quantum_minmod=False,
                       use_quantum_flux=False,
                       minmod_func=None, minmod_n_bits=7,
                       flux_n_bits=8):
        """Generic time-stepping loop."""
        nx = len(x)
        dx = x[1] - x[0]
        U = U0.copy()
        t = 0.0
        self.step_count = 0

        while t < t_final:
            dt = self.compute_dt(U, dx, CFL)
            if t + dt > t_final:
                dt = t_final - t

            U_bc = self.apply_bc(U)
            F_half = np.zeros((3, nx + 1))

            for i in range(nx + 1):
                if order == 1 or i == 0 or i == nx:
                    UL = U_bc[:, i]
                    UR = U_bc[:, i + 1]
                else:
                    UL, UR = self.reconstruct(
                        U_bc[:, i - 1], U_bc[:, i], U_bc[:, i + 1], U_bc[:, i + 2],
                        minmod_func=minmod_func
                    )

                if use_quantum_flux:
                    FL, FR, Smax = compute_rusanov_intermediates(UL, UR, self.gamma)
                    F_half[:, i] = quantum_rusanov_flux_reduced(
                        FL, FR, UL, UR, Smax, n_bits=flux_n_bits
                    )
                else:
                    F_half[:, i] = self.rusanov_flux(UL, UR)

            for i in range(nx):
                U[:, i] -= (dt / dx) * (F_half[:, i + 1] - F_half[:, i])

            t += dt
            self.step_count += 1

        return U


# ============================================================
# Error norms
# ============================================================

def compute_errors(x_num, rho_num, x_exact, rho_exact):
    rho_exact_interp = np.interp(x_num, x_exact, rho_exact)
    err_abs = np.abs(rho_num - rho_exact_interp)
    l1_err = np.sum(err_abs) / len(x_num)
    l2_err = np.sqrt(np.sum(err_abs**2) / len(x_num))
    return l1_err, l2_err


# ============================================================

# ============================================================

if __name__ == "__main__":
    t_start = time.time()

    N = 400
    x = np.linspace(0.5 / N, 1 - 0.5 / N, N)
    t_out = 0.1
    CFL = 0.3

    rhoL, uL, pL = 0.445, 0.698, 3.528
    rhoR, uR, pR = 0.5, 0.0, 0.571

    rho_init = np.where(x < 0.5, rhoL, rhoR)
    u_init   = np.where(x < 0.5, uL,   uR)
    p_init   = np.where(x < 0.5, pL,   pR)

    solver = EulerSolver()
    U0 = np.zeros((3, N))
    for i in range(N):
        U0[:, i] = solver.primitive_to_conserved(rho_init[i], u_init[i], p_init[i])

    # 1) classical first-order Rusanov
    print("=" * 60)
    print("Lax Shock-Tube — Hybrid Quantum Classical CFD")
    print("=" * 60)
    print("\n[1/4] Running classical 1st-order Rusanov...")
    U_cl1 = solver.solve_classical_1st(x, U0.copy(), t_out, CFL=CFL)
    rho_cl1 = np.array([solver.conserved_to_primitive(U_cl1[:, i])[0] for i in range(N)])
    u_cl1   = np.array([solver.conserved_to_primitive(U_cl1[:, i])[1] for i in range(N)])
    p_cl1   = np.array([solver.conserved_to_primitive(U_cl1[:, i])[2] for i in range(N)])
    steps_cl1 = solver.step_count
    print(f"  Done. Steps: {steps_cl1}")

    # 2) classical second-order minmod+Rusanov
    print("\n[2/4] Running classical 2nd-order Minmod+Rusanov...")
    U_cl2 = solver.solve_classical_2nd(x, U0.copy(), t_out, CFL=CFL)
    rho_cl2 = np.array([solver.conserved_to_primitive(U_cl2[:, i])[0] for i in range(N)])
    u_cl2   = np.array([solver.conserved_to_primitive(U_cl2[:, i])[1] for i in range(N)])
    p_cl2   = np.array([solver.conserved_to_primitive(U_cl2[:, i])[2] for i in range(N)])
    steps_cl2 = solver.step_count
    print(f"  Done. Steps: {steps_cl2}")

    # 3) quantum hybrid: minmod 7-bit + Rusanov 9-bit
    print("\n[3/4] Running quantum hybrid 2nd-order (minmod 7-bit, Rusanov 9-bit)...")
    U_q2 = solver.solve_quantum_hybrid(x, U0.copy(), t_out, CFL=CFL,
                                       minmod_n_bits=7, flux_n_bits=9)
    rho_q2 = np.array([solver.conserved_to_primitive(U_q2[:, i])[0] for i in range(N)])
    u_q2   = np.array([solver.conserved_to_primitive(U_q2[:, i])[1] for i in range(N)])
    p_q2   = np.array([solver.conserved_to_primitive(U_q2[:, i])[2] for i in range(N)])
    steps_q2 = solver.step_count
    print(f"  Done. Steps: {steps_q2}")

    # 4) exact solution
    print("\n[4/4] Computing exact Lax solution...")
    x_exact = np.linspace(0, 1, 5000)
    rho_exact, u_exact, p_exact = lax_exact_solution(x_exact, t_out)
    print("  Done.")

    # error norms
    l1_cl1, l2_cl1 = compute_errors(x, rho_cl1, x_exact, rho_exact)
    l1_cl2, l2_cl2 = compute_errors(x, rho_cl2, x_exact, rho_exact)
    l1_q2,  l2_q2  = compute_errors(x, rho_q2,  x_exact, rho_exact)

    print("\n" + "=" * 60)
    print("Error Analysis (Density)")
    print("=" * 60)
    print(f"  Classical 1st-order:  L1 = {l1_cl1:.4e}  L2 = {l2_cl1:.4e}  Steps = {steps_cl1}")
    print(f"  Classical 2nd-order:  L1 = {l1_cl2:.4e}  L2 = {l2_cl2:.4e}  Steps = {steps_cl2}")
    print(f"  Quantum 2nd-order:    L1 = {l1_q2:.4e}  L2 = {l2_q2:.4e}  Steps = {steps_q2}")

    # Also write to file for safe keeping
    with open(f'errors_N{N}.txt', 'w') as f:
        f.write(f"N = {N}, CFL = {CFL}, t_out = {t_out}\n")
        f.write(f"Classical 1st-order:  L1 = {l1_cl1:.4e}  L2 = {l2_cl1:.4e}  Steps = {steps_cl1}\n")
        f.write(f"Classical 2nd-order:  L1 = {l1_cl2:.4e}  L2 = {l2_cl2:.4e}  Steps = {steps_cl2}\n")
        f.write(f"Quantum 2nd-order:    L1 = {l1_q2:.4e}  L2 = {l2_q2:.4e}  Steps = {steps_q2}\n")

    # figure
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    vars_data = [
        ('Density', r'$\rho$', rho_exact, rho_cl2, rho_q2),
        ('Velocity', '$u$',   u_exact,   u_cl2,   u_q2),
        ('Pressure', '$p$',   p_exact,   p_cl2,   p_q2),
    ]

    for idx, (ax, (title, ylabel, exact, cl2, q2)) in enumerate(zip(axes, vars_data)):
        ax.plot(x_exact, exact, 'k-',  linewidth=2.0, label='Exact')
        ax.plot(x, cl2,        'b--',  linewidth=1.5, label='Cl. 2nd Minmod+Rusanov')
        ax.plot(x, q2,         'gold', linewidth=1.5, linestyle='-.', marker='o',
                markersize=2, markevery=30, alpha=0.8, label='Q. 2nd Minmod+Rusanov')
        ax.set_xlabel('x')
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        if idx == 0:
            ax.legend(fontsize=8, loc='best')
        ax.grid(alpha=0.3)

    plt.subplots_adjust(wspace=0.3, top=0.95)
    filename = f'Joint_LAX_quantum_N{N}.png'
    plt.savefig(filename, dpi=400)
    print(f'\nSaved: {filename}')

    t_end = time.time()
    print(f'\nTotal runtime: {t_end - t_start:.1f} s')
    print('=' * 60)
