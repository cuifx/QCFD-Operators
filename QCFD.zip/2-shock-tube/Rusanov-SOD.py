import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from scipy.optimize import fsolve
from pyqpanda import *
import math
import time

import quantum_circuits as qc

matplotlib.use('Agg')

flag = 0

# True: the quantum Rusanov interface routes through the real circuits
# False: fixed-point emulation (validated against the circuits at low widths)
USE_REAL_CIRCUITS = False

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


# QFT-adder phases
def get_angles(aa, n):

    s = bin(int(aa))[2:].zfill(n)
    angles = np.zeros([n])
    for i in range(0, n):
        for j in range(i, n):
            if s[j] == '1':
                angles[n - i - 1] += math.pow(2, -(j - i))
        angles[n - i - 1] *= np.pi
    return angles



def qu_add(aa, q):
    nn = len(q)
    circ = QCircuit()
    circ << QFT(q)
    angles = get_angles(aa, nn)

    for ii in range(0, nn):
        circ << RZ(q[ii], angles[nn - ii - 1])
    circ << QFT(q).dagger()

    return circ


def sod_exact_solution(x, t, gamma=1.4):
    rhoL, uL, pL = 1.0, 0.0, 1.0
    rhoR, uR, pR = 0.125, 0.0, 0.1

    # standard Sod star-region values
    p_star, u_star = 0.30313, 0.92745
    rhoL_star, rhoR_star = 0.42632, 0.26557

    aL = np.sqrt(gamma * pL / rhoL)
    aR = np.sqrt(gamma * pR / rhoR)
    aL_star = np.sqrt(gamma * p_star / rhoL_star)
    aR_star = np.sqrt(gamma * p_star / rhoR_star)

    # shock speed from the right state and p_star
    S_shock = uR + aR * np.sqrt((gamma + 1) / (2 * gamma) * (p_star / pR - 1) + 1)

    # wave positions, x = 0.5 at the diaphragm
    x_head = 0.5 - aL * t
    x_tail = 0.5 + (u_star - aL_star) * t
    x_contact = 0.5 + u_star * t
    x_shock = 0.5 + S_shock * t

    rho = np.zeros_like(x)
    u = np.zeros_like(x)
    p = np.zeros_like(x)

    for i, xi in enumerate(x):
        if xi <= x_head:  # undisturbed left state
            rho[i], u[i], p[i] = rhoL, uL, pL
        elif xi <= x_tail:  # isentropic rarefaction
            u_val = 2 / (gamma + 1) * (aL + (xi - 0.5) / t)
            a_val = aL - 0.5 * (gamma - 1) * u_val
            rho[i] = rhoL * (a_val / aL) ** (2 / (gamma - 1))
            p[i] = pL * (rho[i] / rhoL) ** gamma
            u[i] = u_val
        elif xi <= x_contact:
            rho[i], u[i], p[i] = rhoL_star, u_star, p_star
        elif xi <= x_shock:
            rho[i], u[i], p[i] = rhoR_star, u_star, p_star
        else:
            rho[i], u[i], p[i] = rhoR, uR, pR

    return rho, u, p


# =========================================================
# Rusanov solver, first or second order
# =========================================================
class RusanovSolver:
    def __init__(self, gamma=1.4, order=1):
        self.gamma = gamma
        self.order = order
        self.small_rho = 1e-12
        self.small_p = 1e-12

    def conserved_to_primitive(self, U):
        rho = max(U[0], self.small_rho)
        u = U[1] / rho
        k = 0.5 * rho * u ** 2
        # E = rho * e + rho * u^2 / 2
        e = max(U[2] - k, 1e-12) / rho
        p = (self.gamma - 1) * rho * e
        p = max(p, self.small_p)
        return rho, u, p

    def primitive_to_conserved(self, rho, u, p):
        rho = max(rho, self.small_rho)
        p = max(p, self.small_p)
        e = p / ((self.gamma - 1) * rho)
        E = rho * (e + 0.5 * u ** 2)
        return np.array([rho, rho * u, E])

    def flux(self, U):
        rho, u, p = self.conserved_to_primitive(U)
        mom = rho * u
        E = U[2]
        return np.array([mom, mom * u + p, u * (E + p)])

    def rusanov_flux(self, UL, UR):
        FL = self.flux(UL)
        FR = self.flux(UR)
        rhoL, uL, pL = self.conserved_to_primitive(UL)
        rhoR, uR, pR = self.conserved_to_primitive(UR)
        cL = np.sqrt(self.gamma * pL / rhoL)
        cR = np.sqrt(self.gamma * pR / rhoR)
        Smax = max(abs(uL) + cL, abs(uR) + cR)

        return 0.5 * (FL + FR) - 0.5 * Smax * (UR - UL)

    def minmod(self, a, b):
        return 0.0 if a * b <= 0 else (a if abs(a) < abs(b) else b)

    def reconstruct(self, U_im1, U_i, U_ip1):
        rho_im1, u_im1, p_im1 = self.conserved_to_primitive(U_im1)
        rho_i, u_i, p_i = self.conserved_to_primitive(U_i)
        rho_ip1, u_ip1, p_ip1 = self.conserved_to_primitive(U_ip1)

        drho = self.minmod(rho_i - rho_im1, rho_ip1 - rho_i)
        du = self.minmod(u_i - u_im1, u_ip1 - u_i)
        dp = self.minmod(p_i - p_im1, p_ip1 - p_i)

        rhoL = rho_i + 0.5 * drho
        uL = u_i + 0.5 * du
        pL = p_i + 0.5 * dp
        rhoR = rho_ip1 - 0.5 * drho
        uR = u_ip1 - 0.5 * du
        pR = p_ip1 - 0.5 * dp

        UL = self.primitive_to_conserved(rhoL, uL, pL)
        UR = self.primitive_to_conserved(rhoR, uR, pR)
        return UL, UR

    def apply_bc(self, U):
        nx = U.shape[1]
        U_bc = np.zeros((3, nx + 2))
        U_bc[:, 1:-1] = U
        U_bc[:, 0] = U_bc[:, 1]
        U_bc[:, -1] = U_bc[:, -2]
        return U_bc

    def compute_dt(self, U, dx, CFL):
        max_lambda = 0.0
        for i in range(U.shape[1]):
            rho, u, p = self.conserved_to_primitive(U[:, i])
            c = np.sqrt(self.gamma * p / rho)
            max_lambda = max(max_lambda, abs(u) + c)
        if max_lambda < 1e-12:
            max_lambda = 1e-12
        return CFL * dx / max_lambda

    def solve(self, x, U0, t_final, CFL=0.5):
        nx = len(x)
        dx = x[1] - x[0]
        U = U0.copy()
        t = 0.0
        step = 0

        while t < t_final:
            dt = self.compute_dt(U, dx, CFL)
            if t + dt > t_final:
                dt = t_final - t

            U_bc = self.apply_bc(U)
            F_half = np.zeros((3, nx + 1))

            for i in range(nx + 1):
                if self.order == 1 or i == 0 or i == nx:
                    UL = U_bc[:, i]
                    UR = U_bc[:, i + 1]
                else:
                    UL, UR = self.reconstruct(U_bc[:, i - 1], U_bc[:, i], U_bc[:, i + 1])
                F_half[:, i] = self.rusanov_flux(UL, UR)

            for i in range(nx):
                U[:, i] -= (dt / dx) * (F_half[:, i + 1] - F_half[:, i])

            t += dt
            step += 1

        print(f'  Classical steps: {step}')
        return U

    def solve_with_quantum_flux(self, x, U0, t_final, n_bits=6, CFL=0.5):
        nx = len(x)
        dx = x[1] - x[0]
        U = U0.copy()
        t = 0.0
        step = 0

        while t < t_final:
            dt = self.compute_dt(U, dx, CFL)
            if t + dt > t_final:
                dt = t_final - t

            U_bc = self.apply_bc(U)
            F_half = np.zeros((3, nx + 1))

            for i in range(nx + 1):
                if self.order == 1 or i == 0 or i == nx:
                    UL = U_bc[:, i]
                    UR = U_bc[:, i + 1]
                else:
                    UL, UR = self.reconstruct(U_bc[:, i - 1], U_bc[:, i], U_bc[:, i + 1])
                FL, FR, Smax = compute_rusanov_intermediates(UL, UR, self.gamma)
                F_half[:, i] = quantum_rusanov_flux_reduced(
                    FL, FR, UL, UR, Smax, n_bits
                )

            for i in range(nx):
                U[:, i] -= (dt / dx) * (F_half[:, i + 1] - F_half[:, i])

            t += dt
            step += 1

        print(f'    Quantum steps: {step}')
        return U


# =========================================================
# Errors
# =========================================================
def compute_errors(x_num, rho_num, x_exact, rho_exact):
    rho_exact_interp = np.interp(x_num, x_exact, rho_exact)
    err_abs = np.abs(rho_num - rho_exact_interp)
    l1_err = np.sum(err_abs) / len(x_num)
    l2_err = np.sqrt(np.sum(err_abs**2) / len(x_num))
    return l1_err, l2_err

# =========================================================
# Quantum interface: reduced-input architecture.  The classical front
# end precomputes FL, FR and Smax; the circuit evaluates the core flux
# formula only (Fig. 11 of Cui et al., Sci. China-PMA 2026).
# =========================================================


def compute_rusanov_intermediates(UL, UR, gamma=1.4):
    """Classical front end: primitives, Euler fluxes and S_max."""
    rhoL = max(UL[0], 1e-12)
    uL = UL[1] / rhoL
    eL = max(UL[2] - 0.5 * rhoL * uL**2, 1e-12) / rhoL
    pL = (gamma - 1) * rhoL * eL
    cL = np.sqrt(gamma * pL / rhoL)

    rhoR = max(UR[0], 1e-12)
    uR = UR[1] / rhoR
    eR = max(UR[2] - 0.5 * rhoR * uR**2, 1e-12) / rhoR
    pR = (gamma - 1) * rhoR * eR
    cR = np.sqrt(gamma * pR / rhoR)

    FL = np.array([rhoL * uL, rhoL * uL**2 + pL, uL * (UL[2] + pL)])
    FR = np.array([rhoR * uR, rhoR * uR**2 + pR, uR * (UR[2] + pR)])
    Smax = max(abs(uL) + cL, abs(uR) + cR)

    return FL, FR, Smax


def quantum_rusanov_flux_component(FL_k, FR_k, UL_k, UR_k, Smax, n_bits=None):
    """One flux component.  n_bits=None: exact arithmetic.  Otherwise
    every operation runs in the n-bit fixed-point space, i.e. register
    truncation after each step, high-n-bit retention for products and
    a right shift for the division by two."""
    if n_bits is None:
        return 0.5 * (FL_k + FR_k) - 0.5 * Smax * (UR_k - UL_k)

    max_abs = max(abs(FL_k), abs(FR_k), abs(UL_k), abs(UR_k),
                  abs(Smax), 1e-12)
    int_max = 2**(n_bits - 1) - 1
    # headroom so that fl+fr and ur-ul do not overflow
    safe_max = int_max // 2
    scale = safe_max / max_abs

    def to_int(x):
        scaled = x * scale
        if abs(scaled) < 1.0:
            return 0
        return int(np.round(scaled))

    def clamp(x):
        return max(min(x, int_max), -int_max)

    def from_int(x):
        return x / scale

    fl = to_int(FL_k)
    fr = to_int(FR_k)
    ul = to_int(UL_k)
    ur = to_int(UR_k)
    SM_FRAC_BITS = 0
    sm = int(np.round(Smax * (1 << SM_FRAC_BITS)))

    if USE_REAL_CIRCUITS:
        # real circuit interface
        return qc.quantum_rusanov(fl, fr, ul, ur, sm, n_bits) / scale

    s1 = clamp(fl + fr)
    d_raw = ur - ul
    d_neg = (d_raw < 0)
    d_mag = clamp(abs(d_raw))

    # p = sm * |d|
    raw_prod = sm * d_mag
    p_mag = clamp(raw_prod >> SM_FRAC_BITS)

    # Step 4: s1 // 2, Step 5: p_mag // 2
    # right shift truncates toward zero
    h1 = int(s1 / 2)
    h2 = int(p_mag / 2)
    
    if d_neg:
        result_int = clamp(h1 + h2)

    else:
        result_int = clamp(h1 - h2)

    # bit_num = n_bits - 1
    # qvm = CPUQVM()
    # qvm.init_qvm(False)
    # prog = QProg()
    # q_f = qvm.qAlloc_many(bit_num)
    # q_u = qvm.qAlloc_many(bit_num)
    # aux0 = qvm.qAlloc_many(bit_num)
    # aux1 = qvm.qAlloc_many(1)
    #
    # prog << bind_nonnegative_data(fr, q_f)
    # prog << qu_add(fl, q_f)
    #
    # prog << bind_nonnegative_data(ur, q_u)
    # prog << bind_nonnegative_data(ul, aux0)
    #
    # if ur < ul:
    #     prog << QAdderIgnoreCarry(aux0, q_u, aux1[0]).dagger()
    #     for i in range(bit_num):
    #         prog << SWAP(aux0[i], q_u[i])
    #     prog << bind_nonnegative_data(ur, aux0)
    # else:
    #     prog << QAdderIgnoreCarry(q_u, aux0, aux1[0]).dagger()
    #     prog << bind_nonnegative_data(ul, aux0)
    #
    # if abs(sm) == 1:
    #     for i in range(bit_num):
    #         prog << CNOT(q_u[i], aux0[i])
    #
    # if abs(sm) == 2:
    #     for i in range(bit_num - 1):
    #         prog << CNOT(q_u[bit_num - 2 - i], q_u[bit_num - 1 - i])
    #         prog << CNOT(q_u[bit_num - 1 - i], q_u[bit_num - 2 - i])
    #     prog << CNOT(q_u, aux0)
    #
    # if abs(sm) == 3:
    #     for i in range(bit_num):
    #         prog << CNOT(q_u[i], aux0[i])
    #     for i in range(bit_num - 1):
    #         prog << CNOT(q_u[bit_num - 2 - i], q_u[bit_num - 1 - i])
    #         prog << CNOT(q_u[bit_num - 1 - i], q_u[bit_num - 2 - i])
    #     prog << QAdderIgnoreCarry(aux0, q_u, aux1[0])
    #
    # if d_neg:
    #     prog << QAdderIgnoreCarry(q_f[1:], aux0[1:], aux1[0])
    # else:
    #     prog << QAdderIgnoreCarry(q_f[1:], aux0[1:], aux1[0]).dagger()
    #
    # result = qvm.prob_run_dict(prog, q_f[1:], 1)
    # binary_str = list(result.keys())[0]
    #
    # c = int(binary_str, 2)
    # finalize()
    # if result_int != c:
    #     print("error !!!")
    # t3 = time.time()
    # print(t3 - t0, "s")

    return from_int(result_int)


def quantum_rusanov_flux_reduced(FL, FR, UL, UR, Smax, n_bits=None):
    """Reduced-input Rusanov flux, one circuit call per component."""

    F_quantum = np.zeros(3)
    for k in range(3):
        F_quantum[k] = quantum_rusanov_flux_component(
            FL[k], FR[k], UL[k], UR[k], Smax, n_bits
        )
    return F_quantum


def collect_quantum_rusanov_data(U, x, solver, num_points=30, n_bits=None, seed=42):
    """Sample interface pairs (UL, UR) from the field and evaluate both
    the classical and the quantum Rusanov flux on them.

    Returns interface coordinates, states, precomputed flux data, both
    flux evaluations and the per-component relative errors.
    """
    np.random.seed(seed)
    nx = U.shape[1]

    all_x_iface = np.array([0.5 * (x[i] + x[i + 1]) for i in range(nx - 1)])
    all_UL = np.array([U[:, i] for i in range(nx - 1)])
    all_UR = np.array([U[:, i + 1] for i in range(nx - 1)])

    if len(all_x_iface) > num_points:
        idx = np.sort(np.random.choice(len(all_x_iface), num_points, replace=False))
    else:
        idx = np.arange(len(all_x_iface))

    x_sample = all_x_iface[idx]
    UL_sample = all_UL[idx]
    UR_sample = all_UR[idx]

    FL_all = np.zeros((3, len(idx)))
    FR_all = np.zeros((3, len(idx)))
    Smax_all = np.zeros(len(idx))
    F_classic = np.zeros((3, len(idx)))
    F_quantum = np.zeros((3, len(idx)))

    for k in range(len(idx)):
        UL_k = UL_sample[k]
        UR_k = UR_sample[k]

        F_classic[:, k] = solver.rusanov_flux(UL_k, UR_k)

        FL, FR, Smax = compute_rusanov_intermediates(UL_k, UR_k, solver.gamma)
        FL_all[:, k] = FL
        FR_all[:, k] = FR
        Smax_all[k] = Smax

        F_quantum[:, k] = quantum_rusanov_flux_reduced(
            FL, FR, UL_k, UR_k, Smax, n_bits
        )

    eps = 1e-12
    err_mass = np.abs(F_quantum[0] - F_classic[0]) / (np.abs(F_classic[0]) + eps)
    err_mom = np.abs(F_quantum[1] - F_classic[1]) / (np.abs(F_classic[1]) + eps)
    err_energy = np.abs(F_quantum[2] - F_classic[2]) / (np.abs(F_classic[2]) + eps)

    return {
        'x_iface': x_sample,
        'UL': UL_sample,
        'UR': UR_sample,
        'FL': FL_all,
        'FR': FR_all,
        'Smax': Smax_all,
        'F_classic': F_classic,
        'F_quantum': F_quantum,
        'err_mass': err_mass,
        'err_mom': err_mom,
        'err_energy': err_energy,
        'n_bits': n_bits,
    }


if __name__ == "__main__":
    t0 = time.time()
    t_out = 0.2
    N = 400

    x = np.linspace(0.5/N, 1 - 0.5/N, N)

    rho_init = np.where(x < 0.5, 1.0, 0.125)
    u_init = np.zeros(N)
    p_init = np.where(x < 0.5, 1.0, 0.1)

    solver1 = RusanovSolver(gamma=1.4, order=1)
    U0_1 = np.zeros((3, N))
    for i in range(N):
        U0_1[:, i] = solver1.primitive_to_conserved(rho_init[i], u_init[i], p_init[i])
    U1 = solver1.solve(x, U0_1, t_out, CFL=0.8)
    rho1 = np.array([solver1.conserved_to_primitive(U1[:, i])[0] for i in range(N)])
    u1 = np.array([solver1.conserved_to_primitive(U1[:, i])[1] for i in range(N)])
    p1 = np.array([solver1.conserved_to_primitive(U1[:, i])[2] for i in range(N)])

    # exact solution
    # solver2 = RusanovSolver(gamma=1.4, order=2)
    # U0_2 = np.zeros((3, N))
    # for i in range(N):
    #     U0_2[:, i] = solver2.primitive_to_conserved(rho_init[i], u_init[i], p_init[i])
    # U2 = solver2.solve(x, U0_2, t_out, CFL=0.5)
    # rho2 = np.array([solver2.conserved_to_primitive(U2[:, i])[0] for i in range(N)])
    # u2 = np.array([solver2.conserved_to_primitive(U2[:, i])[1] for i in range(N)])
    # p2 = np.array([solver2.conserved_to_primitive(U2[:, i])[2] for i in range(N)])

    rho_exact, u_exact, p_exact = sod_exact_solution(x_exact, t_out)
    x_exact = np.linspace(0, 1, 5000)
    rho_exact, u_exact, p_exact = sod_exact_solution(x_exact, t_out)
    l1_1, l2_1 = compute_errors(x, rho1, x_exact, rho_exact)

    print('Running quantum Rusanov solver (9-bit)...')
    U_q = solver1.solve_with_quantum_flux(x, U0_1, t_out, n_bits=9, CFL=0.8)
    rho_q = np.array([solver1.conserved_to_primitive(U_q[:, i])[0] for i in range(N)])
    u_q   = np.array([solver1.conserved_to_primitive(U_q[:, i])[1] for i in range(N)])
    p_q   = np.array([solver1.conserved_to_primitive(U_q[:, i])[2] for i in range(N)])

    l1_q, l2_q = compute_errors(x, rho_q, x_exact, rho_exact)
    print(f'  Classical L1={l1_1:.4e}  L2={l2_1:.4e}')
    print(f'  Quantum   L1={l1_q:.4e}  L2={l2_q:.4e}')

    fig, axes = plt.subplots(1, 3, figsize=(18, 4))
    ax = axes[0]
    ax.plot(x_exact, rho_exact, 'k-', linewidth=2, label='Exact')
    ax.plot(x, rho1, 'r--', linewidth=1.5, label='Classical Rusanov')
    ax.plot(x, rho_q, 'b-.', linewidth=1.5, label='Quantum Rusanov (9-bit)')
    ax.set_xlabel('x')
    ax.set_ylabel(r'$\rho$')
    ax.set_title('Density')
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)

    ax = axes[1]
    ax.plot(x_exact, u_exact, 'k-', linewidth=2)
    ax.plot(x, u1, 'r--', linewidth=1.5)
    ax.plot(x, u_q, 'b-.', linewidth=1.5)
    ax.set_xlabel('x')
    ax.set_ylabel('u')
    ax.set_title('Velocity')
    ax.grid(alpha=0.3)

    ax = axes[2]
    ax.plot(x_exact, p_exact, 'k-', linewidth=2)
    ax.plot(x, p1, 'r--', linewidth=1.5)
    ax.plot(x, p_q, 'b-.', linewidth=1.5)
    ax.set_xlabel('x')
    ax.set_ylabel('p')
    ax.set_title('Pressure')
    ax.grid(alpha=0.3)

    plt.subplots_adjust(wspace=0.25, top=0.95)
    plt.savefig('Rusanov_SOD_quantum.png', dpi=400)
    print('Saved: Rusanov_SOD_quantum.png')
    t1 = time.time()
    print(t1 - t0, "s")
