import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams

# Save built-in sum before pyqpanda overwrites it
_builtin_sum = sum

from pyqpanda import *

# ============================================================
# Publication-quality matplotlib configuration
# ============================================================
rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'font.size': 13,
    'axes.titlesize': 15,
    'axes.labelsize': 14,
    'xtick.labelsize': 12,
    'ytick.labelsize': 12,
    'legend.fontsize': 11,
    'figure.dpi': 150,
    'savefig.dpi': 1000,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
    'axes.linewidth': 1.2,
    'xtick.major.width': 1.0,
    'ytick.major.width': 1.0,
    'xtick.major.size': 4.5,
    'ytick.major.size': 4.5,
    'axes.unicode_minus': False,
})


# ============================================================
# Gate-type counting helper
# ============================================================
def count_all_gate_types(prog):
    """Count all relevant gate types in a QProg."""
    return {
        'X':       count_qgate_num(prog, GateType.PAULI_X_GATE),
        'CNOT':    count_qgate_num(prog, GateType.CNOT_GATE),
        'Toffoli': count_qgate_num(prog, GateType.TOFFOLI_GATE),
        'SWAP':    count_qgate_num(prog, GateType.SWAP_GATE),
        'total':   get_qgate_num(prog),
    }


def gate_dict_to_array(d):
    """Convert gate dict to ordered array for consistent key order."""
    return np.array([d['X'], d['CNOT'], d['Toffoli'], d['SWAP'],
                     d['total'] - d['X'] - d['CNOT'] - d['Toffoli'] - d['SWAP']])


GATE_LABELS = ['X', 'CNOT', 'Toffoli', 'SWAP', 'Other']


# ============================================================
# Quantum circuit builders (unchanged logic)
# ============================================================
def minmod_gate_count(bit_num):
    """Build Minmod limiter quantum circuit, return total gate count.
    bit_num: data bit-width (excludes sign bit)."""
    qvm = init_quantum_machine(QMachineType.CPU)
    prog = QProg()

    q_sign_a = qvm.qAlloc_many(1)
    q_sign_b = qvm.qAlloc_many(1)
    q_a = qvm.qAlloc_many(bit_num + 1)
    q_b = qvm.qAlloc_many(bit_num + 1)
    aux = qvm.qAlloc_many(1)

    prog << X(q_sign_a[0])
    prog << CNOT(q_sign_a[0], q_sign_b[0])
    prog << X(q_sign_a[0])

    adder_dag = QAdderIgnoreCarry(q_b, q_a, aux[0]).dagger()
    adder = QAdderIgnoreCarry(q_b[0:bit_num], q_a[0:bit_num], aux[0])

    prog << adder_dag.control(q_sign_b[0])
    prog << adder.control(q_sign_b[0])
    prog << X(q_b[-1]).control(q_sign_b[0])

    prog << bind_nonnegative_data(0, q_b).control(q_sign_b[0]).control(q_b[-1])
    prog << adder.control(q_sign_b[0]).control(q_b[-1])

    prog << X(q_sign_b[0])
    prog << bind_nonnegative_data(0, q_b).control(q_sign_b[0])

    gates = count_all_gate_types(prog)
    finalize()
    return gates


def quantum_compare(bit_num, q_a, q_b, q_c):
    circ = QCircuit()
    circ << QAdderIgnoreCarry(q_b, q_a, q_c[0]).dagger()
    circ << QAdderIgnoreCarry(q_b[0:bit_num], q_a[0:bit_num], q_c[1])
    circ << QAdderIgnoreCarry(q_c, q_b[0:bit_num], q_a[-1]).control(q_b[-1])
    circ << X(q_b[-1])
    circ << QAdderIgnoreCarry(q_c, q_a[0:bit_num], q_a[-1]).control(q_b[-1])
    circ << X(q_b[-1])
    return circ


def quantum_compare_max(bit_num, q_a, q_b, q_c):
    circ = QCircuit()
    circ << QAdderIgnoreCarry(q_b, q_a, q_c[0]).dagger()
    circ << QAdderIgnoreCarry(q_b[0:bit_num], q_a[0:bit_num], q_c[1])
    circ << X(q_b[-1])
    circ << QAdderIgnoreCarry(q_c, q_b[0:bit_num], q_a[-1]).control(q_b[-1])
    circ << X(q_b[-1])
    circ << QAdderIgnoreCarry(q_c, q_a[0:bit_num], q_a[-1]).control(q_b[-1])
    return circ


def quantum_mul_2(bit_num, q_a):
    circ = QCircuit()
    for i in range(0, bit_num):
        circ << SWAP(q_a[bit_num - i], q_a[bit_num - i - 1])
    return circ


def superbee_gate_count(bit_num):
    a = [1]
    b = [1]

    for i in range(len(a)):
        qvm = init_quantum_machine(QMachineType.CPU)
        prog = QProg()

        q_sign_a = qvm.qAlloc_many(1)
        q_sign_b = qvm.qAlloc_many(1)
        q_a = qvm.qAlloc_many(bit_num + 1)
        q_b = qvm.qAlloc_many(bit_num + 1)
        q_sign_c = qvm.qAlloc_many(1)
        q_aux = qvm.qAlloc_many(1)
        q_c0 = qvm.qAlloc_many(bit_num)
        q_c1 = qvm.qAlloc_many(bit_num)
        q_c = qvm.qAlloc_many(bit_num)

        if a[i] < 0:
            prog << X(q_sign_a[0])
        if b[i] < 0:
            prog << X(q_sign_b[0])

        prog << bind_nonnegative_data(abs(round(a[i])), q_a)
        prog << bind_nonnegative_data(abs(round(b[i])), q_b)

        prog << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])
        prog << X(q_sign_a[0])
        prog << X(q_sign_b[0])
        prog << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])

        prog << quantum_mul_2(bit_num, q_a).control(q_sign_c[0])
        prog << quantum_compare(bit_num, q_a, q_b, q_c0).control(q_sign_c[0])
        prog << quantum_mul_2(bit_num, q_a).dagger().control(q_sign_c[0])
        prog << quantum_mul_2(bit_num - 1, q_b[0: bit_num]).control(q_sign_c[0])
        q_b = q_b[0: bit_num] + q_aux
        prog << quantum_compare(bit_num, q_a, q_b, q_c1).control(q_sign_c[0])
        prog << quantum_mul_2(bit_num, q_b).dagger().control(q_sign_c[0])
        prog << quantum_compare_max(bit_num - 1, q_c0, q_c1, q_c[0: bit_num - 1]).control(q_sign_c[0])

        prog << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])
        prog << X(q_sign_a[0])
        prog << X(q_sign_b[0])
        prog << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])
        prog << CNOT(q_sign_a[0], q_sign_c[0])

        gates = count_all_gate_types(prog)
        finalize()

    return gates


def minmod_op_gate_count(bit_num):
    """Build op-register Minmod limiter circuit, return per-type gate counts."""
    qvm = init_quantum_machine(QMachineType.CPU)
    prog = QProg()

    q_sign_a = qvm.qAlloc_many(1)
    q_sign_b = qvm.qAlloc_many(1)
    q_a = qvm.qAlloc_many(bit_num + 1)
    q_b = qvm.qAlloc_many(bit_num + 1)
    q_sign_c = qvm.qAlloc_many(1)
    q_c = qvm.qAlloc_many(bit_num)

    prog << X(q_sign_a[0])
    prog << X(q_sign_b[0])

    prog << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])
    prog << X(q_sign_a[0])
    prog << X(q_sign_b[0])
    prog << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])

    adder_dag = QAdderIgnoreCarry(q_b, q_a, q_c[0]).dagger()
    adder1 = QAdderIgnoreCarry(q_b[0:bit_num], q_a[0:bit_num], q_c[1])

    prog << adder_dag.control(q_sign_c[0])
    prog << adder1.control(q_sign_c[0])

    adder2 = QAdderIgnoreCarry(q_c, q_b[0:bit_num], q_a[-1])
    prog << adder2.control(q_sign_c[0]).control(q_b[-1])

    prog << X(q_b[-1])

    adder3 = QAdderIgnoreCarry(q_c, q_a[0:bit_num], q_a[-1])
    prog << adder3.control(q_sign_c[0]).control(q_b[-1])

    prog << X(q_b[-1])

    prog << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])
    prog << X(q_sign_a[0])
    prog << X(q_sign_b[0])
    prog << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])
    prog << CNOT(q_sign_a[0], q_sign_c[0])

    gates = count_all_gate_types(prog)
    finalize()
    return gates


# ============================================================
# Complexity fitting
# ============================================================
def fit_complexity(x_data, y_data):
    """Fit a linear model y = a*x + b, return coefficients and R^2."""
    x = np.array(x_data, dtype=float)
    y = np.array(y_data, dtype=float)
    A = np.vstack([x, np.ones_like(x)]).T
    coeffs, residuals, rank, sv = np.linalg.lstsq(A, y, rcond=None)
    y_pred = A @ coeffs
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 1.0
    return coeffs[0], coeffs[1], r2


# ============================================================
# Gate-count auditor: counts individual components
# ============================================================
def audit_adder_gates(bit_num):
    """Count gates inside one QAdderIgnoreCarry (n+1 bits) to break down 18n+11."""
    qvm = init_quantum_machine(QMachineType.CPU)
    prog = QProg()
    q_a = qvm.qAlloc_many(bit_num + 1)
    q_b = qvm.qAlloc_many(bit_num + 1)
    aux = qvm.qAlloc_many(1)

    adder = QAdderIgnoreCarry(q_b[0:bit_num], q_a[0:bit_num], aux[0])
    prog << adder
    g = count_all_gate_types(prog)
    finalize()
    return g

def audit_ip_minmod_components(bit_num):
    """Audit ip-Minmod circuit component-by-component to explain the formula."""
    qvm = init_quantum_machine(QMachineType.CPU)
    q_sign_a = qvm.qAlloc_many(1)
    q_sign_b = qvm.qAlloc_many(1)
    q_a = qvm.qAlloc_many(bit_num + 1)
    q_b = qvm.qAlloc_many(bit_num + 1)
    aux = qvm.qAlloc_many(1)

    parts = {}

    # Part 1: sign init
    p = QProg()
    p << X(q_sign_a[0]) << CNOT(q_sign_a[0], q_sign_b[0]) << X(q_sign_a[0])
    parts['sign_init'] = count_all_gate_types(p)

    # Part 2: controlled adder_dag (n+1 bits)
    adder_dag = QAdderIgnoreCarry(q_b, q_a, aux[0]).dagger()
    p2 = QProg()
    p2 << adder_dag.control(q_sign_b[0])
    parts['ctrl_adder_dag'] = count_all_gate_types(p2)

    # Part 3: controlled adder (n bits)
    adder = QAdderIgnoreCarry(q_b[0:bit_num], q_a[0:bit_num], aux[0])
    p3 = QProg()
    p3 << adder.control(q_sign_b[0])
    parts['ctrl_adder'] = count_all_gate_types(p3)

    # Part 4: controlled X
    p4 = QProg()
    p4 << X(q_b[-1]).control(q_sign_b[0])
    parts['ctrl_x'] = count_all_gate_types(p4)

    # Part 5: double-controlled adder
    p5 = QProg()
    p5 << adder.control(q_sign_b[0]).control(q_b[-1])
    parts['dctrl_adder'] = count_all_gate_types(p5)

    # Part 6: sign reset
    p6 = QProg()
    p6 << X(q_sign_b[0])
    parts['sign_reset'] = count_all_gate_types(p6)

    # Part 7-8: bind operations (classical, not counted by pyqpanda)
    total = _builtin_sum(v['total'] for v in parts.values())

    finalize()
    return parts, total

def audit_op_minmod_components(bit_num):
    """Audit op-Minmod circuit component-by-component."""
    qvm = init_quantum_machine(QMachineType.CPU)
    q_sign_a = qvm.qAlloc_many(1)
    q_sign_b = qvm.qAlloc_many(1)
    q_a = qvm.qAlloc_many(bit_num + 1)
    q_b = qvm.qAlloc_many(bit_num + 1)
    q_sign_c = qvm.qAlloc_many(1)
    q_c = qvm.qAlloc_many(bit_num)

    parts = {}

    # Part 1: sign flip
    p = QProg()
    p << X(q_sign_a[0]) << X(q_sign_b[0])
    parts['sign_flip'] = count_all_gate_types(p)

    # Part 2: sign XOR
    p2 = QProg()
    p2 << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])
    p2 << X(q_sign_a[0]) << X(q_sign_b[0])
    p2 << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])
    parts['sign_xor'] = count_all_gate_types(p2)

    # Part 3: controlled adder_dag
    adder_dag = QAdderIgnoreCarry(q_b, q_a, q_c[0]).dagger()
    p3 = QProg()
    p3 << adder_dag.control(q_sign_c[0])
    parts['ctrl_adder_dag'] = count_all_gate_types(p3)

    # Part 4: controlled adder1
    adder1 = QAdderIgnoreCarry(q_b[0:bit_num], q_a[0:bit_num], q_c[1])
    p4 = QProg()
    p4 << adder1.control(q_sign_c[0])
    parts['ctrl_adder1'] = count_all_gate_types(p4)

    # Part 5: double-controlled adder2
    adder2 = QAdderIgnoreCarry(q_c, q_b[0:bit_num], q_a[-1])
    p5 = QProg()
    p5 << adder2.control(q_sign_c[0]).control(q_b[-1])
    parts['dctrl_adder2'] = count_all_gate_types(p5)

    # Part 6: X flip
    p6 = QProg()
    p6 << X(q_b[-1])
    parts['x_flip_1'] = count_all_gate_types(p6)

    # Part 7: double-controlled adder3
    adder3 = QAdderIgnoreCarry(q_c, q_a[0:bit_num], q_a[-1])
    p7 = QProg()
    p7 << adder3.control(q_sign_c[0]).control(q_b[-1])
    parts['dctrl_adder3'] = count_all_gate_types(p7)

    # Part 8: X flip back
    p8 = QProg()
    p8 << X(q_b[-1])
    parts['x_flip_2'] = count_all_gate_types(p8)

    # Part 9: sign restore
    p9 = QProg()
    p9 << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])
    p9 << X(q_sign_a[0]) << X(q_sign_b[0])
    p9 << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])
    p9 << CNOT(q_sign_a[0], q_sign_c[0])
    parts['sign_restore'] = count_all_gate_types(p9)

    total = _builtin_sum(v['total'] for v in parts.values())
    finalize()
    return parts, total


# ============================================================
# Figure 1: Gate count scaling with Superbee extrapolation
# ============================================================
def plot_scaling_figure(mm_bits, mm_totals, mm_breakdowns,
                        sb_bits, sb_totals, sb_breakdowns,
                        op_bits, op_totals, op_breakdowns):
    """Standalone figure: total gate count vs n with linear fits and CNOT/X shading."""

    fig, ax = plt.subplots(figsize=(10, 7))

    c_ip  = '#2166AC'
    c_op  = '#B2182B'
    c_sb  = '#4DAF4A'

    a_ip, b_ip, r2_ip = fit_complexity(mm_bits, mm_totals)
    a_op, b_op, r2_op = fit_complexity(op_bits, op_totals)
    a_sb, b_sb, r2_sb = fit_complexity(sb_bits, sb_totals)

    # Superbee extrapolated data
    sb_ext_bits = list(range(5, 11))
    sb_ext_totals = [a_sb * n + b_sb for n in sb_ext_bits]
    sb_cnot_slope = sb_breakdowns[1]['CNOT'] - sb_breakdowns[0]['CNOT']
    sb_x_slope    = sb_breakdowns[1]['X'] - sb_breakdowns[0]['X']
    sb_ext_cnot  = [sb_breakdowns[0]['CNOT'] + sb_cnot_slope * (n - 3) for n in sb_ext_bits]
    sb_ext_cnot_arr = np.array(sb_ext_cnot, dtype=float)
    sb_ext_total_arr = np.array(sb_ext_totals, dtype=float)

    # Data points & fit lines
    x_fine = np.linspace(3, 10, 100)
    ax.plot(mm_bits, mm_totals, 'o', color=c_ip, markersize=8,
            markeredgecolor='black', markeredgewidth=0.6, zorder=5)
    ax.plot(x_fine, a_ip * x_fine + b_ip, '-', color=c_ip, linewidth=2.5, zorder=4)

    ax.plot(op_bits, op_totals, '^', color=c_op, markersize=8,
            markeredgecolor='black', markeredgewidth=0.6, zorder=5)
    ax.plot(x_fine[:len(x_fine)*6//7], a_op * x_fine[:len(x_fine)*6//7] + b_op,
            '-', color=c_op, linewidth=2.5, zorder=4)

    # Superbee: measured (solid) + extrapolated (hollow)
    ax.plot(sb_bits, sb_totals, 's', color=c_sb, markersize=12,
            markeredgecolor='black', markeredgewidth=0.7, zorder=5)
    ax.plot(sb_ext_bits, sb_ext_totals, 's', color=c_sb, markersize=12,
            markerfacecolor='none', markeredgecolor=c_sb, markeredgewidth=1.5,
            linestyle='None', zorder=5, alpha=0.6)
    ax.plot(x_fine, a_sb * x_fine + b_sb, '--', color=c_sb, linewidth=1.8, zorder=4, alpha=0.5)

    # Legend
    from matplotlib.lines import Line2D
    legend_main = [
        Line2D([0], [0], color=c_ip, marker='o', markersize=8, linewidth=2.5,
               markeredgecolor='black', markeredgewidth=0.5, label='ip-Minmod'),
        Line2D([0], [0], color=c_op, marker='^', markersize=8, linewidth=2.5,
               markeredgecolor='black', markeredgewidth=0.5, label='op-Minmod'),
        Line2D([0], [0], color=c_sb, marker='s', markersize=10, linewidth=1.8,
               markeredgecolor='black', markeredgewidth=0.5, label='Superbee'),
    ]
    ax.legend(handles=legend_main, loc='upper left', frameon=True, fancybox=True,
              framealpha=0.92, edgecolor='gray', fontsize=10, ncol=1)

    # Formula box (top-left, right of legend)
    formula_text = (
        f"ip-Minmod :  ${a_ip:.0f}n + {b_ip:.0f}$\n"
        f"op-Minmod :  ${a_op:.0f}n + {b_op:.0f}$\n"
        f"Superbee  :  ${a_sb:.0f}n + {b_sb:.0f}$"
    )
    ax.text(0.32, 0.98, formula_text, transform=ax.transAxes,
            fontsize=9.5, ha='left', va='top',
            bbox=dict(boxstyle='round,pad=0.5', facecolor='white',
                      edgecolor='gray', alpha=0.9))

    ax.set_xlabel('Bit-width $n$', fontsize=13)
    ax.set_ylabel('Gate count', fontsize=13)
    ax.set_xticks(range(3, 11))
    ax.grid(True, alpha=0.18, linestyle='--')
    ax.set_xlim(2.5, 10.5)
    ax.set_ylim(0, sb_ext_totals[-1] * 1.10)

    fig.savefig('limiter_gate_scaling.png', dpi=1000, bbox_inches='tight',
                facecolor='white', edgecolor='none')
    plt.show()
    print("Figure 1 saved: limiter_gate_scaling.png")

    return a_ip, b_ip, a_op, b_op, a_sb, b_sb


# ============================================================
# Figure 2: Gate composition at n=3 and n=4 (all circuits)
# ============================================================
def plot_composition_figure(mm_bits, mm_breakdowns,
                            sb_bits, sb_breakdowns,
                            op_bits, op_breakdowns):
    """Standalone figure: stacked-bar composition at n=3 and n=4."""

    fig, ax = plt.subplots(figsize=(10, 7))

    c_ip  = '#2166AC'
    c_op  = '#B2182B'
    c_sb  = '#4DAF4A'
    bar_colors = ['#F4A582', '#92C5DE', '#0571B0', '#CA0020', '#D9D9D9']
    gate_labels_short = ['X', 'CNOT', 'Toff', 'SWAP', 'Oth']

    # Two groups: n=3 and n=4, each with all 3 circuits (Superbee available at both)
    groups = [
        {'label': '$n = 3$', 'n': 3, 'circuits': ['ip', 'op', 'sb']},
        {'label': '$n = 4$', 'n': 4, 'circuits': ['ip', 'op', 'sb']},
    ]

    group_width = 0.65
    all_xticks = []
    all_xticklabels = []
    max_total = 0

    for gi, grp in enumerate(groups):
        n_val = grp['n']
        n_bars = len(grp['circuits'])
        group_center = gi * 0.85

        for bi, circ in enumerate(grp['circuits']):
            if circ == 'ip':
                idx = mm_bits.index(n_val)
                arr = gate_dict_to_array(mm_breakdowns[idx])
                color = c_ip
                label = 'ip-Minmod'
            elif circ == 'op':
                idx = op_bits.index(n_val)
                arr = gate_dict_to_array(op_breakdowns[idx])
                color = c_op
                label = 'op-Minmod'
            elif circ == 'sb':
                idx = sb_bits.index(n_val)
                arr = gate_dict_to_array(sb_breakdowns[idx])
                color = c_sb
                label = 'Superbee'
            else:
                continue

            x_center = group_center - group_width / 2 + (bi + 0.5) * (group_width / n_bars)
            w = (group_width / n_bars) * 0.82

            bottom = 0
            for gate_i in range(len(GATE_LABELS)):
                h = arr[gate_i]
                ax.bar(x_center, h, w, bottom=bottom,
                       color=bar_colors[gate_i])

                if h > 5:
                    ax.text(x_center, bottom + h / 2, gate_labels_short[gate_i],
                            ha='center', va='center', fontsize=8, color='white',
                            fontweight='bold')
                bottom += h

            max_total = max(max_total, arr.sum())
            cnot_pct = (arr[1] + arr[2]) / arr.sum() * 100
            ax.text(x_center, bottom + 5, f'{cnot_pct:.0f}% CNOT', ha='center', va='bottom',
                    fontsize=9.5, color='gray')

            all_xticks.append(x_center)
            all_xticklabels.append(label)

    # Group separator
    ax.axvline(x=0.425, color='gray', linewidth=0.8, linestyle=':', alpha=0.5)

    ax.set_xticks(all_xticks)
    ax.set_xticklabels(all_xticklabels, fontsize=11)

    # Group labels (data x, axes-fraction y)
    ax.text(0.0, -0.06, '$n = 3$', ha='center', va='top', fontsize=14,
            fontweight='bold', transform=ax.get_xaxis_transform())
    ax.text(0.85, -0.06, '$n = 4$', ha='center', va='top', fontsize=14,
            fontweight='bold', transform=ax.get_xaxis_transform())

    # Legend
    from matplotlib.patches import Patch
    legend_gates = [
        Patch(facecolor=bar_colors[0], edgecolor='black', linewidth=0.4, label='X'),
        Patch(facecolor=bar_colors[1], edgecolor='black', linewidth=0.4, label='CNOT'),
        Patch(facecolor=bar_colors[4], edgecolor='black', linewidth=0.4, label='Other'),
    ]
    ax.legend(handles=legend_gates, loc='upper right', ncol=3,
              frameon=True, fancybox=True, framealpha=0.9, edgecolor='gray',
              fontsize=10, columnspacing=0.6, handlelength=1.0)

    ax.set_ylabel('Gate count', fontsize=13)
    ax.grid(axis='y', alpha=0.15, linestyle='--')
    ax.set_ylim(0, max_total * 1.18)
    ax.set_xlim(-0.3, 1.15)

    fig.savefig('limiter_gate_composition.png', dpi=1000, bbox_inches='tight',
                facecolor='white', edgecolor='none')
    plt.show()
    print("Figure 2 saved: limiter_gate_composition.png")


# ============================================================
# Main
# ============================================================
def main():
    sb_bit_nums = list(range(3, 5))          # Superbee 3-4
    mm_bit_nums = list(range(3, 11))         # ip-Minmod 3-10
    op_bit_nums = list(range(3, 9))          # op-Minmod 3-8 (qubit limit at n>=9)

    minmod_gates_list   = []   # list of dicts
    superbee_gates_list = []
    minmod_op_gates_list = []

    # ---- Collect ip-Minmod data ----
    print("Collecting ip-Minmod gate data (bit=3-10)...")
    for n in mm_bit_nums:
        print(f"  ip-Minmod n={n} ...", end=' ')
        g = minmod_gate_count(n)
        minmod_gates_list.append(g)
        print(f"total={g['total']}, CNOT={g['CNOT']}, Toffoli={g['Toffoli']}, X={g['X']}, SWAP={g['SWAP']}")

    # ---- Collect Superbee data ----
    print("\nCollecting Superbee gate data (bit=3-4)...")
    for n in sb_bit_nums:
        print(f"  Superbee n={n} ...", end=' ')
        g = superbee_gate_count(n)
        superbee_gates_list.append(g)
        print(f"total={g['total']}, CNOT={g['CNOT']}, Toffoli={g['Toffoli']}, X={g['X']}, SWAP={g['SWAP']}")

    # ---- Collect op-Minmod data ----
    print("\nCollecting op-Minmod gate data (bit=3-10)...")
    for n in op_bit_nums:
        print(f"  op-Minmod n={n} ...", end=' ')
        g = minmod_op_gate_count(n)
        minmod_op_gates_list.append(g)
        print(f"total={g['total']}, CNOT={g['CNOT']}, Toffoli={g['Toffoli']}, X={g['X']}, SWAP={g['SWAP']}")

    # ---- Extract total counts ----
    mm_totals  = [g['total'] for g in minmod_gates_list]
    sb_totals  = [g['total'] for g in superbee_gates_list]
    op_totals  = [g['total'] for g in minmod_op_gates_list]

    # ---- Complexity analysis ----
    print("\n" + "=" * 65)
    print("Complexity Analysis (linear fit: y = a*n + b)")
    print("-" * 65)
    a, b, r2 = fit_complexity(mm_bit_nums, mm_totals)
    print(f"  ip-Minmod:  gates = {a:.2f}*n + {b:.1f},  R^2 = {r2:.6f}")
    a, b, r2 = fit_complexity(op_bit_nums, op_totals)
    print(f"  op-Minmod:  gates = {a:.2f}*n + {b:.1f},  R^2 = {r2:.6f}")
    a, b, r2 = fit_complexity(sb_bit_nums, sb_totals)
    print(f"  Superbee:   gates = {a:.2f}*n + {b:.1f},  R^2 = {r2:.6f}")
    print("=" * 65)

    # ---- Print detailed table ----
    print("\n" + "=" * 100)
    print("Detailed Gate Count Table")
    print("=" * 100)
    header = f"{'n':>3}  {'ip-Minmod':>10}  {'op-Minmod':>10}  {'Superbee':>10}  |  {'ip CNOT':>8}  {'ip Toff':>8}  {'ip X':>6}  |  {'op CNOT':>8}  {'op Toff':>8}  {'op X':>6}  |  {'sb CNOT':>8}  {'sb Toff':>8}  {'sb X':>6}  {'sb SWAP':>8}"
    print(header)
    print("-" * 100)
    for i, n in enumerate(mm_bit_nums):
        ig = minmod_gates_list[i]
        has_op = n in op_bit_nums
        has_sb = n in sb_bit_nums

        ip_str = f"{ig['total']:10d}"
        cnot_ip = f"{ig['CNOT']:8d}"
        toff_ip = f"{ig['Toffoli']:8d}"
        x_ip    = f"{ig['X']:6d}"

        if has_op:
            og = minmod_op_gates_list[op_bit_nums.index(n)]
            op_str = f"{og['total']:10d}"
            cnot_op = f"{og['CNOT']:8d}"
            toff_op = f"{og['Toffoli']:8d}"
            x_op    = f"{og['X']:6d}"
        else:
            op_str = f"{'—':>10}"
            cnot_op, toff_op, x_op = f"{'—':>8}", f"{'—':>8}", f"{'—':>6}"

        if has_sb:
            sg = superbee_gates_list[sb_bit_nums.index(n)]
            sb_str = f"{sg['total']:10d}"
            cnot_sb = f"{sg['CNOT']:8d}"
            toff_sb = f"{sg['Toffoli']:8d}"
            x_sb    = f"{sg['X']:6d}"
            swp_sb  = f"{sg['SWAP']:8d}"
        else:
            sb_str = f"{'—':>10}"
            cnot_sb, toff_sb, x_sb, swp_sb = f"{'—':>8}", f"{'—':>8}", f"{'—':>6}", f"{'—':>8}"

        print(f"{n:3d}  {ip_str}  {op_str}  {sb_str}  |  "
              f"{cnot_ip}  {toff_ip}  {x_ip}  |  "
              f"{cnot_op}  {toff_op}  {x_op}  |  "
              f"{cnot_sb}  {toff_sb}  {x_sb}  {swp_sb}")
    print("=" * 100)

    # ---- User-friendly summary ----
    print("\n" + "=" * 65)
    print("Key Takeaways")
    print("-" * 65)
    ip_per_bit = (mm_totals[-1] - mm_totals[0]) / (mm_bit_nums[-1] - mm_bit_nums[0])
    op_per_bit = (op_totals[-1] - op_totals[0]) / (op_bit_nums[-1] - op_bit_nums[0])
    print(f"  ip-Minmod scaling: ~{ip_per_bit:.1f} gates per extra bit")
    print(f"  op-Minmod scaling: ~{op_per_bit:.1f} gates per extra bit")
    print(f"  Superbee uses {sb_totals[0]/mm_totals[0]:.1f}x more gates than ip-Minmod (n=3)")
    mm_ratio_3 = (minmod_gates_list[0]['CNOT'] + minmod_gates_list[0]['Toffoli']) / minmod_gates_list[0]['total'] * 100
    print(f"  ip-Minmod multi-qubit gate ratio: ~{mm_ratio_3:.1f}% (n=3)")
    print("=" * 65)

    # ---- Component-level audit: explain where 18n+11 comes from ----
    print("\n" + "=" * 80)
    print("Component-level Audit: ip-Minmod formula breakdown (n=5 as example)")
    print("=" * 80)
    parts, total = audit_ip_minmod_components(5)
    row_fmt = "  {:<22s}  {:>6d}  {:>6d}  {:>6d}  {:>6d}  {:>6d}"
    hdr_fmt = "  {:<22s}  {:>6s}  {:>6s}  {:>6s}  {:>6s}  {:>6s}"
    print(hdr_fmt.format('Component', 'Total', 'CNOT', 'Toffoli', 'X', 'SWAP'))
    print("  " + "-" * 56)
    for name, g in parts.items():
        print(row_fmt.format(name, g['total'], g['CNOT'], g['Toffoli'], g['X'], g['SWAP']))
    print("  " + "-" * 56)
    print(row_fmt.format('SUM', total,
                          _builtin_sum(v['CNOT'] for v in parts.values()),
                          _builtin_sum(v['Toffoli'] for v in parts.values()),
                          _builtin_sum(v['X'] for v in parts.values()),
                          _builtin_sum(v['SWAP'] for v in parts.values())))
    print()

    # QAdder alone
    adder_g = audit_adder_gates(5)
    print(f"  One QAdderIgnoreCarry (n=5):  total={adder_g['total']}, "
          f"CNOT={adder_g['CNOT']}, X={adder_g['X']}")
    print("  Formula: ip-Minmod ≈ 3×|adder(n+1)| + const")
    print(f"  Verified: total({parts['ctrl_adder_dag']['total']} + "
          f"{parts['ctrl_adder']['total']} + "
          f"{parts['dctrl_adder']['total']}) ≈ "
          f"3×{adder_g['total']} + ({parts['sign_init']['total']} + "
          f"{parts['ctrl_x']['total']} + {parts['sign_reset']['total']})")
    print("=" * 80)

    print("\n" + "=" * 80)
    print("Component-level Audit: op-Minmod formula breakdown (n=5 as example)")
    print("=" * 80)
    parts2, total2 = audit_op_minmod_components(5)
    print(hdr_fmt.format('Component', 'Total', 'CNOT', 'Toffoli', 'X', 'SWAP'))
    print("  " + "-" * 56)
    for name, g in parts2.items():
        print(row_fmt.format(name, g['total'], g['CNOT'], g['Toffoli'], g['X'], g['SWAP']))
    print("  " + "-" * 56)
    print(row_fmt.format('SUM', total2,
                          _builtin_sum(v['CNOT'] for v in parts2.values()),
                          _builtin_sum(v['Toffoli'] for v in parts2.values()),
                          _builtin_sum(v['X'] for v in parts2.values()),
                          _builtin_sum(v['SWAP'] for v in parts2.values())))
    print("=" * 80)

    # ---- Plot figures ----
    coeffs = plot_scaling_figure(
        mm_bit_nums, mm_totals, minmod_gates_list,
        sb_bit_nums, sb_totals, superbee_gates_list,
        op_bit_nums, op_totals, minmod_op_gates_list
    )
    a_ip, b_ip, a_op, b_op, a_sb, b_sb = coeffs

    plot_composition_figure(
        mm_bit_nums, minmod_gates_list,
        sb_bit_nums, superbee_gates_list,
        op_bit_nums, minmod_op_gates_list
    )

    # ---- Write information TXT file ----
    write_info_txt(mm_bit_nums, minmod_gates_list,
                   op_bit_nums, minmod_op_gates_list,
                   sb_bit_nums, superbee_gates_list,
                   a_ip, b_ip, a_op, b_op, a_sb, b_sb)


def write_info_txt(mm_bits, mm_data, op_bits, op_data, sb_bits, sb_data,
                   a_ip, b_ip, a_op, b_op, a_sb, b_sb):
    """Write a comprehensive text file documenting the figure and all data."""
    sb_ext_bits = list(range(5, 11))
    sb_ext_totals = [a_sb * n + b_sb for n in sb_ext_bits]
    sb_cnot_slope = sb_data[1]['CNOT'] - sb_data[0]['CNOT']
    sb_x_slope    = sb_data[1]['X'] - sb_data[0]['X']
    sb_swap_slope = sb_data[1]['SWAP'] - sb_data[0]['SWAP']
    sb_ext_cnot = [sb_data[0]['CNOT'] + sb_cnot_slope * (n - 3) for n in sb_ext_bits]
    sb_ext_x    = [sb_data[0]['X'] + sb_x_slope * (n - 3) for n in sb_ext_bits]
    sb_ext_swap = [sb_data[0]['SWAP'] + sb_swap_slope * (n - 3) for n in sb_ext_bits]

    lines = []
    lines.append("=" * 72)
    lines.append("  Quantum Limiter Gate Count — Figure Information")
    lines.append("=" * 72)
    lines.append(f"  Generated: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"  Image file: limiter_gate_count_comparison.png  (400 DPI)")
    lines.append("")

    lines.append("-" * 72)
    lines.append("  FIGURE DESCRIPTION")
    lines.append("-" * 72)
    lines.append("  Two separate figures comparing quantum gate resource costs.")
    lines.append("")
    lines.append("  Figure 1: limiter_gate_scaling.png")
    lines.append("  ─────────────────────────────────────────")
    lines.append("  Gate count vs bit-width n (3 <= n <= 10) with linear fits.")
    lines.append("    - Solid markers  = measured data (pyqpanda CPU simulator)")
    lines.append("    - Hollow squares = Superbee formula-extrapolated values (n >= 5)")
    lines.append("    - Solid lines    = linear fit (all R^2 = 1.0000)")
    lines.append("    - Formula box    = top-left annotation with the 3 complexity equations")
    lines.append("    - ip-Minmod:  n = 3..10  (8 data points)")
    lines.append("    - op-Minmod:  n = 3..8   (6 points; qubit limit at n=9)")
    lines.append("    - Superbee:   n = 3,4    (2 measured; n=5..10 extrapolated)")
    lines.append("")
    lines.append("  Figure 2: limiter_gate_composition.png")
    lines.append("  ────────────────────────────────────────")
    lines.append("  Gate composition breakdown at n=3 and n=4.")
    lines.append("    - Two groups: left = n=3, right = n=4")
    lines.append("    - Each group: ip-Minmod, op-Minmod, Superbee (all available)")
    lines.append("    - Stacked bars: X / CNOT / Other (Toffoli=0, SWAP=0)")
    lines.append("    - Per-segment labels inside each bar")
    lines.append("    - Bar top: CNOT percentage only")
    lines.append("")

    lines.append("-" * 72)
    lines.append("  COMPLEXITY FORMULAS (linear fit, all R^2 = 1.0000)")
    lines.append("-" * 72)
    lines.append(f"  ip-Minmod:  gates(n) = {a_ip:.0f}*n + {b_ip:.0f}")
    lines.append(f"  op-Minmod:  gates(n) = {a_op:.0f}*n + {b_op:.0f}")
    lines.append(f"  Superbee:   gates(n) = {a_sb:.0f}*n + {b_sb:.0f}")
    lines.append("")

    lines.append("-" * 72)
    lines.append("  MEASURED GATE COUNTS")
    lines.append("-" * 72)
    hdr = f"  {'n':>3s}  {'ip-Total':>9s}  {'ip-CNOT':>8s}  {'ip-X':>6s}  |  {'op-Total':>9s}  {'op-CNOT':>8s}  {'op-X':>6s}  |  {'sb-Total':>9s}  {'sb-CNOT':>8s}  {'sb-X':>6s}  {'sb-SWAP':>8s}"
    lines.append(hdr)
    lines.append("  " + "-" * 98)
    for i, n in enumerate(mm_bits):
        ig = mm_data[i]
        has_op = n in op_bits
        has_sb = n in sb_bits
        ip_row = f"  {n:3d}  {ig['total']:9d}  {ig['CNOT']:8d}  {ig['X']:6d}"
        if has_op:
            og = op_data[op_bits.index(n)]
            ip_row += f"  |  {og['total']:9d}  {og['CNOT']:8d}  {og['X']:6d}"
        else:
            ip_row += f"  |  {'—':>9s}  {'—':>8s}  {'—':>6s}"
        if has_sb:
            sg = sb_data[sb_bits.index(n)]
            ip_row += f"  |  {sg['total']:9d}  {sg['CNOT']:8d}  {sg['X']:6d}  {sg['SWAP']:8d}"
        else:
            ip_row += f"  |  {'—':>9s}  {'—':>8s}  {'—':>6s}  {'—':>8s}"
        lines.append(ip_row)

    lines.append("")
    lines.append("-" * 72)
    lines.append("  SUPERBEE EXTRAPOLATED VALUES (from 76n+10)")
    lines.append("-" * 72)
    lines.append(f"  {'n':>3s}  {'Total':>9s}  {'CNOT':>8s}  {'X':>6s}  {'SWAP':>8s}")
    lines.append("  " + "-" * 38)
    for i, n in enumerate(sb_ext_bits):
        lines.append(f"  {n:3d}  {int(sb_ext_totals[i]):9d}  {int(sb_ext_cnot[i]):8d}  "
                     f"{int(sb_ext_x[i]):6d}  {int(sb_ext_swap[i]):8d}")

    lines.append("")
    lines.append("-" * 72)
    lines.append("  KEY STATISTICS")
    lines.append("-" * 72)
    lines.append(f"  ip-Minmod cost per extra bit: {a_ip:.1f} gates")
    lines.append(f"  op-Minmod cost per extra bit: {a_op:.1f} gates")
    lines.append(f"  Superbee  cost per extra bit: {a_sb:.1f} gates")
    lines.append(f"  Superbee / ip-Minmod ratio at n=3: {sb_data[0]['total']/mm_data[0]['total']:.2f}x")
    for i, n in enumerate(mm_bits):
        ig = mm_data[i]
        cnot_ratio = ig['CNOT'] / ig['total'] * 100
        lines.append(f"  ip-Minmod n={n}: CNOT ratio = {cnot_ratio:.1f}%")
    for i, n in enumerate(op_bits):
        og = op_data[i]
        cnot_ratio = og['CNOT'] / og['total'] * 100
        lines.append(f"  op-Minmod n={n}: CNOT ratio = {cnot_ratio:.1f}%")
    for i, n in enumerate(sb_bits):
        sg = sb_data[i]
        cnot_ratio = sg['CNOT'] / sg['total'] * 100
        lines.append(f"  Superbee  n={n}: CNOT ratio = {cnot_ratio:.1f}%")

    lines.append("")
    lines.append("=" * 72)
    lines.append("  End of report")
    lines.append("=" * 72)

    txt_content = "\n".join(lines)
    with open("gate_count_info.txt", "w", encoding="utf-8") as f:
        f.write(txt_content)
    print("\nInfo file saved: gate_count_info.txt")


if __name__ == "__main__":
    main()
