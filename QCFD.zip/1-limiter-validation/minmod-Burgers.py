import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
from scipy import stats
from pyqpanda import *
import math
import time

# ========================
# Parameters
# ========================
nx = 200
L = 2.0
dx = L / nx
cfl = 0.3
t_end = 0.5
nt_max = 1000
x = np.linspace(0, L, nx)

# Initial condition: square wave on [0.5, 1.0]
u_initial = np.zeros(nx)
u_initial[(x >= 0.5) & (x <= 1.0)] = 1.0



plt.style.use('seaborn-v0_8-paper')
rcParams.update({
    'font.family': 'sans-serif',
    'font.size': 12,
    'axes.titlesize': 14,
    'axes.labelsize': 12,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'figure.dpi': 300,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.1
})


# ========================
# Limiter functions (vectorized)
# ========================
def minmod(a, b):
    return np.where((a * b <= 0), 0, np.sign(a) * np.minimum(np.abs(a), np.abs(b)))


def preprocess_numbers(a, b, n_bits):

    max_val = max(abs(a), abs(b))
    if max_val == 0:
        return 0, 0, 1

    max_integer = (1 << n_bits) - 1
    F_max = max_integer / max_val

    # largest power of two not exceeding F_max
    if F_max < 1:
        F = 1
    else:
        exponent = math.floor(math.log2(F_max))
        F = 1 << exponent

    # scale and clamp
    A = round(a * F)
    B = round(b * F)
    A_clamped = min(max(A, -max_integer), max_integer)
    B_clamped = min(max(B, -max_integer), max_integer)

    return A_clamped, B_clamped, F


# In-place minmod circuit
def quantum_minmod_ip(a, b):
    bit_num = 7
    c = np.zeros(len(a))

    for i in range(len(a)):
        qvm = init_quantum_machine(QMachineType.CPU)
        prog = QProg()

        q_sign_a = qvm.qAlloc_many(1)
        q_sign_b = qvm.qAlloc_many(1)
        q_a = qvm.qAlloc_many(bit_num + 1)
        q_b = qvm.qAlloc_many(bit_num + 1)
        aux = qvm.qAlloc_many(1)

        # state preparation
        if a[i] < 0:
            prog << X(q_sign_a[0])
        if b[i] < 0:
            prog << X(q_sign_b[0])

        A_clamped, B_clamped, F = preprocess_numbers(abs(a[i]), abs(b[i]), bit_num)

        prog << bind_nonnegative_data(A_clamped, q_a)
        prog << bind_nonnegative_data(B_clamped, q_b)

        # sign_c = sign_a
        # sign_b steers the magnitude update
        prog << X(q_sign_a[0])
        prog << CNOT(q_sign_a[0], q_sign_b[0])
        prog << X(q_sign_a[0])

        prog << QAdderIgnoreCarry(q_b, q_a, aux[0]).dagger().control(q_sign_b[0])
        prog << QAdderIgnoreCarry(q_b[0:bit_num], q_a[0:bit_num], aux[0]).control(q_sign_b[0])

        prog << X(q_b[-1]).control(q_sign_b[0])

        prog << bind_nonnegative_data(B_clamped, q_b).control(q_sign_b[0]).control(q_b[-1])
        prog << QAdderIgnoreCarry(q_b[0:bit_num], q_a[0:bit_num], aux[0]).control(q_sign_b[0]).control(q_b[-1])

        prog << X(q_sign_b[0])
        prog << bind_nonnegative_data(B_clamped, q_b).control(q_sign_b[0])

        # result = prob_run_dict(prog, q_b[0:bit_num] + q_sign_a, 1)
        result = prob_run_dict(prog, q_b[0:bit_num] + q_sign_a, 1)
        binary_str = list(result.keys())[0]
        c[i] = int(binary_str, 2)
        if c[i] >= 2**bit_num:
            c[i] = -(c[i] - 2**bit_num)

        c[i] = c[i]/F
        finalize()

    return c


def quantum_minmod_op(a, b):

    bit_num = 5
    c = np.zeros(len(a))

    for i in range(len(a)):
        qvm = init_quantum_machine(QMachineType.CPU)
        prog = QProg()

        q_sign_a = qvm.qAlloc_many(1)
        q_sign_b = qvm.qAlloc_many(1)
        q_a = qvm.qAlloc_many(bit_num + 1)
        q_b = qvm.qAlloc_many(bit_num + 1)
        q_sign_c = qvm.qAlloc_many(1)
        q_c = qvm.qAlloc_many(bit_num)

        if a[i] < 0:
            prog << X(q_sign_a[0])
        if b[i] < 0:
            prog << X(q_sign_b[0])

        prog << bind_nonnegative_data(abs(round(a[i])), q_a)
        prog << bind_nonnegative_data(abs(round(b[i])), q_b)

        prog << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])
        prog << X(q_sign_a[0])
        prog << X(q_sign_b[0])
        prog << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])

        prog << QAdderIgnoreCarry(q_b, q_a, q_c[0]).dagger().control(q_sign_c[0])
        prog << QAdderIgnoreCarry(q_b[0:bit_num], q_a[0:bit_num], q_c[1]).control(q_sign_c[0])

        prog << QAdderIgnoreCarry(q_c, q_b[0:bit_num], q_a[-1]).control(q_sign_c[0]).control(q_b[-1])

        prog << X(q_b[-1])

        prog << QAdderIgnoreCarry(q_c, q_a[0:bit_num], q_a[-1]).control(q_sign_c[0]).control(q_b[-1])

        prog << X(q_b[-1])

        prog << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])
        prog << X(q_sign_a[0])
        prog << X(q_sign_b[0])
        prog << Toffoli(q_sign_a[0], q_sign_b[0], q_sign_c[0])

        prog << CNOT(q_sign_a[0], q_sign_c[0])

        result = prob_run_dict(prog, q_c + q_sign_c, 1)
        binary_str = list(result.keys())[0]
        c[i] = int(binary_str, 2)
        if c[i] >= 2**bit_num:
            c[i] = -(c[i] - 2**bit_num)

        finalize()

    return c


# ========================
# Time stepping (Lax-Friedrichs flux, periodic domain)
# ========================
def run_simulation(use_limiter=True, limiter_func=None):
    u = u_initial.copy()
    t = 0.0
    start_time = time.perf_counter()
    ii = 0
    for _ in range(nt_max):

        # time step from the CFL condition
        max_u = np.max(np.abs(u))
        dt = cfl * dx / max_u if max_u > 0 else cfl * dx
        dt = min(dt, t_end - t)
        if t >= t_end:
            break

        u_old = u.copy()
        u_L, u_R = np.zeros_like(u), np.zeros_like(u)

        # slopes
        du_L = (u_old[1:-1] - u_old[:-2]) / dx
        du_R = (u_old[2:] - u_old[1:-1]) / dx

        if use_limiter:
            # limited slope
            du = limiter_func(du_L, du_R)
        else:
            # unlimited: central difference
            du = 0.5 * (du_L + du_R)

        # interface values (MUSCL)
        u_L[1:-1] = u_old[1:-1] - 0.5 * dx * du
        u_R[1:-1] = u_old[1:-1] + 0.5 * dx * du

        # periodic boundary
        u_L[0], u_R[-1] = u_L[-2], u_R[1]
        u_L[-1], u_R[0] = u_L[1], u_R[-2]

        # Lax-Friedrichs flux
        ul, ur = u_R[:-1], u_L[1:]
        flux = 0.5 * (0.5 * ul ** 2 + 0.5 * ur ** 2) - 0.5 * (dx / (2 * dt)) * (ur - ul)

        # conservative update
        u[1:-1] = u_old[1:-1] + dt / dx * (flux[:-1] - flux[1:])


        u[0], u[-1] = u[-2], u[1]
        t += dt

        end_time = time.perf_counter()
        elapsed_time = end_time - start_time
        print(f"step {ii}: {elapsed_time:.6f} s, t = {t}, t_end = {t_end}")
        ii += 1

    return u


# Vector test cases for the circuit
def generate_vector_testcases(num_cases=500, vec_length=10):
    np.random.seed(42)
    cases = []

    for _ in range(num_cases):
        base = np.random.normal(0, 2, (2, vec_length))

        # inject degenerate cases: zero components and sign flips
        if np.random.rand() < 0.3:
            base[:, np.random.randint(vec_length)] = 0
        if np.random.rand() < 0.2:
            idx = np.random.randint(vec_length)
            base[0, idx] *= -1

        cases.append(base)

    return np.array(cases)


# Error metrics
def analyze_vector_results(standard, candidate):
    error = candidate - standard
    return {
        'component_mse': np.mean(error ** 2, axis=(0, 1)),
        'global_mse': np.mean(error ** 2),
        'max_abs_error': np.max(np.abs(error)),
        'error_correlation': stats.pearsonr(standard.flatten(), candidate.flatten())[0],
        'exact_match_rate': np.mean(np.isclose(standard, candidate, atol=1e-8))
    }


# Validation scatter plot
def plot_vector_comparison(standard, candidate, stats, vec_length=10):
    """Plot comparison between two vectors with error analysis.

    Args:
        standard: Reference array of shape (num_samples, vec_length)
        candidate: Test array of shape (num_samples, vec_length)
        stats: Dictionary containing error metrics
        vec_length: Expected length of each vector
    """

    assert standard.shape == candidate.shape, "shape mismatch"
    assert standard.shape[1] == vec_length, "vec_length mismatch"

    fig = plt.figure(constrained_layout=True, figsize=(12, 8))
    gs = fig.add_gridspec(3, 4)

    # ----------------------------
    # scatter: standard vs candidate
    # ----------------------------
    ax_main = fig.add_subplot(gs[:2, :2])
    error = np.abs(standard - candidate).flatten()

    data_min = min(standard.min(), candidate.min())
    data_max = max(standard.max(), candidate.max())
    ax_main.set_xlim(data_min - 0.5, data_max + 0.5)
    ax_main.set_ylim(data_min - 0.5, data_max + 0.5)

    sc = ax_main.scatter(
        standard.flatten(), candidate.flatten(),
        c=error,
        cmap='viridis', alpha=0.6,
        edgecolors='w', linewidths=0.3
    )
    ax_main.plot([data_min, data_max], [data_min, data_max], 'r--', lw=1)
    ax_main.set(
        xlabel="Standard Output",
        ylabel="Candidate Output",
        title=f"Component-wise Comparison (N={len(error)} points)"
    )
    plt.colorbar(sc, ax=ax_main, label="Absolute Error")

    # ----------------------------
    # error matrix
    # ----------------------------
    ax_matrix = fig.add_subplot(gs[0, 2:])
    error_matrix = np.abs(standard - candidate).T  # (vec_length, num_samples)

    x_edges = np.arange(error_matrix.shape[1] + 1)
    y_edges = np.arange(error_matrix.shape[0] + 1)

    pc = ax_matrix.pcolormesh(
        x_edges, y_edges, error_matrix,
        cmap='OrRd', shading='flat',
        edgecolors='k', linewidth=0.1
    )
    ax_matrix.set(
        xlabel="Test Case Index",
        ylabel="Vector Component",
        title="Error Matrix (Component vs. Case)",
        yticks=np.arange(vec_length) + 0.5,
        # yticklabels=[f"C{i}" for i in range(vec_length)]
    )
    plt.colorbar(pc, ax=ax_matrix, label="Absolute Error")

    # ----------------------------
    # per-component box plot
    # ----------------------------
    ax_stats = fig.add_subplot(gs[1, 2:])

    error_by_component = [
        np.abs(standard[:, i] - candidate[:, i])
        for i in range(vec_length)
    ]
    valid_components = [e for e in error_by_component if len(e) > 0]
    if not valid_components:
        raise ValueError("no valid error data")

    positions = np.arange(len(valid_components)) * 3
    bp = ax_stats.boxplot(
        valid_components,
        positions=positions,
        widths=0.8,
        patch_artist=True,
        boxprops=dict(facecolor='lightblue')
    )
    ax_stats.set(
        xticks=positions,
        xticklabels=[f'C{i}' for i in range(len(valid_components))],
        ylabel="Absolute Error",
        title="Component Error Distribution"
    )

    # ----------------------------
    # summary text
    # ----------------------------
    ax_text = fig.add_subplot(gs[2, :])
    required_stats = ['global_mse', 'max_abs_error', 'error_correlation', 'exact_match_rate']

    text_lines = []
    for k in required_stats:
        if k in stats:
            if k == 'exact_match_rate':
                text_lines.append(f"{k.replace('_', ' ').title()}: {stats[k] * 100:.1f}%")
            else:
                text_lines.append(f"{k.replace('_', ' ').title()}: {stats[k]:.2e}")
        else:
            text_lines.append(f"{k}: Missing")

    ax_text.text(
        0.5, 0.5, "\n".join(text_lines),
        ha='center', va='center', fontsize=12
    )
    ax_text.axis('off')

    output_path = 'vector_minmod_comparison.png'
    try:
        plt.savefig(output_path, bbox_inches='tight', dpi=150)
        print(f"saved: {output_path}")
    except Exception as e:
        print(f"save failed: {e}")
    finally:
        plt.close()

    return output_path


if __name__ == "__main__":
    # ========================
    u_high_order = run_simulation(use_limiter=False)
    # ========================
    print("Running simulations...")
    u_minmod = run_simulation(limiter_func=minmod)
    u_quantum_minmod = run_simulation(limiter_func=quantum_minmod_ip)

    # ========================

    # ========================
    plt.figure(figsize=(10, 6))
    plt.plot(x, u_initial, 'k:', lw=2, label='Initial')
    plt.plot(x, u_high_order, 'm--', lw=1.5, label='2-Order (No limiter)')
    plt.plot(x, u_minmod, 'b-', lw=1.2, label='Minmod')
    # plt.plot(x, u_superbee, 'r-', lw=1.2, label='Superbee')
    # plt.plot(x, u_vanleer, 'g-', lw=1, label='Van Leer')

    plt.plot(x, u_quantum_minmod,
             color='gold',
             linestyle=':',
             marker='o',
             markersize=4,
             markevery=5,
             alpha=0.7,
             label='Quantum_Minmod')

    plt.title('Burgers Equation: High-Order vs Limiters (t=0.5)')
    plt.xlabel('Position (x)')
    plt.ylabel('Velocity (u)')
    plt.legend()
    plt.grid(True)
    plt.xlim(0, 2)
    plt.show()

    VEC_LENGTH = 10
    TEST_CASES = 10


    test_data = generate_vector_testcases(TEST_CASES, VEC_LENGTH)
    standard_results = np.array([minmod(a, b) for a, b in test_data])
    candidate_results = np.array([quantum_minmod_ip(a, b) for a, b in test_data])

    stats = analyze_vector_results(standard_results, candidate_results)
    plot_vector_comparison(standard_results, candidate_results, stats, VEC_LENGTH)

    print("=== Vector Minmod Validation Report ===")
    print(f"Components: {VEC_LENGTH} | Test Cases: {TEST_CASES}")
    print("\nComponent MSE:")
    for i, mse in enumerate(np.atleast_1d(stats['component_mse'])):
        print(f"  Component {i}: {mse:.2e}")

    print("\nGlobal Metrics:")
    global_metrics = ['global_mse', 'max_abs_error', 'error_correlation', 'exact_match_rate']
    for k in ['global_mse', 'max_abs_error', 'error_correlation', 'exact_match_rate']:
        if k in stats:
            print(f"  {k.replace('_', ' ').title()}: {stats[k]:.4f}")
