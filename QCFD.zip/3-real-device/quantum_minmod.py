# -*- coding: utf-8 -*-
"""
Real-device minmod experiment on WK_C180_2.  The circuit is built with
the legacy pyqpanda, exported to OriginIR, loaded through pyqpanda3 and
submitted to the quantum cloud.
"""

import numpy as np

# ============================================================
# imports
# ============================================================
# legacy pyqpanda: circuit construction + OriginIR export
try:
    from pyqpanda import *
    HAS_PYQPANDA = True
except ImportError:
    HAS_PYQPANDA = False
    print("warning: pyqpanda not available")

# pyqpanda3: cloud submission
try:
    from pyqpanda3.intermediate_compiler import convert_originir_string_to_qprog
    from pyqpanda3.qcloud import QCloudOptions, QCloudService
    HAS_PYQPANDA3 = True
except ImportError:
    HAS_PYQPANDA3 = False
    print("warning: pyqpanda3 not available")

# ============================================================
# device configuration
# ============================================================
# insert your Origin Pilot API key here (not committed to the repo)
API_KEY = "XXXX"
CHIP_NAME = "WK_C180_2"
SHOTS = 1000

# ============================================================

# ============================================================

def minmod(a, b):
    """classical reference."""
    return np.where((a * b <= 0), 0, np.sign(a) * np.minimum(np.abs(a), np.abs(b)))


# ============================================================
# circuit construction and OriginIR export
# ============================================================

def build_circuit_originir(a, b, bit_num=2):
    """Build the minmod circuit, return the OriginIR string.

    Args:
        a, b: integers with |a|, |b| < 2^bit_num
        bit_num: magnitude register width

    Returns:
        returns: OriginIR string including the measurements
    """
    qvm = init_quantum_machine(QMachineType.CPU)
    prog = QProg()

    q_sign_a = qvm.qAlloc_many(1)
    q_sign_b = qvm.qAlloc_many(1)
    q_sign_c = qvm.qAlloc_many(1)
    q_a = qvm.qAlloc_many(bit_num + 1)
    q_b = qvm.qAlloc_many(bit_num + 1)
    q_c = qvm.qAlloc_many(bit_num)

    # sign encoding
    if a < 0:
        prog << X(q_sign_a[0])
    if b < 0:
        prog << X(q_sign_b[0])

    # magnitude encoding
    prog << bind_nonnegative_data(abs(a), q_a)
    prog << bind_nonnegative_data(abs(b), q_b)

    # sign_c = NOT(sign_a XOR sign_b)
    prog << CNOT(q_sign_a[0], q_sign_c[0])
    prog << CNOT(q_sign_b[0], q_sign_c[0])
    prog << X(q_sign_c[0])

    # compare |a| and |b| through the adder network
    prog << QAdderIgnoreCarry(q_b, q_a, q_c[0]).dagger().control(q_sign_c[0])
    prog << QAdderIgnoreCarry(q_b[0:bit_num], q_a[0:bit_num], q_c[0]).control(q_sign_c[0])

    # select the output magnitude, branch 1
    prog << Toffoli(q_b[-1], q_b[0], q_c[0])
    prog << Toffoli(q_b[-1], q_b[1], q_c[1])

    # select the output magnitude, branch 2
    prog << CNOT(q_sign_c[0], q_b[-1])
    prog << Toffoli(q_b[-1], q_a[0], q_c[0])
    prog << Toffoli(q_b[-1], q_a[1], q_c[1])
    prog << CNOT(q_sign_c[0], q_b[-1])

    # output sign
    prog << CNOT(q_sign_a[0], q_sign_c[0])
    prog << X(q_sign_c[0])

    # measurement
    clist = qvm.cAlloc_many(3)
    prog << measure_all(q_c, clist[0:bit_num])
    prog << Measure(q_sign_c[0], clist[2])

    # OriginIR export
    originir = convert_qprog_to_originir(prog, qvm)
    finalize()

    return originir


# ============================================================

# ============================================================

def decode_result(binary_str, bit_num=2):
    """Decode the measured bit string (sign-magnitude encoding)."""
    idx = int(binary_str, 2)
    mag = idx & ((1 << bit_num) - 1)
    sign = (idx >> bit_num) & 1
    return -mag if sign else mag


# ============================================================

# ============================================================

def run_experiment():
    """Run the real-device experiment."""
    print("=" * 60)
    print("Quantum minmod real-device experiment (WK_C180_2)")
    print("=" * 60)

    if not HAS_PYQPANDA:
        print("\nerror: pyqpanda is required")
        print("install: pip install pyqpanda")
        return

    if not HAS_PYQPANDA3:
        print("\nerror: pyqpanda3 is required")
        print("install: pip install pyqpanda3")
        return


    print(f"\ninitializing the pyqpanda3 cloud service...")
    print(f"  chip: {CHIP_NAME}")
    print(f"  shots: {SHOTS}")
    service = QCloudService(API_KEY)
    backend = service.backend(CHIP_NAME)
    options = QCloudOptions()
    print(f"  backend ready: {backend.name()}")

    # enumerate the input combinations
    values = np.arange(-3, 4)  # [-3, -2, -1, 0, 1, 2, 3]
    aa, bb = np.meshgrid(values, values)
    a_all = aa.flatten()
    b_all = bb.flatten()
    num_cases = len(a_all)

    print(f"\n>>> real-device test (2-bit Toffoli version, 11 qubits)")
    print(f"all combinations: {num_cases}")
    print(f"integer range: [-3, 3]\n")
    print("building circuits and submitting...\n")

    # output file
    output_path = "results.txt"
    header = f"{'#':>4}  {'a':>4}  {'b':>4}  {'classic':>8}  {'quantum':>8}  {'match':>6}"
    sep = "-" * 45

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("Real-device quantum minmod experiment results\n")
        f.write(f"config: 2-bit Toffoli version, 11 qubits, chip {CHIP_NAME}, {num_cases} cases\n")
        f.write(sep + "\n")
        f.write(header + "\n")
        f.write(sep + "\n")

        print(header)
        print(sep)

        match_count = 0
        for i in range(num_cases):
            a_val = int(a_all[i])
            b_val = int(b_all[i])
            classic_val = minmod(
                np.array([a_val]), np.array([b_val])
            )[0]

            # build circuit -> OriginIR
            originir = build_circuit_originir(a_val, b_val)

            # load into pyqpanda3
            prog_p3 = convert_originir_string_to_qprog(originir)

            # submit and wait
            print(f"[{i+1}/{num_cases}] submit a={a_val:>3}, b={b_val:>3} ...", end=" ", flush=True)
            job = backend.run(prog_p3, SHOTS, options)
            result = job.result()

            # most probable outcome
            probs = result.get_probs()
            best_key = max(probs, key=probs.get)
            quantum_val = decode_result(best_key)

            is_match = (classic_val == quantum_val)
            if is_match:
                match_count += 1
            match_str = "OK" if is_match else "FAIL"
            line = f"{i+1:>4}  {a_val:>4}  {b_val:>4}  {classic_val:>8}  {quantum_val:>8}  {match_str:>4}"
            print(f"{best_key} → {quantum_val:>3}  {match_str}")
            f.write(line + "\n")

        # summary
        rate = match_count / num_cases * 100
        summary = f"\n{match_count}/{num_cases} ({rate:.1f}%) exact matches"

        f.write(sep + "\n")
        f.write(summary + "\n")

        print(sep)
        print(summary)

    print(f"\nresults saved to: {output_path}")
    print("\n" + "=" * 60)
    print("done.")
    print("=" * 60)


if __name__ == "__main__":
    run_experiment()
