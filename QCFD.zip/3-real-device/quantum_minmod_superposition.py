"""Superposition-input minmod: CPUQVM simulation, classical
probability reference, and visualization."""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from collections import Counter
from pyqpanda import *

# ============================================================

# ============================================================
def margolus(qvm, c1, c2, t):
    prog = QProg()
    prog << RY(t, np.pi/4)
    prog << CNOT(c2, t)
    prog << RY(t, np.pi/4)
    prog << CNOT(c1, t)
    prog << RY(t, -np.pi/4)
    prog << CNOT(c2, t)
    prog << RY(t, -np.pi/4)
    return prog


# ============================================================
# superposition circuit
# ============================================================
# qubit map: a_m[0], a_s[1], b_m[2], b_s[3], c_m[4], c_s[5], aux[6], tmp[7]

def build_superposition_circuit(qvm, h_qubits, x_qubits):
    """
    h_qubits: input qubits put in superposition (subset of {0..3})
    x_qubits: input qubits fixed to |1> (subset of {0..3})
    remaining input qubits stay in |0>
    """
    prog = QProg()

    q = qvm.qAlloc_many(8)
    q_a_m, q_a_s = q[0], q[1]
    q_b_m, q_b_s = q[2], q[3]
    q_c_m, q_c_s = q[4], q[5]
    q_aux, q_tmp = q[6], q[7]

    c = qvm.cAlloc_many(2)

    # state preparation: H for superposition, X for fixed |1>
    for idx in h_qubits:
        prog << H(q[idx])
    for idx in x_qubits:
        if idx not in h_qubits:  # keep superposed qubits untouched
            prog << X(q[idx])

    # 2. signs_equal = NOT(sign_a XOR sign_b) → q_aux
    prog << CNOT(q_a_s, q_aux)
    prog << CNOT(q_b_s, q_aux)
    prog << X(q_aux)

    # Margolus chain
    prog << margolus(qvm, q_aux, q_a_m, q_tmp)
    prog << margolus(qvm, q_tmp, q_b_m, q_c_m)
    prog << margolus(qvm, q_aux, q_a_m, q_tmp)

    # 4. sign_out
    prog << margolus(qvm, q_aux, q_a_s, q_c_s)

    # measurement
    prog << Measure(q_c_m, c[0])
    prog << Measure(q_c_s, c[1])

    return prog, c


# ============================================================
# decoding
# ============================================================
def decode_result(binary_str):
    idx = int(binary_str, 2)
    mag = idx & 1
    sign = (idx >> 1) & 1
    return -mag if sign else mag


# ============================================================
# classical probability reference
# ============================================================
def minmod_classic(a_val, b_val):
    if a_val * b_val <= 0:
        return 0
    return int(np.sign(a_val)) * min(abs(a_val), abs(b_val))


def compute_classical_distribution(h_qubits, x_qubits):
    """
    Enumerate all input basis states and collect the minmod output
    distribution.  h_qubits are superposed (weight 1/2^|h|), x_qubits
    are fixed to |1>, the rest stay |0>.
    """
    n_super = len(h_qubits)
    dist = Counter()

    # bit idx of {0..3}: drawn from the basis state if in h_qubits
    #   idx in x_qubits → 1
    #   else → 0
    for state_idx in range(1 << n_super):
        h_vals = {}
        for i, q_idx in enumerate(sorted(h_qubits)):
            h_vals[q_idx] = (state_idx >> i) & 1

        a_m = h_vals.get(0, 1 if 0 in x_qubits else 0)
        a_s = h_vals.get(1, 1 if 1 in x_qubits else 0)
        b_m = h_vals.get(2, 1 if 2 in x_qubits else 0)
        b_s = h_vals.get(3, 1 if 3 in x_qubits else 0)

        a_val = -a_m if a_s else a_m
        b_val = -b_m if b_s else b_m

        result = minmod_classic(a_val, b_val)
        if result == 0:
            # circuit: sign_out = signs_equal AND sign_a
            signs_equal = 1 - (a_s ^ b_s)  # NOT(XOR)
            sign_out = signs_equal & a_s
            key_str = f"{sign_out}0"  # mag=0, sign=sign_out
        else:
            key_str = f"{(1 if result < 0 else 0)}{abs(result)}"
        dist[key_str] += 1

    # normalize
    total = 1 << n_super
    return {k: v / total for k, v in dist.items()}


# ============================================================
# simulation
# ============================================================
def run_quantum_simulation(h_qubits, x_qubits, shots=10000):
    qvm = init_quantum_machine(QMachineType.CPU)
    prog, c = build_superposition_circuit(qvm, h_qubits, x_qubits)
    counts = qvm.run_with_configuration(prog, c, shots)
    finalize()
    total = shots  # pyqpanda shadows the builtin sum
    return {k: v / total for k, v in counts.items()}


# ============================================================
# experiments
# ============================================================
EXPERIMENTS = [
    # A: a superposed, b = +1
    {"id": "A1", "title": "a: sign in H (a∈{+1,-1}), b=+1",
     "h_qubits": {1}, "x_qubits": {0, 2}},  # H(sign_a), X(mag_a=1, mag_b=1)
    {"id": "A2", "title": "a: mag in H (a∈{0,+1}), b=+1",
     "h_qubits": {0}, "x_qubits": {2}},     # H(mag_a), X(mag_b=1)
    {"id": "A3", "title": "a: full H (a∈{+0,+1,-0,-1}), b=+1",
     "h_qubits": {0, 1}, "x_qubits": {2}},  # H(mag_a, sign_a), X(mag_b=1)

    # B: b superposed, a = +1
    {"id": "B1", "title": "b: sign in H (b∈{+1,-1}), a=+1",
     "h_qubits": {3}, "x_qubits": {0, 2}},  # H(sign_b), X(mag_a=1, mag_b=1)
    {"id": "B2", "title": "b: mag in H (b∈{0,+1}), a=+1",
     "h_qubits": {2}, "x_qubits": {0}},     # H(mag_b), X(mag_a=1)
    {"id": "B3", "title": "b: full H (b∈{+0,+1,-0,-1}), a=+1",
     "h_qubits": {2, 3}, "x_qubits": {0}},  # H(mag_b, sign_b), X(mag_a=1)

    # C: both superposed
    {"id": "C1", "title": "both sign in H (a,b∈{+1,-1})",
     "h_qubits": {1, 3}, "x_qubits": {0, 2}},  # H(sign_a, sign_b), X(mag_a=1, mag_b=1)
    {"id": "C2", "title": "both full in H (all 4 inputs)",
     "h_qubits": {0, 1, 2, 3}, "x_qubits": set()},  # H on all 4 inputs
]


# ============================================================

# ============================================================
def run_all():
    print("=" * 70)
    print("Superposition minmod: CPUQVM vs classical distribution")
    print("=" * 70)

    all_results = []

    for exp in EXPERIMENTS:
        h = exp["h_qubits"]
        x = exp["x_qubits"]
        print(f"\n[{exp['id']}] {exp['title']}")
        print(f"  H on: {sorted(h)}, X on: {sorted(x)}")

        # classical reference
        classical = compute_classical_distribution(h, x)
        # quantum simulation
        quantum = run_quantum_simulation(h, x, shots=10000)

        # union of keys
        all_keys = sorted(set(list(classical.keys()) + list(quantum.keys())))

        print(f"  {'key':>4}  {'classic':>8}  {'quantum':>8}")
        for k in all_keys:
            cv = classical.get(k, 0)
            qv = quantum.get(k, 0)
            print(f"  {k:>4}  {cv:7.2%}  {qv:7.2%}")

        # fidelity
        fidelity = 0.0
        for k in all_keys:
            fidelity += classical.get(k, 0) if classical.get(k, 0) < quantum.get(k, 0) else quantum.get(k, 0)
        print(f"  Classical fidelity: {fidelity:.4f}")

        all_results.append({
            "exp": exp,
            "classical": classical,
            "quantum": quantum,
            "all_keys": all_keys,
            "fidelity": fidelity,
        })

    print(f"\n{'=' * 70}")
    ok = all(r["fidelity"] > 0.98 for r in all_results)
    print(f"Verification: {'ALL PASS' if ok else 'SOME FAIL'}")
    return all_results


# ============================================================

# ============================================================
OUTPUT_LABELS = {"00": "0\n(00)", "10": "0\n(10)", "01": "+1\n(01)", "11": "-1\n(11)"}

def plot_results(results):
    n = len(results)
    cols = 3
    rows = (n + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(14, 4 * rows))
    axes = axes.flatten()

    bar_width = 0.35
    colors_classic = '#4C72B0'
    colors_quantum = '#DD8452'

    for i, res in enumerate(results):
        ax = axes[i]
        exp = res["exp"]
        classical = res["classical"]
        quantum = res["quantum"]
        all_keys = res["all_keys"]

        labels = [OUTPUT_LABELS.get(k, k) for k in all_keys]
        x = np.arange(len(labels))
        cv = [classical.get(k, 0) for k in all_keys]
        qv = [quantum.get(k, 0) for k in all_keys]

        ax.bar(x - bar_width/2, cv, bar_width, color=colors_classic, alpha=0.9,
               edgecolor='white', linewidth=0.5, label='Classical')
        ax.bar(x + bar_width/2, qv, bar_width, color=colors_quantum, alpha=0.9,
               edgecolor='white', linewidth=0.5, label='Quantum')

        ax.set_xticks(x)
        ax.set_xticklabels(labels)
        ax.set_ylabel('Probability')
        ax.set_title(f"[{exp['id']}] {exp['title']}", fontsize=9, fontweight='bold')
        ax.set_ylim(0, max(max(cv), max(qv)) * 1.25)
        ax.set_xlabel(f"Fidelity={res['fidelity']:.4f}")

        if i == 0:
            ax.legend(loc='upper left', fontsize=7, framealpha=0.9)

    # hide unused panels
    for j in range(n, len(axes)):
        axes[j].set_visible(False)

    plt.tight_layout()
    plt.savefig("results_superposition_8cases.png", dpi=200, bbox_inches='tight')
    plt.close()
    print("\nSaved: results_superposition_8cases.png")


if __name__ == "__main__":
    results = run_all()
    plot_results(results)
