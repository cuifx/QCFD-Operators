"""2-bit quantum minmod hardware results (WK_C180_2) -- figure scripts.

Figure 1: results_2bit_v11_wk2_success_matrix.png
    7x7 heatmap of target-state probability (%) for all input combos
    a, b in {-3..3}, 3000 shots per case. Reads results_2bit_wk2_matrix.json.

Figure 2: results_2bit_superposition_wk2.png
    Superposition-input tests (E1: 2 states, E2: 4 states, E3: 64 states),
    classical prediction vs quantum measurement. Requires the raw per-key
    probability file results_2bit_wk2_superposition.json (downloaded from
    the quantum cloud task results); the figure is skipped if not present.

Usage:
    python plot_2bit_results.py
"""

import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from collections import Counter

plt.rcParams["font.family"] = "DejaVu Sans"
plt.rcParams["axes.unicode_minus"] = False

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))


# ============================================================
# Figure 1: 7x7 success-probability matrix
# ============================================================
def plot_success_matrix():
    path = os.path.join(OUTPUT_DIR, "results_2bit_wk2_matrix.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    vals = np.array(data["values"], dtype=float)  # rows = b (+3..-3), cols = a (-3..+3)
    labels = ["-3", "-2", "-1", "+0", "+1", "+2", "+3"]
    ylabels = ["+3", "+2", "+1", "+0", "-1", "-2", "-3"]  # row 0 = b = +3

    fig, ax = plt.subplots(figsize=(11, 10))
    im = ax.imshow(vals, cmap="RdYlGn", vmin=0, vmax=38, aspect="equal")

    for i in range(7):
        for j in range(7):
            ax.text(j, i, f"{vals[i, j]:.2f}%",
                    ha="center", va="center", fontsize=12,
                    fontweight="bold", color="black")

    ax.set_xticks(range(7), labels, fontsize=13)
    ax.set_yticks(range(7), ylabels, fontsize=13)
    ax.set_xlabel("a", fontsize=14)
    ax.set_ylabel("b", fontsize=14)

    # white grid lines between cells
    ax.set_xticks(np.arange(-0.5, 7, 1), minor=True)
    ax.set_yticks(np.arange(-0.5, 7, 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=2.5)
    ax.tick_params(which="minor", length=0)

    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label("Success probability (%)", fontsize=13)

    fig.tight_layout()
    out = os.path.join(OUTPUT_DIR, "results_2bit_v11_wk2_success_matrix.png")
    fig.savefig(out, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {out}")


# ============================================================
# Figure 2: superposition-input tests (needs raw key-level data)
# ============================================================
# Experiment definitions (identical to quantum_minmod_2bit.py submission):
#   E1: a magnitude low bit in H (a in {0,1}), b = +2  -> 2 states
#   E2: a magnitude full H (a in {0..3}), b = +3       -> 4 states
#   E3: a, b both full H (signs included)              -> 64 states
EXPERIMENTS = [
    {"id": "E1", "h_mag_a": [0], "h_sign_a": [], "h_mag_b": [], "h_sign_b": [],
     "b": 2, "title": "[E1] a: mag low-bit H (a in {0,1}, 2 states), b=+2"},
    {"id": "E2", "h_mag_a": [0, 1], "h_sign_a": [], "h_mag_b": [], "h_sign_b": [],
     "b": 3, "title": "[E2] a: mag H (a in {0..3}, 4 states), b=+3"},
    {"id": "E3", "h_mag_a": [0, 1], "h_sign_a": [0], "h_mag_b": [0, 1], "h_sign_b": [0],
     "b": None, "title": "[E3] a,b: full H (64 states)"},
]


def minmod_classic(a_val, b_val):
    if a_val * b_val <= 0:
        return 0
    return int(np.sign(a_val)) * min(abs(a_val), abs(b_val))


def compute_classical_distribution(exp):
    """Classical output distribution over sign|mag 3-bit keys."""
    h_mag_a, h_sign_a = exp["h_mag_a"], exp["h_sign_a"]
    h_mag_b, h_sign_b = exp["h_mag_b"], exp["h_sign_b"]
    n_super = len(h_mag_a) + len(h_sign_a) + len(h_mag_b) + len(h_sign_b)
    dist = Counter()
    for state_idx in range(1 << n_super):
        bit = 0

        def draw(spec):
            nonlocal bit
            v = {}
            for name in spec:
                v[name] = {}
                for q in spec[name]:
                    v[name][q] = (state_idx >> bit) & 1
                    bit += 1
            return v

        d = draw([("ma", h_mag_a), ("sa", h_sign_a), ("mb", h_mag_b), ("sb", h_sign_b)])
        # a magnitude qubits: q0 LSB, q1 MSB; unspecified -> a = 0
        a0 = d["ma"].get(0, 0)
        a1 = d["ma"].get(1, 0)
        a_mag = a0 + 2 * a1
        a_s = d["sa"].get(0, 0)
        b1 = d["mb"].get(1, 1) if exp["b"] is not None else d["mb"].get(1, 0)
        b0 = d["mb"].get(0, 1) if exp["b"] is not None else d["mb"].get(0, 0)
        if exp["b"] is not None:
            b_mag = abs(exp["b"])
        else:
            b_mag = b0 + 2 * b1
        b_s = d["sb"].get(0, 0)
        a_val = -a_mag if a_s else a_mag
        b_val = -b_mag if b_s else b_mag
        result = minmod_classic(a_val, b_val)
        if result == 0:
            signs_equal = 1 - (a_s ^ b_s)
            sign_out = signs_equal & a_s
            key = f"{sign_out}{a_mag:02b}"
        else:
            key = f"{1 if result < 0 else 0}{abs(result):02b}"
        dist[key] += 1
    total = 1 << n_super
    return {k: v / total for k, v in dist.items()}


def key_label(k):
    sign = int(k[0])
    mag = int(k[1:], 2)
    val = -mag if sign else mag
    return f"{val:+d}\n({k})"


def plot_superposition():
    path = os.path.join(OUTPUT_DIR, "results_2bit_wk2_superposition.json")
    if not os.path.exists(path):
        print("Skipped superposition figure: results_2bit_wk2_superposition.json "
              "(raw per-key probabilities from the cloud tasks) not found.")
        return

    with open(path, encoding="utf-8") as f:
        raw = json.load(f)

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    bar_width = 0.35
    color_classic = "#4C72B0"
    color_quantum = "#DD8452"

    for ax, exp in zip(axes, EXPERIMENTS):
        classical = compute_classical_distribution(exp)
        quantum = raw.get(exp["id"], {})
        all_keys = sorted(set(list(classical.keys()) + list(quantum.keys())))

        fidelity = sum(min(classical.get(k, 0), quantum.get(k, 0)) for k in all_keys)

        labels = [key_label(k) for k in all_keys]
        x = np.arange(len(labels))
        cv = [classical.get(k, 0) for k in all_keys]
        qv = [quantum.get(k, 0) for k in all_keys]

        ax.bar(x - bar_width / 2, cv, bar_width, color=color_classic,
               label="Classical")
        ax.bar(x + bar_width / 2, qv, bar_width, color=color_quantum,
               label="Quantum (Real)")
        ax.set_xticks(x, labels, fontsize=7)
        ax.set_ylabel("Probability")
        ax.set_title(exp["title"], fontsize=9, fontweight="bold")
        ax.set_ylim(0, max(max(cv), max(qv)) * 1.2)
        ax.text(0.98, 0.95, f"F={fidelity:.3f}", transform=ax.transAxes,
                ha="right", va="top", fontsize=8,
                bbox=dict(boxstyle="round,pad=0.2", facecolor="lightgray", alpha=0.7))
        if exp["id"] == "E1":
            ax.legend(loc="upper left", fontsize=7)

    plt.tight_layout()
    out = os.path.join(OUTPUT_DIR, "results_2bit_superposition_wk2.png")
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {out}")


if __name__ == "__main__":
    plot_success_matrix()
    plot_superposition()
