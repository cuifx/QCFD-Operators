"""1-bit minmod with Margolus gates in place of Toffoli gates."""
import numpy as np
from pyqpanda import *

def margolus(qvm, c1, c2, t):
    """
    Margolus gate: reduced-depth Toffoli for computational-basis
    inputs, ~5 layers, 3 CNOT + 4 RY(+/-pi/4).
    """
    prog = QProg()
    prog << RY(t, np.pi/4)
    prog << CNOT(c2, t)
    prog << RY(t, np.pi/4)
    prog << CNOT(c1, t)
    prog << RY(t, -np.pi/4)
    prog << CNOT(c2, t)
    prog << RY(t, -np.pi/4)
    return prog


def build_circuit_margolus(qvm, a, b):
    """Build the Margolus-based 1-bit minmod circuit, return (prog, cbits)."""
    prog = QProg()

    q = qvm.qAlloc_many(8)
    q_a_m, q_a_s = q[0], q[1]
    q_b_m, q_b_s = q[2], q[3]
    q_c_m, q_c_s = q[4], q[5]
    q_aux, q_tmp = q[6], q[7]

    c = qvm.cAlloc_many(2)

    # input encoding
    if abs(a) == 1:
        prog << X(q_a_m)
    if a < 0:
        prog << X(q_a_s)
    if abs(b) == 1:
        prog << X(q_b_m)
    if b < 0:
        prog << X(q_b_s)

    # 2. signs_equal = NOT(sign_a XOR sign_b) → q_aux
    prog << CNOT(q_a_s, q_aux)
    prog << CNOT(q_b_s, q_aux)
    prog << X(q_aux)

    # mag_out = signs_equal AND |a| AND |b|  (Margolus gates)
    prog << margolus(qvm, q_aux, q_a_m, q_tmp)  # tmp = aux & |a|
    prog << margolus(qvm, q_tmp, q_b_m, q_c_m)  # c_m = tmp & |b|
    prog << margolus(qvm, q_aux, q_a_m, q_tmp)  # uncompute tmp

    # sign_out = signs_equal AND sign_a
    prog << margolus(qvm, q_aux, q_a_s, q_c_s)

    # measurement
    prog << Measure(q_c_m, c[0])
    prog << Measure(q_c_s, c[1])

    return prog, c


def decode_result(binary_str):
    idx = int(binary_str, 2)
    mag = idx & 1
    sign = (idx >> 1) & 1
    return -mag if sign else mag


def local_verify():
    values = [-1, 0, 1]
    match_count = 0

    print("=" * 55)
    print("1-bit minmod (Margolus version), local CPUQVM validation")
    print("=" * 55)

    for a in values:
        for b in values:
            classic = int(np.where((a*b <= 0), 0, np.sign(a) * min(abs(a), abs(b))))

            qvm = init_quantum_machine(QMachineType.CPU)
            prog, c = build_circuit_margolus(qvm, a, b)
            counts = qvm.run_with_configuration(prog, c, 1)
            key = list(counts.keys())[0]
            quantum_val = decode_result(key)
            ok = (classic == quantum_val)
            if ok:
                match_count += 1
            print(f"  a={a:>3}, b={b:>3} | classic={classic:>3} | quantum={quantum_val:>3} ({key}) | {'OK' if ok else 'FAIL'}")
            finalize()

    print(f"\nmatches: {match_count}/9")
    return match_count == 9


def build_circuit_originir_margolus(a, b):
    """Export the Margolus circuit to OriginIR."""
    qvm = init_quantum_machine(QMachineType.CPU)
    prog, _ = build_circuit_margolus(qvm, a, b)
    originir = convert_qprog_to_originir(prog, qvm)
    finalize()
    return originir


if __name__ == "__main__":
    ok = local_verify()
    print(f"\n=== {'all correct' if ok else 'mismatches found'} ===")

    if ok:
        # resource summary
        originir = build_circuit_originir_margolus(1, 1)
        lines = [l.strip() for l in originir.split('\n') if l.strip()]
        gate_lines = [l for l in lines if not l.startswith('QINIT') and not l.startswith('CREG')]

        n_cnot = len([l for l in gate_lines if 'CNOT' in l])
        n_x = len([l for l in gate_lines if l.startswith('X')])
        n_ry = len([l for l in gate_lines if 'RY' in l])
        n_measure = len([l for l in gate_lines if 'MEASURE' in l])

        print(f"\n=== Margolus version resource summary ===")
        print(f"  CNOT:    {n_cnot}")
        print(f"  RY:      {n_ry}")
        print(f"  X:       {n_x}")
        print(f"  MEASURE: {n_measure}")
        print(f"  total gates: {len(gate_lines)}")
        print(f"  CNOT-equivalent: {n_cnot} (original ~26)")
        print(f"  CNOT reduction: {(1 - n_cnot/26)*100:.0f}%")
        print(f"\n  === comparison ===")
        print(f"                    original   Margolus")
        print(f"  CNOT (XOR part):        2            2")
        print(f"  CNOT (Toffoli part):   24          {n_cnot-2}")
        print(f"  total CNOT:            26          {n_cnot}")
        print(f"  RY gates:               0          {n_ry}")
