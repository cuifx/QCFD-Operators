# -*- coding: utf-8 -*-
"""
1-bit minmod, gate-level version: 8 qubits, 2 CNOT + 4 Toffoli + ~5 X.
"""

import numpy as np

try:
    from pyqpanda import *
    HAS_PYQPANDA = True
except ImportError:
    HAS_PYQPANDA = False

try:
    from pyqpanda3.intermediate_compiler import convert_originir_string_to_qprog
    from pyqpanda3.qcloud import QCloudOptions, QCloudService
    HAS_PYQPANDA3 = True
except ImportError:
    HAS_PYQPANDA3 = False


def minmod_classic(a, b):
    return np.where((a * b <= 0), 0, np.sign(a) * np.minimum(np.abs(a), np.abs(b)))


def build_circuit_1bit(qvm, a, b):
    """Build the 1-bit minmod circuit, return (prog, cbits)."""
    prog = QProg()
    
    q = qvm.qAlloc_many(8)
    q_a_m, q_a_s = q[0], q[1]
    q_b_m, q_b_s = q[2], q[3]
    q_c_m, q_c_s = q[4], q[5]
    q_aux, q_tmp = q[6], q[7]
    
    c = qvm.cAlloc_many(2)
    
    # input encoding
    if abs(a) == 1:  prog << X(q_a_m)
    if a < 0:        prog << X(q_a_s)
    if abs(b) == 1:  prog << X(q_b_m)
    if b < 0:        prog << X(q_b_s)
    
    # 2. signs_equal = NOT(sign_a XOR sign_b) → q_aux
    prog << CNOT(q_a_s, q_aux)
    prog << CNOT(q_b_s, q_aux)
    prog << X(q_aux)
    
    # 3. mag_out = signs_equal AND |a| AND |b|
    prog << Toffoli(q_aux, q_a_m, q_tmp)   # tmp = aux & |a|
    prog << Toffoli(q_tmp, q_b_m, q_c_m)   # c_m = tmp & |b|
    prog << Toffoli(q_aux, q_a_m, q_tmp)   # uncompute tmp
    
    # 4. sign_out = signs_equal AND sign_a
    prog << Toffoli(q_aux, q_a_s, q_c_s)
    
    # measurement
    prog << Measure(q_c_m, c[0])
    prog << Measure(q_c_s, c[1])
    
    return prog, c


def decode_result(binary_str):
    idx = int(binary_str, 2)
    mag = idx & 1
    sign = (idx >> 1) & 1
    return -mag if sign else mag


def build_circuit_originir(a, b):
    """Export the circuit to OriginIR for device submission."""
    qvm = init_quantum_machine(QMachineType.CPU)
    prog, _ = build_circuit_1bit(qvm, a, b)
    originir = convert_qprog_to_originir(prog, qvm)
    finalize()
    return originir


def local_verify():
    """Local CPUQVM validation over the 9 input combinations."""
    print("=" * 55)
    print("1-bit minmod, local CPUQVM validation (gate level, 9 cases)")
    print("=" * 55)
    
    values = [-1, 0, 1]
    match_count = 0
    
    for a in values:
        for b in values:
            classic = int(minmod_classic(np.array([a]), np.array([b]))[0])
            
            qvm = init_quantum_machine(QMachineType.CPU)
            prog, c = build_circuit_1bit(qvm, a, b)
            counts = qvm.run_with_configuration(prog, c, 1)
            key = list(counts.keys())[0]
            quantum_val = decode_result(key)
            ok = (classic == quantum_val)
            if ok: match_count += 1
            print(f"  a={a:>3}, b={b:>3} | classic={classic:>3} | quantum={quantum_val:>3} ({key}) | {'OK' if ok else 'FAIL'}")
            finalize()
    
    print(f"\n  matches: {match_count}/9")
    
    # resource estimate
    originir = build_circuit_originir(1, 1)
    lines = [l.strip() for l in originir.split('\n') if l.strip()]
    gate_lines = [l for l in lines if not l.startswith('QINIT') and not l.startswith('CREG')]
    
    n_cnot = len([l for l in gate_lines if 'CNOT' in l])
    n_toffoli = len([l for l in gate_lines if 'TOFFOLI' in l])
    n_x = len([l for l in gate_lines if l.startswith('X')])
    n_measure = len([l for l in gate_lines if 'MEASURE' in l])
    
    # Toffoli decomposition: ~6 CNOT + 7 single-qubit gates ~ 13 layers
    toffoli_depth = 13
    est_cnot_total = n_cnot + n_toffoli * 6
    est_depth = n_x + n_cnot + n_toffoli * toffoli_depth + n_measure
    
    print(f"\n  === 1-bit resource summary ===")
    print(f"  qubits: 8  (a_m, a_s, b_m, b_s, c_m, c_s, aux, tmp)")
    print(f"  classical registers: 2")
    print(f"  CNOT:    {n_cnot}")
    print(f"  TOFFOLI: {n_toffoli}  (≈{n_toffoli*6} CNOT)")
    print(f"  X:       {n_x}")
    print(f"  MEASURE: {n_measure}")
    print(f"  CNOT-equivalent total: ~{est_cnot_total}")
    print(f"  estimated depth: ~{est_depth} layers")
    print(f"  OriginIR lines: {len(gate_lines)}")
    
    print(f"\n  === comparison with the 2-bit version ===")
    print(f"                             2-bit          1-bit")
    print(f"  qubits:                       11              8")
    print(f"  CNOT-equivalent:            ~289            ~{est_cnot_total}")
    print(f"  depth:                     ~488 layers     ~{est_depth} layers")
    print(f"  test cases:                   49              9")
    print(f"  depth reduction:              --            {(1-est_depth/488)*100:.0f}%")
    print(f"  CNOT reduction:               --            {(1-est_cnot_total/289)*100:.0f}%")
    
    return match_count == 9


if __name__ == "__main__":
    ok = local_verify()
    print(f"\n=== {'all correct' if ok else 'mismatches found'} ===")
