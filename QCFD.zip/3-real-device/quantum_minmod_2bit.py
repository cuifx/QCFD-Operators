# -*- coding: utf-8 -*-
"""
2-bit minmod, generic adder-comparator architecture (n = 2).

Circuit (following quantum_minmod.py):
  1. sign-magnitude encoding (3 sign qubits)
  2. signs_equal = NOT(sign_a XOR sign_b) → sign_c
  3. controlled 2-bit subtractor (QAdderIgnoreCarry.dagger), borrow in b_extra
  4. controlled adder restores |a>
  5. borrow drives the Toffoli selection -> output
  6. output sign = sign_c AND sign_a
  7. measurement

qubit layout (11 qubits):
  sign_a[0], sign_b[0], sign_c[0]  (3 symbol qubits)
  a[0], a[1], a[2]                  magnitude + extra bit
  b[0], b[1], b[2]                  magnitude + extra bit / borrow
  c[0], c[1]                        output magnitude

Goal: 49/49 correct on the local CPUQVM before simplification.
"""

import numpy as np
import re
from collections import Counter

try:
    from pyqpanda import *
    HAS_PYQPANDA = True
except ImportError:
    HAS_PYQPANDA = False
    print("warning: pyqpanda not available")


def M(qvm, c1, c2, t):
    """Margolus gate: reduced-depth Toffoli, 3 CNOT + 4 RY."""
    p = QProg()
    p << RY(t,  np.pi/4) << CNOT(c2, t) << RY(t,  np.pi/4)
    p << CNOT(c1, t) << RY(t, -np.pi/4) << CNOT(c2, t) << RY(t, -np.pi/4)
    return p


def minmod_classic(a, b):
    """Classical minmod."""
    if a * b <= 0:
        return 0
    return int(np.sign(a)) * min(abs(a), abs(b))


def decode_result(binary_str, bit_num=2):
    """Decode the measured bit string (sign-magnitude)."""
    idx = int(binary_str, 2)
    mag = idx & ((1 << bit_num) - 1)
    sign = (idx >> bit_num) & 1
    return -mag if sign else mag


def build_circuit_2bit(qvm, a, b):
    """Build the 2-bit minmod circuit (adder architecture).

    Args:
        qvm: quantum virtual machine
        a, b: inputs in [-3, 3]

    Returns:
        prog: circuit
        c_reg: classical registers (c[0..1] magnitude, c[2] sign)
    """
    bit_num = 2
    prog = QProg()

    # qubit allocation
    q_sign_a = qvm.qAlloc_many(1)
    q_sign_b = qvm.qAlloc_many(1)
    q_sign_c = qvm.qAlloc_many(1)
    q_a = qvm.qAlloc_many(bit_num + 1)   # 3 qubits: a0, a1, a_extra
    q_b = qvm.qAlloc_many(bit_num + 1)   # b0, b1, b_extra (borrow)
    q_c = qvm.qAlloc_many(bit_num)       # output magnitude

    # sign encoding
    if a < 0:
        prog << X(q_sign_a[0])
    if b < 0:
        prog << X(q_sign_b[0])

    # magnitude encoding
    prog << bind_nonnegative_data(abs(a), q_a)
    prog << bind_nonnegative_data(abs(b), q_b)

    # sign_c = NOT(sign_a XOR sign_b)
    prog << CNOT(q_sign_a[0], q_sign_c[0])
    prog << CNOT(q_sign_b[0], q_sign_c[0])
    prog << X(q_sign_c[0])

    # controlled subtraction |a> -= |b> when sign_c = 1;
    # borrow stored in q_b[bit_num]

    prog << QAdderIgnoreCarry(q_b, q_a, q_c[0]).dagger().control(q_sign_c[0])

    # controlled add restores |a> (without the borrow bit)

    prog << QAdderIgnoreCarry(q_b[0:bit_num], q_a[0:bit_num], q_c[0]).control(q_sign_c[0])

    # selection driven by the borrow qubit
    # borrow = 1: |a| < |b|, select |b|
    # borrow = 0: |a| >= |b|, select |a|

    # branch 1: borrow = 1, select |b|
    prog << M(qvm, q_b[-1], q_b[0], q_c[0])
    prog << M(qvm, q_b[-1], q_b[1], q_c[1])

    # branch 2: borrow = 0, select |a|
    # flip the borrow when sign_c = 1
    prog << CNOT(q_sign_c[0], q_b[-1])
    prog << M(qvm, q_b[-1], q_a[0], q_c[0])
    prog << M(qvm, q_b[-1], q_a[1], q_c[1])
    prog << CNOT(q_sign_c[0], q_b[-1])  # restore the borrow

    # final sign: same sign -> sign_a;
    # opposite signs: magnitude is zero, the sign bit is irrelevant

    prog << CNOT(q_sign_a[0], q_sign_c[0])
    prog << X(q_sign_c[0])

    # measurement
    c_reg = qvm.cAlloc_many(3)
    prog << measure_all(q_c, c_reg[0:bit_num])
    prog << Measure(q_sign_c[0], c_reg[2])

    return prog, c_reg


def run_local_test():
    """Local CPUQVM validation over the 49 combinations."""
    print("=" * 60)
    print("2-bit minmod local validation (adder architecture)")
    print("=" * 60)

    if not HAS_PYQPANDA:
        print("error: pyqpanda is required")
        return

    values = np.arange(-3, 4)  # [-3, -2, -1, 0, 1, 2, 3]
    aa, bb = np.meshgrid(values, values)
    a_all = aa.flatten()
    b_all = bb.flatten()
    num_cases = len(a_all)

    header = f"{'#':>4}  {'a':>4}  {'b':>4}  {'classic':>6}  {'quantum':>6}  {'match':>6}"
    print(header)
    print("-" * 45)

    match_count = 0
    for i in range(num_cases):
        a_val, b_val = int(a_all[i]), int(b_all[i])
        classic_val = minmod_classic(a_val, b_val)

        qvm = init_quantum_machine(QMachineType.CPU)
        prog, c_reg = build_circuit_2bit(qvm, a_val, b_val)

        # one shot, noiseless
        result = qvm.run_with_configuration(prog, c_reg, 1)
        best_key = list(result.keys())[0]
        quantum_val = decode_result(best_key)

        is_match = (classic_val == quantum_val)
        if is_match:
            match_count += 1
        match_str = "OK" if is_match else "FAIL"

        print(f"{i+1:>4}  {a_val:>4}  {b_val:>4}  {classic_val:>6}  {quantum_val:>6}  {match_str:>4}")

        finalize()

    print("-" * 45)
    rate = match_count / num_cases * 100
    print(f"{match_count}/{num_cases} ({rate:.1f}%) exact matches")

    return match_count == num_cases


def run_local_test_detailed():
    """Local validation with detailed failure listing."""
    print("=" * 60)
    print("2-bit minmod local validation (detailed)")
    print("=" * 60)

    if not HAS_PYQPANDA:
        print("error: pyqpanda is required")
        return

    values = np.arange(-3, 4)
    aa, bb = np.meshgrid(values, values)
    a_all = aa.flatten()
    b_all = bb.flatten()
    num_cases = len(a_all)

    match_count = 0
    failures = []

    for i in range(num_cases):
        a_val, b_val = int(a_all[i]), int(b_all[i])
        classic_val = minmod_classic(a_val, b_val)

        qvm = init_quantum_machine(QMachineType.CPU)
        prog, c_reg = build_circuit_2bit(qvm, a_val, b_val)
        result = qvm.run_with_configuration(prog, c_reg, 1)
        best_key = list(result.keys())[0]
        quantum_val = decode_result(best_key)

        is_match = (classic_val == quantum_val)
        if is_match:
            match_count += 1
        else:
            failures.append((a_val, b_val, classic_val, quantum_val, best_key))

        finalize()

    print(f"\n{match_count}/{num_cases} ({match_count/num_cases*100:.1f}%) correct\n")

    if failures:
        print(f"failures ({len(failures)}):")
        print(f"  {'a':>4}  {'b':>4}  {'classic':>6}  {'quantum':>6}  {'measured':>6}")
        for a_v, b_v, c_v, q_v, key in failures:
            print(f"  {a_v:>4}  {b_v:>4}  {c_v:>6}  {q_v:>6}  {key:>6}")
    else:
        print("all correct")

    return match_count == num_cases


def count_gates_from_originir(originir_str):
    """Count CNOT gates in an OriginIR string."""
    cnot_count = 0
    toffoli_count = 0
    for line in originir_str.split('\n'):
        if 'CNOT' in line:
            cnot_count += 1
        if 'toffoli' in line.lower() or 'CCX' in line:
            toffoli_count += 1
    return cnot_count, toffoli_count


def analyze_circuit():
    """Resource analysis of the minmod circuit variants."""
    if not HAS_PYQPANDA:
        print("error: pyqpanda is required")
        return

    qvm = init_quantum_machine(QMachineType.CPU)
    prog, c_reg = build_circuit_2bit(qvm, 1, 2)

    # OriginIR export
    originir = convert_qprog_to_originir(prog, qvm)

    cnot_count, toffoli_count = count_gates_from_originir(originir)

    # line count as a depth proxy
    lines = [l for l in originir.split('\n') if l.strip() and not l.strip().startswith('QINIT') and not l.strip().startswith('//')]
    total_ops = len([l for l in lines if any(op in l for op in ['CNOT', 'RY', 'RX', 'RZ', 'H', 'X', 'Y', 'Z', 'TOFFOLI', 'BARRIER'])])

    print(f"\nresources (adder architecture):")
    print(f"  qubits: 11")
    print(f"  CNOTs: {cnot_count}")
    print(f"  Toffolis: {toffoli_count}")
    print(f"  total operation lines: {total_ops}")
    print("  note: OriginIR lines != hardware depth (Toffoli decomposes)")

    finalize()


# ============================================================
# Truth-table version: 2-bit minmod without the adder network.
# ============================================================
#
# The 2-bit magnitude comparison follows directly from the Boolean
# truth table (magnitudes 0..3):
#     borrow = (|a| < |b|)
#            = (¬a1 ∧ b1) ∨ (¬(a1⊕b1) ∧ ¬a0 ∧ b0)
#   out1_f = signs_equal AND a1 AND b1   (MSB of the min, zeroed for
#                                          opposite signs)
#     out0_f = signs_equal ∧ (borrow ? a0 : b0)
# Margolus gates act as Toffolis on computational-basis inputs, so the
# substitution is exact here.
#
# qubit layout (11 qubits):
#   q0 sign_a, q1 sign_b, q2 signs_equal (reused as the output sign)
#   q3 a0, q4 a1, q5 b0, q6 b1
#   q7 borrow, q8 tmp (reused: eq -> out1_m -> a0_m/diff)
#   q9 out0_f (holds t2 during stage 4), q10 out1_f
#
# Compared with the 13-qubit version:
#   - eq stored in the shared q8, uncomputed after use (3 gates)
#   - t2 parked in the output q9 (idle during stage 4), uncomputed (3 gates)
#   - the two uncomputes touch different qubits and run in parallel

def build_circuit_2bit_simple(qvm, a, b):
    """2-bit minmod, truth-table version (no adder network, 11 qubits).

    Args:
        qvm: quantum virtual machine
        a, b: inputs in [-3, 3]

    Returns:
        prog: circuit
        c_reg: classical registers (c[0..1] magnitude, c[2] sign)
    """
    bit_num = 2
    prog = QProg()

    # qubit allocation
    q_sign_a = qvm.qAlloc_many(1)      # q0
    q_sign_b = qvm.qAlloc_many(1)      # q1
    q_sign_c = qvm.qAlloc_many(1)      # q2: signs_equal -> output sign
    q_a = qvm.qAlloc_many(bit_num)     # q3=a0, q4=a1
    q_b = qvm.qAlloc_many(bit_num)     # q5=b0, q6=b1
    q_br = qvm.qAlloc_many(1)          # q7: borrow = (|a|<|b|)
    q_tmp = qvm.qAlloc_many(1)         # q8: shared temporary (eq -> out1_m -> a0_m/diff)
    q_out0_f = qvm.qAlloc_many(1)      # q9: output magnitude LSB (holds t2 during stage 4)
    q_out1_f = qvm.qAlloc_many(1)      # q10: output magnitude MSB

    # sign encoding
    if a < 0:
        prog << X(q_sign_a[0])
    if b < 0:
        prog << X(q_sign_b[0])

    # magnitude encoding
    prog << bind_nonnegative_data(abs(a), q_a)
    prog << bind_nonnegative_data(abs(b), q_b)

    # ── 3. signs_equal = ¬(sign_a ⊕ sign_b) ──
    prog << CNOT(q_sign_a[0], q_sign_c[0])
    prog << CNOT(q_sign_b[0], q_sign_c[0])
    prog << X(q_sign_c[0])

    # borrow cascade (three terms, one accumulation)
    # 4a. q_br = ¬a1 ∧ b1
    prog << X(q_a[1])
    prog << M(qvm, q_a[1], q_b[1], q_br[0])
    prog << X(q_a[1])
    # 4b. q_tmp = eq = ¬(a1⊕b1)
    prog << CNOT(q_a[1], q_tmp[0])
    prog << CNOT(q_b[1], q_tmp[0])
    prog << X(q_tmp[0])
    # 4c. q_out0_f (borrowed) = NOT a0 AND b0
    prog << X(q_a[0])
    prog << M(qvm, q_a[0], q_b[0], q_out0_f[0])
    prog << X(q_a[0])
    # 4d. q_br ^= eq AND (NOT a0 AND b0)   (mutually exclusive with
    #     NOT a1 AND b1, so XOR acts as OR)
    prog << M(qvm, q_tmp[0], q_out0_f[0], q_br[0])
    # 4e. uncompute q_tmp (eq → |0⟩)
    prog << X(q_tmp[0])
    prog << CNOT(q_b[1], q_tmp[0])
    prog << CNOT(q_a[1], q_tmp[0])
    # 4f. uncompute q_out0_f (¬a0∧b0 → |0⟩)
    prog << X(q_a[0])
    prog << M(qvm, q_a[0], q_b[0], q_out0_f[0])
    prog << X(q_a[0])

    # out1_f = signs_equal AND a1 AND b1 (magnitude MSB of the min)
    prog << M(qvm, q_sign_c[0], q_a[1], q_tmp[0])   # tmp = signs_equal ∧ a1
    prog << M(qvm, q_tmp[0], q_b[1], q_out1_f[0])   # out1_f = tmp ∧ b1
    prog << M(qvm, q_sign_c[0], q_a[1], q_tmp[0])   # uncompute: tmp → |0⟩

    # out0_f = signs_equal AND (borrow ? a0 : b0)
    prog << M(qvm, q_sign_c[0], q_b[0], q_out0_f[0])  # out0_f = signs_equal∧b0
    prog << M(qvm, q_sign_c[0], q_a[0], q_tmp[0])     # tmp = signs_equal∧a0
    prog << CNOT(q_out0_f[0], q_tmp[0])               # tmp = a0_m ⊕ b0_m (diff)
    prog << M(qvm, q_br[0], q_tmp[0], q_out0_f[0])    # out0_f ^= borrow∧diff

    # final sign (q2 reused): sign_out = NOT(sign_a XOR signs_equal);
    # for opposite signs the magnitude is zero, so the sign is irrelevant
    prog << CNOT(q_sign_a[0], q_sign_c[0])
    prog << X(q_sign_c[0])

    # measurement
    c_reg = qvm.cAlloc_many(3)
    prog << Measure(q_out0_f[0], c_reg[0])
    prog << Measure(q_out1_f[0], c_reg[1])
    prog << Measure(q_sign_c[0], c_reg[2])

    return prog, c_reg


def build_circuit_2bit_simple_v13(qvm, a, b):
    """Truth-table version v13, 13 qubits (kept for comparison).

    Args:
        qvm: quantum virtual machine
        a, b: inputs in [-3, 3]

    Returns:
        prog: circuit
        c_reg: classical registers (c[0..1] magnitude, c[2] sign)
    """
    bit_num = 2
    prog = QProg()

    # qubit allocation (13 qubits)
    q_sign_a = qvm.qAlloc_many(1)      # q0
    q_sign_b = qvm.qAlloc_many(1)      # q1
    q_sign_c = qvm.qAlloc_many(1)      # q2: signs_equal -> output sign
    q_a = qvm.qAlloc_many(bit_num)     # q3=a0, q4=a1
    q_b = qvm.qAlloc_many(bit_num)     # q5=b0, q6=b1
    q_eq = qvm.qAlloc_many(1)          # q7: eq = ¬(a1⊕b1)
    q_t2 = qvm.qAlloc_many(1)          # q8: ¬a0∧b0
    q_br = qvm.qAlloc_many(1)          # q9: borrow = (|a|<|b|)
    q_tmp = qvm.qAlloc_many(1)         # q10: shared temporary
    q_out0_f = qvm.qAlloc_many(1)      # q11: output magnitude LSB
    q_out1_f = qvm.qAlloc_many(1)      # q12: output magnitude MSB

    # sign encoding
    if a < 0:
        prog << X(q_sign_a[0])
    if b < 0:
        prog << X(q_sign_b[0])

    # magnitude encoding
    prog << bind_nonnegative_data(abs(a), q_a)
    prog << bind_nonnegative_data(abs(b), q_b)

    # ── 3. signs_equal = ¬(sign_a ⊕ sign_b) ──
    prog << CNOT(q_sign_a[0], q_sign_c[0])
    prog << CNOT(q_sign_b[0], q_sign_c[0])
    prog << X(q_sign_c[0])

    # ── 4. borrow = (|a| < |b|) ──
    # 4a. q_br += ¬a1 ∧ b1
    prog << X(q_a[1])
    prog << M(qvm, q_a[1], q_b[1], q_br[0])
    prog << X(q_a[1])
    # 4b. eq = ¬(a1⊕b1)
    prog << CNOT(q_a[1], q_eq[0])
    prog << CNOT(q_b[1], q_eq[0])
    prog << X(q_eq[0])
    # 4c. q_t2 = ¬a0 ∧ b0
    prog << X(q_a[0])
    prog << M(qvm, q_a[0], q_b[0], q_t2[0])
    prog << X(q_a[0])
    # 4d. q_br ^= eq AND q_t2   (mutually exclusive, XOR as OR)
    prog << M(qvm, q_eq[0], q_t2[0], q_br[0])

    # out1_f = signs_equal AND a1 AND b1 (magnitude MSB of the min)
    prog << M(qvm, q_sign_c[0], q_a[1], q_tmp[0])   # tmp = signs_equal ∧ a1
    prog << M(qvm, q_tmp[0], q_b[1], q_out1_f[0])   # out1_f = tmp ∧ b1
    prog << M(qvm, q_sign_c[0], q_a[1], q_tmp[0])   # uncompute: tmp → |0⟩

    # out0_f = signs_equal AND (borrow ? a0 : b0)
    prog << M(qvm, q_sign_c[0], q_b[0], q_out0_f[0])  # out0_f = signs_equal∧b0
    prog << M(qvm, q_sign_c[0], q_a[0], q_tmp[0])     # tmp = signs_equal∧a0
    prog << CNOT(q_out0_f[0], q_tmp[0])               # tmp = a0_m ⊕ b0_m (diff)
    prog << M(qvm, q_br[0], q_tmp[0], q_out0_f[0])    # out0_f ^= borrow∧diff

    # final sign (q2 reused): sign_out = NOT(sign_a XOR signs_equal);
    # for opposite signs the magnitude is zero, so the sign is irrelevant
    prog << CNOT(q_sign_a[0], q_sign_c[0])
    prog << X(q_sign_c[0])

    # measurement
    c_reg = qvm.cAlloc_many(3)
    prog << Measure(q_out0_f[0], c_reg[0])
    prog << Measure(q_out1_f[0], c_reg[1])
    prog << Measure(q_sign_c[0], c_reg[2])

    return prog, c_reg


def build_circuit_2bit_simple_v12(qvm, a, b):
    """Truth-table version v12, 12 qubits.

    Compromise: eq is reused for an output temporary (one uncompute)
    while t2 keeps its own qubit; depth sits between v13 (36) and
    v11 (45).

    qubit layout (12 qubits):
      q0 sign_a, q1 sign_b, q2 signs_equal
      q3 a0, q4 a1, q5 b0, q6 b1
      q7 eq (reused out1_m/a0_m/diff), q8 t2 (own), q9 borrow
      q10 out0_f, q11 out1_f
    """
    bit_num = 2
    prog = QProg()

    q_sign_a = qvm.qAlloc_many(1)      # q0
    q_sign_b = qvm.qAlloc_many(1)      # q1
    q_sign_c = qvm.qAlloc_many(1)      # q2: signs_equal -> output sign
    q_a = qvm.qAlloc_many(bit_num)     # q3=a0, q4=a1
    q_b = qvm.qAlloc_many(bit_num)     # q5=b0, q6=b1
    q_eq = qvm.qAlloc_many(1)          # q7: eq, reused
    q_t2 = qvm.qAlloc_many(1)          # q8: NOT a0 AND b0
    q_br = qvm.qAlloc_many(1)          # q9: borrow
    q_out0_f = qvm.qAlloc_many(1)      # q10
    q_out1_f = qvm.qAlloc_many(1)      # q11

    # sign encoding
    if a < 0:
        prog << X(q_sign_a[0])
    if b < 0:
        prog << X(q_sign_b[0])

    # magnitude encoding
    prog << bind_nonnegative_data(abs(a), q_a)
    prog << bind_nonnegative_data(abs(b), q_b)

    # ── 3. signs_equal ──
    prog << CNOT(q_sign_a[0], q_sign_c[0])
    prog << CNOT(q_sign_b[0], q_sign_c[0])
    prog << X(q_sign_c[0])

    # ── 4. borrow ──
    prog << X(q_a[1])
    prog << M(qvm, q_a[1], q_b[1], q_br[0])
    prog << X(q_a[1])
    prog << CNOT(q_a[1], q_eq[0])
    prog << CNOT(q_b[1], q_eq[0])
    prog << X(q_eq[0])
    prog << X(q_a[0])
    prog << M(qvm, q_a[0], q_b[0], q_t2[0])
    prog << X(q_a[0])
    prog << M(qvm, q_eq[0], q_t2[0], q_br[0])
    # 4e. uncompute q_eq for later reuse
    prog << X(q_eq[0])
    prog << CNOT(q_b[1], q_eq[0])
    prog << CNOT(q_a[1], q_eq[0])

    # ── 5. out1_f ──
    prog << M(qvm, q_sign_c[0], q_a[1], q_eq[0])   # eq = se∧a1
    prog << M(qvm, q_eq[0], q_b[1], q_out1_f[0])   # out1_f = eq∧b1
    prog << M(qvm, q_sign_c[0], q_a[1], q_eq[0])   # uncompute

    # ── 6. out0_f ──
    prog << M(qvm, q_sign_c[0], q_b[0], q_out0_f[0])  # out0_f = se∧b0
    prog << M(qvm, q_sign_c[0], q_a[0], q_eq[0])      # eq = se∧a0
    prog << CNOT(q_out0_f[0], q_eq[0])                # eq = a0_m⊕b0_m
    prog << M(qvm, q_br[0], q_eq[0], q_out0_f[0])     # out0_f ^= borrow∧diff

    # final sign (q2 reused)
    prog << CNOT(q_sign_a[0], q_sign_c[0])
    prog << X(q_sign_c[0])

    # measurement
    c_reg = qvm.cAlloc_many(3)
    prog << Measure(q_out0_f[0], c_reg[0])
    prog << Measure(q_out1_f[0], c_reg[1])
    prog << Measure(q_sign_c[0], c_reg[2])

    return prog, c_reg


def run_local_test_simple():
    """Local CPUQVM validation, truth-table circuit, 49 combinations."""
    print("=" * 60)
    print("2-bit minmod local validation (truth-table circuit)")
    print("=" * 60)

    if not HAS_PYQPANDA:
        print("error: pyqpanda is required")
        return

    values = np.arange(-3, 4)
    aa, bb = np.meshgrid(values, values)
    a_all = aa.flatten()
    b_all = bb.flatten()
    num_cases = len(a_all)

    header = f"{'#':>4}  {'a':>4}  {'b':>4}  {'classic':>6}  {'quantum':>6}  {'match':>6}"
    print(header)
    print("-" * 45)

    match_count = 0
    failures = []
    for i in range(num_cases):
        a_val, b_val = int(a_all[i]), int(b_all[i])
        classic_val = minmod_classic(a_val, b_val)

        qvm = init_quantum_machine(QMachineType.CPU)
        prog, c_reg = build_circuit_2bit_simple(qvm, a_val, b_val)
        result = qvm.run_with_configuration(prog, c_reg, 1)
        best_key = list(result.keys())[0]
        quantum_val = decode_result(best_key)

        is_match = (classic_val == quantum_val)
        if is_match:
            match_count += 1
        else:
            failures.append((a_val, b_val, classic_val, quantum_val, best_key))
        match_str = "OK" if is_match else "FAIL"

        print(f"{i+1:>4}  {a_val:>4}  {b_val:>4}  {classic_val:>6}  {quantum_val:>6}  {match_str:>4}")

        finalize()

    print("-" * 45)
    rate = match_count / num_cases * 100
    print(f"{match_count}/{num_cases} ({rate:.1f}%) exact matches")

    if failures:
        print("\nfailures:")
        for a_v, b_v, c_v, q_v, key in failures:
            print(f"  a={a_v:>3} b={b_v:>3} classic={c_v:>3} quantum={q_v:>3} key={key}")
    else:
        print("all correct")

    return match_count == num_cases


def calc_originir_depth(originir_str):
    """OriginIR depth by dependency scheduling.

    A gate occupies all qubits it touches (including CONTROL bits);
    within a layer each qubit is touched once, different qubits run in
    parallel.
    """
    last_layer = {}        # qubit -> last layer touched
    depth = 0
    control_stack = []     # nested CONTROL control bits

    for line in originir_str.split('\n'):
        s = line.strip()
        if not s or s.startswith('QINIT') or s.startswith('CREG') or s.startswith('//'):
            continue
        if s.startswith('DAGGER') or s.startswith('ENDDAGGER'):
            continue
        if s.startswith('CONTROL'):
            qs = [int(x) for x in s.replace('CONTROL', '').replace('q', '').replace('[', '').replace(']', '').split(',') if x.strip()]
            control_stack.append(set(qs))
            continue
        if s.startswith('ENDCONTROL'):
            if control_stack:
                control_stack.pop()
            continue

        # qubits touched by this gate
        qubits = [int(m) for m in re.findall(r'q\[(\d+)\]', s)]
        for cs in control_stack:
            qubits.extend(cs)
        if not qubits:
            continue

        # earliest layer = max over touched qubits + 1
        earliest = 0
        for q in qubits:
            earliest = max(earliest, last_layer.get(q, 0))
        layer = earliest + 1
        for q in qubits:
            last_layer[q] = layer
        depth = max(depth, layer)

    return depth


def analyze_circuit_simple():
    """Resource comparison of the truth-table circuit variants."""
    if not HAS_PYQPANDA:
        print("error: pyqpanda is required")
        return

    def _stats(builder):
        qvm = init_quantum_machine(QMachineType.CPU)
        prog, c_reg = builder(qvm, 1, 2)
        originir = convert_qprog_to_originir(prog, qvm)
        cnot, toffoli = count_gates_from_originir(originir)
        depth = calc_originir_depth(originir)
        finalize()
        return cnot, toffoli, depth

    cnot_old, toffoli_old, depth_old = _stats(build_circuit_2bit)
    cnot_v13, toffoli_v13, depth_v13 = _stats(build_circuit_2bit_simple_v13)
    cnot_v12, toffoli_v12, depth_v12 = _stats(build_circuit_2bit_simple_v12)
    cnot_v11, toffoli_v11, depth_v11 = _stats(build_circuit_2bit_simple)

    # hardware-equivalent CNOTs: Toffoli ~ 15, CNOT = 1
    hw_old = cnot_old + 15 * toffoli_old
    hw_v13 = cnot_v13 + 15 * toffoli_v13
    hw_v12 = cnot_v12 + 15 * toffoli_v12
    hw_v11 = cnot_v11 + 15 * toffoli_v11

    print(f"\nresource comparison (a=1, b=2):")
    print(f"  {'metric':<16} {'adder':>9} {'v13(13q)':>9} {'v12(12q)':>9} {'v11(11q)':>9}")
    print(f"  {'-'*58}")
    print(f"  {'qubits':<16} {'11':>9} {'13':>9} {'12':>9} {'11':>9}")
    print(f"  {'OriginIR CNOT':<16} {cnot_old:>9} {cnot_v13:>9} {cnot_v12:>9} {cnot_v11:>9}")
    print(f"  {'OriginIR Toffoli':<16} {toffoli_old:>9} {toffoli_v13:>9} {toffoli_v12:>9} {toffoli_v11:>9}")
    print(f"  {'hw-CNOT-equiv':<16} {hw_old:>9} {hw_v13:>9} {hw_v12:>9} {hw_v11:>9}")
    print(f"  {'OriginIR depth':<16} {depth_old:>9} {depth_v13:>9} {depth_v12:>9} {depth_v11:>9}")

    print(f"\n  v11 vs adder version: CNOT {hw_old}->{hw_v11} ({-100*(1-hw_v11/hw_old):.0f}%), "
          f"depth {depth_old}->{depth_v11} ({-100*(1-depth_v11/depth_old):.0f}%)")
    print(f"        v12 vs v13 = CNOT {hw_v13}→{hw_v12} ({-100*(1-hw_v12/hw_v13):.0f}%), "
          f"depth {depth_v13}->{depth_v12} ({-100*(1-depth_v12/depth_v13):.0f}%)")
    print(f"        v11 vs v12 = CNOT {hw_v12}→{hw_v11} ({-100*(1-hw_v11/hw_v12):.0f}%), "
          f"depth {depth_v12}->{depth_v11} ({-100*(1-depth_v11/depth_v12):.0f}%)")


# ============================================================
# real-device submission (pyqpanda3)
# ============================================================

# insert your Origin Pilot API key here (not committed to the repo)
API_KEY = "XXXX"
CHIP_NAME = "WK_C180"   # WK_C180_2 under maintenance; the cloud backend
                        # name is WK_C180 (not WK_C180_1)
SHOTS = 1000

# pyqpanda3 0.3.1 cannot pin physical qubits on the device
# (best_qubit_blocks/set_specified_block need 0.4.x; run(prog, qubits)
# only works for the statevector simulator), so the cloud auto-mapping
# is used.  Local pre-compilation estimates ~99 CZ / depth 144 for v11,
# already beyond the noise budget of this chip.


def run_real_machine(a_val=None, b_val=None):
    """Submit the real-device experiment (v11, 11 qubits / 38 CNOT / 45 layers).

    Args:
        a_val, b_val: submit a single pair if both are given, else all 49
    """
    try:
        from pyqpanda3.intermediate_compiler import convert_originir_string_to_qprog
        from pyqpanda3.qcloud import QCloudOptions, QCloudService
    except ImportError:
        print("error: pyqpanda3 is required")
        return

    print("=" * 60)
    print("2-bit minmod real-device experiment (truth-table v11)")
    print("=" * 60)

    service = QCloudService(API_KEY)
    backend = service.backend(CHIP_NAME)
    options = QCloudOptions()
    print(f"backend ready: {backend.name()}")
    print(f"Shots: {SHOTS}")

    if a_val is not None and b_val is not None:
        cases = [(a_val, b_val)]
        print(f"single case: a={a_val}, b={b_val}\n")
    else:
        values = np.arange(-3, 4)
        aa, bb = np.meshgrid(values, values)
        cases = [(int(x), int(y)) for x, y in zip(aa.flatten(), bb.flatten())]
        print(f"all combinations: {len(cases)} cases\n")

    # output file
    output_path = "results_2bit_v11_real.txt"
    header = f"{'#':>4}  {'a':>4}  {'b':>4}  {'classic':>6}  {'quantum':>6}  {'match':>6}"
    sep = "-" * 45

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("Real-device 2-bit minmod results (truth-table v11)\n")
        f.write(f"config: 11 qubits / 38 CNOT / 45 layers, chip {CHIP_NAME}, shots {SHOTS}, {len(cases)} cases\n")
        f.write(sep + "\n")
        f.write(header + "\n")
        f.write(sep + "\n")

        print(header)
        print(sep)

        match_count = 0
        for i, (a_val, b_val) in enumerate(cases):
            classic_val = minmod_classic(a_val, b_val)

            # build the v11 circuit -> OriginIR
            qvm = init_quantum_machine(QMachineType.CPU)
            prog, c_reg = build_circuit_2bit_simple(qvm, a_val, b_val)
            originir = convert_qprog_to_originir(prog, qvm)
            finalize()

            # load into pyqpanda3
            prog_p3 = convert_originir_string_to_qprog(originir)

            # submit (cloud auto-mapping)
            print(f"[{i+1}/{len(cases)}] submit a={a_val:>3}, b={b_val:>3} ...", end=" ", flush=True)
            job = backend.run(prog_p3, SHOTS, options)
            result = job.result()

            # decode
            probs = result.get_probs()
            best_key = max(probs, key=probs.get)
            quantum_val = decode_result(best_key)

            is_match = (classic_val == quantum_val)
            if is_match:
                match_count += 1
            match_str = "OK" if is_match else "FAIL"
            line = f"{i+1:>4}  {a_val:>4}  {b_val:>4}  {classic_val:>6}  {quantum_val:>6}  {match_str:>4}"
            print(f"{best_key} → {quantum_val:>3}  {match_str}")
            f.write(line + "\n")

            # single-case mode: print the full distribution
            if len(cases) == 1:
                expected = f"{1 if classic_val < 0 else 0}{(classic_val >> 1) & 1}{classic_val & 1}"
                print(f"  expected: {expected} (classic={classic_val:+d})")
                print("  top-8 probabilities:")
                for k, p in sorted(probs.items(), key=lambda kv: -kv[1])[:8]:
                    mark = "  <-- expected" if k == expected else ""
                    print(f"    {k}  {p*100:6.2f}%{mark}")
                f.write(f"  # Top-8: " + ", ".join(f"{k}:{p*100:.2f}%" for k, p in sorted(probs.items(), key=lambda kv: -kv[1])[:8]) + "\n")

        rate = match_count / len(cases) * 100
        summary = f"\n{match_count}/{len(cases)} ({rate:.1f}%) exact matches"
        f.write(sep + "\n")
        f.write(summary + "\n")
        print(sep)
        print(summary)

    print(f"\nresults saved to: {output_path}")


# ============================================================
# entry point
# ============================================================

if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "real":
        if len(sys.argv) > 3:
            # single case: python quantum_minmod_2bit.py real <a> <b>
            run_real_machine(int(sys.argv[2]), int(sys.argv[3]))
        else:
            run_real_machine()
    elif len(sys.argv) > 1 and sys.argv[1] == "analyze":
        analyze_circuit_simple()
    elif len(sys.argv) > 1 and sys.argv[1] == "analyze_old":
        analyze_circuit()
    elif len(sys.argv) > 1 and sys.argv[1] == "old":
        # local validation, adder architecture
        ok = run_local_test_detailed()
        if ok:
            print("\nadder-architecture validation passed")
    else:
        # default: truth-table version, 49 cases
        ok = run_local_test_simple()
        if ok:
            print("\nvalidation passed; run 'python quantum_minmod_2bit.py analyze'")
            print("for the resource comparison.")
