# Source Code: Quantum Circuit Implementation of Core Nonlinear Operators for Explicit CFD Schemes

Code for the numerical experiments of the JCP manuscript. The quantum
operators are built with [pyQPanda](https://github.com/OriginQ/pyqpanda)
and executed either on the local CPU statevector simulator or, for the
hardware experiments, on the WK_C180_2 superconducting processor through
the Origin quantum cloud.

## Layout

```
.
├── quantum_circuits.py        shared circuit interfaces (minmod / superbee /
│                              Rusanov) used by the solvers; running the file
│                              executes the low-bit validation suite
├── test_lowbit_integration.py end-to-end check: real circuits vs fixed-point
│                              emulation on small Lax and Sod cases
├── 1-limiter-validation/      unit tests of the limiter circuits (Sec. 5.1)
├── 2-shock-tube/              Sod and Lax shock-tube solvers (Secs. 5.2-5.3)
├── 3-real-device/             WK_C180_2 hardware experiments (Sec. 5.4)
└── 4-cs-readout/              flow-field encoding and compressed-sensing
                               reconstruction (Sec. 6)
```

## Dependencies

Python 3.11 with

```
numpy  scipy  matplotlib  pyqpanda  pyqpanda3  qiskit  PyWavelets  numba
```

## Experiment map

| Manuscript figure | Script | Output |
|---|---|---|
| Fig. limcom (limiter validation) | `1-limiter-validation/limiter-com-q.py` | `limiter_functions_with_quantum_points.png` |
| Fig. bur (Burgers equation) | `1-limiter-validation/minmod-Burgers.py` | `vector_minmod_comparison.png` |
| Fig. gate_num a/b (gate scaling) | `1-limiter-validation/gate_counter.py` | `limiter_gate_scaling.png`, `limiter_gate_composition.png` |
| Fig. Rusanov_SOD (Sod problem) | `2-shock-tube/Rusanov-SOD.py` | `Rusanov_SOD_quantum.png` |
| Fig. Joint_LAX (Lax problem) | `2-shock-tube/Lax_hybrid.py` | `Joint_LAX_quantum_N400.png`, `errors_N400.txt` |
| Fig. margolus_9subplots | `3-real-device/plot_margolus.py` | `results_margolus_9subplots.png` |
| Fig. superposition_8cases | `3-real-device/plot_superposition.py` | `results_superposition_8cases.png` |
| Fig. 2bit_success_matrix | `3-real-device/plot_2bit_results.py` | `results_2bit_v11_wk2_success_matrix.png` |
| Fig. case1/case2 error curves and visual comparison | `4-cs-readout/quantum_reconstruction.py` | `quantum_error_vs_ratio_*.png`, `quantum_visual_comparison_*.png` |

The hardware figures are plotted from the measurement data stored next to
the plotting scripts (`results_margolus.json`, `results_2bit_wk2_matrix.json`,
`experiment_summary.json`); the submission scripts
(`quantum_minmod*.py`) reproduce the raw measurements when a valid API key
is provided.

## Running

```bash
# shared-interface validation (minmod 3-7 bit, superbee exhaustive 2-3 bit,
# Rusanov 3-5 bit vs classical references)
python quantum_circuits.py

# limiter unit tests (Sec. 5.1); the minmod circuit runs at 7-bit precision
cd 1-limiter-validation
python limiter-com-q.py
python minmod-Burgers.py
python gate_counter.py

# shock-tube validation (Secs. 5.2-5.3)
cd ../2-shock-tube
python Rusanov-SOD.py      # Sod problem, 400 cells, 9-bit quantum flux
python Lax_hybrid.py       # Lax problem, 400 cells, minmod 7-bit + flux 9-bit

# compressed-sensing readout (Sec. 6); caches ship with the repo,
# regenerate with generate_flow_fields.py / runme.py if needed
cd ../4-cs-readout
python quantum_reconstruction.py --case both --res 512
```

`Lax_hybrid.py` and `Rusanov-SOD.py` evaluate the quantum operators in one
of two modes, selected by the `USE_REAL_CIRCUITS` flag:

* `False` (default) — fixed-point emulation of the circuits, fast enough
  for the full 400-cell runs;
* `True` — every operator call goes through the pyqpanda circuits in
  `quantum_circuits.py` (gate-level validation; practical only for small
  grids, see `test_lowbit_integration.py`).

## Hardware experiments (3-real-device/)

The circuits were submitted to the WK_C180_2 processor through pyqpanda3.
`API.txt` and the `API_KEY` variables in `quantum_minmod.py` /
`quantum_minmod_2bit.py` are placeholders — insert your own Origin Pilot
API key before running, and keep it out of the repository.

* `quantum_minmod.py` — 2-bit Toffoli-branch version (baseline, 488 layers)
* `quantum_minmod_1bit.py` — 1-bit gate-level version, local validation
* `quantum_minmod_1bit_margolus.py` — 1-bit Margolus-optimized version
* `quantum_minmod_2bit.py` — 2-bit truth-table versions (v11 / v12 / v13)
  with resource comparison and device submission
* `quantum_minmod_superposition.py` — superposition-input tests, local
  CPUQVM simulation
* `plot_*.py` — figures from the stored measurement data

## Notes

* The CPU statevector simulator is limited to 29 qubits; the bit widths
  used in the scripts stay within this budget (minmod up to 7 bit, superbee
  up to 3 bit, Rusanov up to 6 bit per component).
* The fixed-point emulation in the solvers reproduces the circuit
  arithmetic exactly (register truncation, right-shift halving, clamping)
  and was verified bit-for-bit against the circuits at low widths by
  `test_lowbit_integration.py`.
