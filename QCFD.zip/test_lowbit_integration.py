"""Low-bit end-to-end tests: real quantum interfaces (pyqpanda circuits)
vs fixed-point classical emulation, on small Lax / Sod cases.

Run:  python test_lowbit_integration.py
"""

import importlib.util
import os

import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


lx = load_module("lax_hybrid_mod",
                 os.path.join(BASE, "2-shock-tube", "Lax_hybrid.py"))
rs = load_module("rusanov_sod_mod",
                 os.path.join(BASE, "2-shock-tube", "Rusanov-SOD.py"))


def build_lax(N):
    x = np.linspace(0.5 / N, 1 - 0.5 / N, N)
    rhoL, uL, pL = 0.445, 0.698, 3.528
    rhoR, uR, pR = 0.5, 0.0, 0.571
    rho_init = np.where(x < 0.5, rhoL, rhoR)
    u_init = np.where(x < 0.5, uL, uR)
    p_init = np.where(x < 0.5, pL, pR)
    solver = lx.EulerSolver()
    U0 = np.zeros((3, N))
    for i in range(N):
        U0[:, i] = solver.primitive_to_conserved(rho_init[i], u_init[i], p_init[i])
    return x, U0, solver


print("=" * 70)
print("[Test A] Lax hybrid -- real quantum circuits vs emulation")
print("          N=25, t=0.02, CFL=0.3, minmod 3-bit, flux 4-bit")
print("=" * 70)

N = 25
x, U0, solver = build_lax(N)
t_out, CFL = 0.02, 0.3

lx.USE_REAL_CIRCUITS = True
import time
t0 = time.time()
U_q = solver.solve_quantum_hybrid(x, U0.copy(), t_out, CFL=CFL,
                                  minmod_n_bits=3, flux_n_bits=4)
rho_q = np.array([solver.conserved_to_primitive(U_q[:, i])[0] for i in range(N)])
t_q = time.time() - t0
steps_q = solver.step_count

lx.USE_REAL_CIRCUITS = False
U_e = solver.solve_quantum_hybrid(x, U0.copy(), t_out, CFL=CFL,
                                  minmod_n_bits=3, flux_n_bits=4)
rho_e = np.array([solver.conserved_to_primitive(U_e[:, i])[0] for i in range(N)])
steps_e = solver.step_count

print(f"  steps: quantum={steps_q}, emulation={steps_e}")
print(f"  max |rho_q - rho_e| = {np.abs(rho_q - rho_e).max():.3e}")
print(f"  quantum wall time: {t_q:.1f} s  (real circuits at gate level)")

print()
print("=" * 70)
print("[Test B] Sod problem -- real quantum Rusanov flux vs emulation")
print("          N=25, t=0.02, CFL=0.8, 4-bit flux")
print("=" * 70)

solverB = rs.RusanovSolver(gamma=1.4, order=1)
rho_init = np.where(x < 0.5, 1.0, 0.125)
u_init = np.zeros(N)
p_init = np.where(x < 0.5, 1.0, 0.1)
U0B = np.zeros((3, N))
for i in range(N):
    U0B[:, i] = solverB.primitive_to_conserved(rho_init[i], u_init[i], p_init[i])

rs.USE_REAL_CIRCUITS = True
t0 = time.time()
U_qB = solverB.solve_with_quantum_flux(x, U0B.copy(), t_out, n_bits=4, CFL=0.8)
rho_qB = np.array([solverB.conserved_to_primitive(U_qB[:, i])[0] for i in range(N)])
t_qB = time.time() - t0

rs.USE_REAL_CIRCUITS = False
U_eB = solverB.solve_with_quantum_flux(x, U0B.copy(), t_out, n_bits=4, CFL=0.8)
rho_eB = np.array([solverB.conserved_to_primitive(U_eB[:, i])[0] for i in range(N)])

print(f"  (step counts printed by the solver above)")
print(f"  max |rho_q - rho_e| = {np.abs(rho_qB - rho_eB).max():.3e}")
print(f"  (exact match expected: both consume the same fixed-point integers)")
print(f"  quantum wall time: {t_qB:.1f} s")

ok_a = np.abs(rho_q - rho_e).max() < 1e-10
ok_b = np.abs(rho_qB - rho_eB).max() < 1e-10
print()
print(f"Test A (Lax):   {'PASS' if ok_a else 'DIFF'}  (minmod power-of-2 "
      f"rescaling may give tiny diffs vs emulation float-F)")
print(f"Test B (Sod):   {'PASS' if ok_b else 'DIFF'}")
