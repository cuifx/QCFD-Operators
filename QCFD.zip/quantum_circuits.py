"""Quantum circuit interfaces for the nonlinear CFD operators (pyQPanda).

 quantum_minmod(a, b, bit_num)                  in-place minmod limiter
 quantum_superbee(a, b, bit_num)                superbee limiter
 quantum_rusanov(fl, fr, ul, ur, sm, n_bits)    reduced-input Rusanov flux

Each function takes classical fixed-point integers, builds the circuit for
that input (signs through X gates, magnitudes through bind_nonnegative_data,
arithmetic through QAdderIgnoreCarry), and returns the measured integer.
This matches the computational-basis pipeline of the paper, where sign
branches are resolved at construction time.

Running this file executes low-bit validation against classical references.
"""

import math

import numpy as np
from pyqpanda import (
    init_quantum_machine, QProg, QCircuit, QMachineType,
    X, CNOT, SWAP, Toffoli, QAdderIgnoreCarry, bind_nonnegative_data,
    prob_run_dict,
)

# A fresh CPUQVM is created per call.  A shared machine with qAlloc/qFree
# recycling reuses qubits with dirty state and silently corrupts results.


# ---------------------------------------------------------------
# In-place minmod (Fig. 5): 0 for opposite signs, sign(a)*min(|a|,|b|)
# for same signs.  Magnitudes are rescaled to the largest power of two
# fitting the register.
# ---------------------------------------------------------------
def quantum_minmod(a, b, bit_num=7):
    m = bit_num

    def preprocess(x, y):
        max_val = max(abs(x), abs(y))
        if max_val == 0:
            return 0, 0, 1
        max_integer = (1 << m) - 1
        F_max = max_integer / max_val
        F = 1 if F_max < 1 else (1 << math.floor(math.log2(F_max)))
        A = min(max(round(x * F), -max_integer), max_integer)
        B = min(max(round(y * F), -max_integer), max_integer)
        return A, B, F

    A_clamped, B_clamped, F = preprocess(abs(a), abs(b))

    qvm = init_quantum_machine(QMachineType.CPU)
    prog = QProg()

    q_sign_a = qvm.qAlloc_many(1)
    q_sign_b = qvm.qAlloc_many(1)
    q_a = qvm.qAlloc_many(m + 1)
    q_b = qvm.qAlloc_many(m + 1)
    aux = qvm.qAlloc_many(1)

    if a < 0:
        prog << X(q_sign_a[0])
    if b < 0:
        prog << X(q_sign_b[0])

    prog << bind_nonnegative_data(A_clamped, q_a)
    prog << bind_nonnegative_data(B_clamped, q_b)

    # magnitude update steered by the sign qubit of b
    prog << X(q_sign_a[0])
    prog << CNOT(q_sign_a[0], q_sign_b[0])
    prog << X(q_sign_a[0])

    prog << QAdderIgnoreCarry(q_b, q_a, aux[0]).dagger().control(q_sign_b[0])
    prog << QAdderIgnoreCarry(q_b[0:m], q_a[0:m], aux[0]).control(q_sign_b[0])

    prog << X(q_b[-1]).control(q_sign_b[0])

    prog << bind_nonnegative_data(B_clamped, q_b).control(q_sign_b[0]).control(q_b[-1])
    prog << QAdderIgnoreCarry(q_b[0:m], q_a[0:m], aux[0]).control(q_sign_b[0]).control(q_b[-1])

    prog << X(q_sign_b[0])
    prog << bind_nonnegative_data(B_clamped, q_b).control(q_sign_b[0])

    result = prob_run_dict(prog, q_b[0:m] + q_sign_a, 1)
    c = int(list(result.keys())[0], 2)
    if c >= 2 ** m:
        c = -(c - 2 ** m)

    return c / F


# ---------------------------------------------------------------
# Comparator primitives.  QAdderIgnoreCarry(target, addend, carry)
# computes target += addend and demands equal-length operands.
# ---------------------------------------------------------------
def _quantum_compare(m, q_a, q_b, q_c):
    """min(|a|, |b|) -> q_c.  q_a is restored, q_b is left dirty."""
    circ = QCircuit()
    circ << QAdderIgnoreCarry(q_b, q_a, q_c[0]).dagger()
    circ << QAdderIgnoreCarry(q_b[0:m], q_a[0:m], q_c[1])
    circ << QAdderIgnoreCarry(q_c, q_b[0:m], q_a[-1]).control(q_b[-1])
    circ << X(q_b[-1])
    circ << QAdderIgnoreCarry(q_c, q_a[0:m], q_a[-1]).control(q_b[-1])
    circ << X(q_b[-1])
    return circ


def _quantum_compare_max(m, q_a, q_b, q_c, q_aux):
    """max(a, b) -> q_c, all registers m bits.  Both operands restored."""
    circ = QCircuit()
    circ << QAdderIgnoreCarry(q_b, q_a, q_aux[0]).dagger()   # a -= b, borrow
    circ << QAdderIgnoreCarry(q_b, q_a, q_aux[1])            # a += b
    for j in range(m):
        circ << CNOT(q_a[j], q_c[j])                         # q_c = a
    for j in range(m):
        circ << CNOT(q_a[j], q_b[j])                         # q_b[j] = a^b
        circ << Toffoli(q_aux[0], q_b[j], q_c[j])            # q_c ^= sel*(a^b)
        circ << CNOT(q_a[j], q_b[j])
    return circ


def _quantum_mul_2(m, q_a):
    """In-place doubling via a SWAP chain."""
    circ = QCircuit()
    for i in range(m):
        circ << SWAP(q_a[m - i], q_a[m - i - 1])
    return circ


# ---------------------------------------------------------------
# Superbee.  For A = |a|, B = |b| with a*b > 0,
#   max(min(2A,B), min(A,2B)) = min(2A,B)  if A <= B
#                             = min(A,2B)  if A >  B,
# so a single min-comparison suffices; the branch is chosen when the
# circuit is built.  The doubled magnitude 2*max(A,B) < 2^(m+1) sets the
# comparison width k = m+1 (bit k serves as carry ancilla), giving
# 3m + 5 qubits in total.
# ---------------------------------------------------------------
def quantum_superbee(a, b, bit_num=3):
    if a * b <= 0:
        return 0.0

    m = bit_num
    k = m + 1
    A, B = abs(int(round(a))), abs(int(round(b)))

    x, y = (2 * A, B) if A <= B else (A, 2 * B)

    qvm = init_quantum_machine(QMachineType.CPU)
    prog = QProg()

    q_x = qvm.qAlloc_many(k + 1)
    q_y = qvm.qAlloc_many(k + 1)
    q_c = qvm.qAlloc_many(k)

    prog << bind_nonnegative_data(x, q_x)
    prog << bind_nonnegative_data(y, q_y)
    prog << _quantum_compare(k, q_x, q_y, q_c)

    result = prob_run_dict(prog, q_c, 1)
    mag = int(list(result.keys())[0], 2)

    return -mag if a < 0 else mag


def superbee_classic(a, b):
    """Integer-exact classical reference."""
    if a * b <= 0:
        return 0
    sa = -1 if a < 0 else 1
    A, B = abs(a), abs(b)
    return sa * max(min(2 * A, B), min(A, 2 * B))


# ---------------------------------------------------------------
# Reduced-input Rusanov flux, one component.  Fixed-point convention as
# in Rusanov-SOD.py / Lax_hybrid.py:
#   s1 = fl + fr,  p = sm * |ur - ul|
#   h1 = trunc(s1/2),  h2 = trunc(p/2)
#   F = clamp(h1 + h2 if ur < ul else h1 - h2)
# |s1| and p are formed on the QVM; halving is the measurement of the
# high bits (LSB dropped).  Signs and the final clamp are classical.
# Widths: |d| < 2^(m+1), p < 2^(m+3); 4m + 7 qubits in total.
# ---------------------------------------------------------------
def _shift_add(prog, q_src, q_dst, k, aux):
    """q_dst += k * q_src for small non-negative integer k."""
    w = len(q_src)
    i = 0
    while k > 0:
        if k & 1:
            prog << QAdderIgnoreCarry(q_dst[i:i + w], q_src, aux[0])
        k >>= 1
        i += 1


def quantum_rusanov(fl, fr, ul, ur, sm, n_bits=6):
    m = n_bits - 1
    int_max = 2 ** m - 1
    sm = int(abs(sm))

    sign_fl, sign_fr = fl < 0, fr < 0
    mag_fl, mag_fr = abs(fl), abs(fr)

    # s1 = fl + fr: subtract magnitudes when the signs differ
    if sign_fl == sign_fr:
        s1_sign = sign_fl
        s1_big, s1_small = mag_fl, mag_fr
        s1_sub = False
    else:
        s1_sign = sign_fl if mag_fl >= mag_fr else sign_fr
        s1_big, s1_small = max(mag_fl, mag_fr), min(mag_fl, mag_fr)
        s1_sub = True

    # d = ur - ul: subtract magnitudes for like signs, add otherwise
    d = ur - ul
    d_neg = d < 0
    if (ur >= 0) == (ul >= 0):
        d_sub = True
        d_big, d_small = max(abs(ur), abs(ul)), min(abs(ur), abs(ul))
    else:
        d_sub = False
        d_big, d_small = abs(ur), abs(ul)

    qvm = init_quantum_machine(QMachineType.CPU)
    prog = QProg()

    q_s = qvm.qAlloc_many(m + 1)
    q_d = qvm.qAlloc_many(m + 1)
    q_p = qvm.qAlloc_many(m + 3)
    q_t = qvm.qAlloc_many(m + 1)
    aux = qvm.qAlloc_many(1)

    prog << bind_nonnegative_data(s1_big, q_s)
    prog << bind_nonnegative_data(s1_small, q_t)
    if s1_sub:
        prog << QAdderIgnoreCarry(q_s, q_t, aux[0]).dagger()
    else:
        prog << QAdderIgnoreCarry(q_s, q_t, aux[0])
    r1 = prob_run_dict(prog, q_s[1:], 1)
    h1 = int(list(r1.keys())[0], 2)

    prog2 = QProg()
    prog2 << bind_nonnegative_data(d_big, q_d)
    prog2 << bind_nonnegative_data(d_small, q_t[:m + 1])
    if d_sub:
        prog2 << QAdderIgnoreCarry(q_d, q_t[:m + 1], aux[0]).dagger()
    else:
        prog2 << QAdderIgnoreCarry(q_d, q_t[:m + 1], aux[0])
    if sm > 0:
        _shift_add(prog2, q_d, q_p, sm, aux)
    r2 = prob_run_dict(prog2, q_p[1:], 1)
    h2 = int(list(r2.keys())[0], 2)

    h1_signed = -h1 if s1_sign else h1
    r = h1_signed + h2 if d_neg else h1_signed - h2
    return max(min(r, int_max), -int_max)


def rusanov_classic(fl, fr, ul, ur, sm, n_bits=6):
    """Classical fixed-point reference, same convention."""
    m = n_bits - 1
    int_max = 2 ** m - 1
    s1 = fl + fr
    d = ur - ul
    p = sm * abs(d)
    h1 = int(s1 / 2)
    h2 = int(p / 2)
    r = h1 + h2 if d < 0 else h1 - h2
    return max(min(r, int_max), -int_max)


def _run_tests():
    rng = np.random.RandomState(42)

    print("[1] minmod vs classical, random cases")
    for bit_num in (3, 4, 5, 6, 7):
        n = 40
        ok = 0
        scale = 2 ** (bit_num - 1) - 1
        for _ in range(n):
            a = int(rng.randint(-scale, scale + 1))
            b = int(rng.randint(-scale, scale + 1))
            q = quantum_minmod(a, b, bit_num)
            c = 0 if a * b <= 0 else (a if abs(a) < abs(b) else b)
            ok += abs(q - c) < 1e-9
        print(f"  bit={bit_num}: {ok}/{n}")

    print("[2] superbee vs classical, exhaustive")
    for bit_num in (2, 3):
        lim = 2 ** bit_num - 1
        ok = tot = 0
        for a in range(-lim, lim + 1):
            for b in range(-lim, lim + 1):
                if b == 0:
                    continue
                ok += abs(quantum_superbee(a, b, bit_num)
                          - superbee_classic(a, b)) < 1e-9
                tot += 1
        print(f"  bit={bit_num}: {ok}/{tot}")

    print("[3] rusanov vs classical fixed-point, random cases")
    for n_bits in (3, 4, 5):
        m = n_bits - 1
        lim = 2 ** m - 1
        n = 40
        ok = 0
        for _ in range(n):
            fl = int(rng.randint(-lim, lim + 1))
            fr = int(rng.randint(-lim, lim + 1))
            ul = int(rng.randint(-lim, lim + 1))
            ur = int(rng.randint(-lim, lim + 1))
            sm = int(rng.randint(0, 4))
            ok += quantum_rusanov(fl, fr, ul, ur, sm, n_bits) == \
                rusanov_classic(fl, fr, ul, ur, sm, n_bits)
        print(f"  n_bits={n_bits}: {ok}/{n}")


if __name__ == "__main__":
    _run_tests()
