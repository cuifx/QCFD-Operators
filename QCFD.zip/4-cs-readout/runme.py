import cfd_shock_vortex as c
import numpy as np
result = c.run_cfd()
if result is not None:
    rho, snaps, times = result
    print(f"Final rho: [{rho.min():.4f}, {rho.max():.4f}]")
    np.savez_compressed("shock_vortex_cfd_cache.npz",
        rho=rho, snapshots=np.array(snaps), snap_times=np.array(times),
        nx=c.NX, ny=c.NY)
    print("Cache saved. DONE.")
else:
    print("FAILED")
