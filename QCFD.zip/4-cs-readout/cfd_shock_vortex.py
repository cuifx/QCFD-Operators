"""
Standalone shock-vortex interaction CFD solver — Numba JIT-accelerated.

Solves 2D compressible Euler equations with:
  - X: WENO5 + shock-sensor (1st-order near shocks) + HLL flux
  - Y: MUSCL-MC + HLL flux (2nd-order, dissipative)
  - Binary Rankine-Hugoniot shock initialization at cell interface
  - Sponge-layer absorption zone (x > 1.95) + non-reflective outflow BC
  - Isentropic vortex superimposed on stationary Ma=1.5 shock
    (Colera et al. Sec 3.8: piecewise v_theta + energy integral)

Grid: nx=512, ny=256, domain [0,2]x[0,1], shock at x=0.5.
Outputs density field snapshots saved to shock_vortex_cfd_cache.npz."""
import os
import numpy as np
from numba import njit

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))

def _log(msg):
    print(msg, flush=True)

# =========================================================================
#  Parameters
# =========================================================================
GAMMA = 1.4
GM1 = GAMMA - 1.0
GM1_INV = 1.0 / GM1

# Grid
NX, NY = 512, 256
DOMAIN_X = (0.0, 2.0)
DOMAIN_Y = (0.0, 1.0)
dx = (DOMAIN_X[1] - DOMAIN_X[0]) / NX
dy = (DOMAIN_Y[1] - DOMAIN_Y[0]) / NY
SHOCK_X0 = 0.5

# Pre-shock state (left, supersonic inflow)
Ma = 1.5
aL = np.sqrt(GAMMA)
rL, pL = 1.0, 1.0
uL = Ma * aL

# Post-shock state — Rankine-Hugoniot
rR = rL * (GAMMA+1)*Ma**2 / (GM1*Ma**2 + 2)
uR = uL * rL / rR
pR = pL * (2*GAMMA*Ma**2 - GM1) / (GAMMA+1)
aR = np.sqrt(GAMMA*pR/rR)
_log(f"Pre-shock:  rho={rL:.4f}, u={uL:.4f}, p={pL:.4f}, c={aL:.4f}, M={Ma}")
_log(f"Post-shock: rho={rR:.4f}, u={uR:.4f}, p={pR:.4f}, c={aR:.4f}, M={uR/aR:.4f}")

# Vortex parameters (Colera et al. Sec 3.8)
VORTEX_X0 = 0.25
VORTEX_Y0 = 0.5
VORTEX_R  = 0.175
VORTEX_A  = 0.075
VORTEX_VM = 0.9

# Time control
CFL = 0.25
T_END = 0.35
DT_OUTPUT = 0.025

# Sponge layer
SPONGE_X0 = 1.95
SPONGE_SIGMA_MAX = 30.0
SPONGE_BETA = 3.0

# =========================================================================
#  Grid (NumPy — for host-side ops)
# =========================================================================
xc = DOMAIN_X[0] + (np.arange(NX) + 0.5) * dx
yc = DOMAIN_Y[0] + (np.arange(NY) + 0.5) * dy
Xc, Yc = np.meshgrid(xc, yc)

# Sponge weight
sponge_mask = np.maximum(0.0, (xc - SPONGE_X0) / (DOMAIN_X[1] - SPONGE_X0))
sponge_weight = SPONGE_SIGMA_MAX * sponge_mask ** SPONGE_BETA
_sp_w = sponge_weight.reshape(1, 1, NX)  # for broadcasting

# Pre-compute sponge target constants (for Numba)
SPONGE_TARGET = np.array([rR, rR*uR, 0.0, pR*GM1_INV + 0.5*rR*uR*uR])

# Left boundary constants (for Numba)
LEFT_BC = np.array([rL, rL*uL, 0.0, pL*GM1_INV + 0.5*rL*uL*uL])


# =========================================================================
#  Numba-JIT core functions
# =========================================================================

# =========================================================================
#  WENO5 reconstruction helpers
# =========================================================================
@njit(cache=True, inline='always')
def wen5_left(f0, f1, f2, f3, f4):
    """WENO5-JS left-biased reconstruction."""
    eps = 1e-6
    v0 = (2.0*f0 - 7.0*f1 + 11.0*f2) / 6.0
    v1 = (-f1 + 5.0*f2 + 2.0*f3) / 6.0
    v2 = (2.0*f2 + 5.0*f3 - f4) / 6.0
    b0 = 13.0/12.0 * (f0 - 2.0*f1 + f2)**2 + 0.25 * (f0 - 4.0*f1 + 3.0*f2)**2
    b1 = 13.0/12.0 * (f1 - 2.0*f2 + f3)**2 + 0.25 * (f1 - f3)**2
    b2 = 13.0/12.0 * (f2 - 2.0*f3 + f4)**2 + 0.25 * (3.0*f2 - 4.0*f3 + f4)**2
    w0 = 0.1  / (eps + b0)**2
    w1 = 0.6  / (eps + b1)**2
    w2 = 0.3  / (eps + b2)**2
    w_sum = w0 + w1 + w2
    return (w0*v0 + w1*v1 + w2*v2) / w_sum


@njit(cache=True, inline='always')
def wen5_right(f0, f1, f2, f3, f4):
    """WENO5-JS right-biased reconstruction."""
    eps = 1e-6
    v0 = (2.0*f4 - 7.0*f3 + 11.0*f2) / 6.0
    v1 = (-f3 + 5.0*f2 + 2.0*f1) / 6.0
    v2 = (2.0*f2 + 5.0*f1 - f0) / 6.0
    b0 = 13.0/12.0 * (f4 - 2.0*f3 + f2)**2 + 0.25 * (f4 - 4.0*f3 + 3.0*f2)**2
    b1 = 13.0/12.0 * (f3 - 2.0*f2 + f1)**2 + 0.25 * (f3 - f1)**2
    b2 = 13.0/12.0 * (f2 - 2.0*f1 + f0)**2 + 0.25 * (3.0*f2 - 4.0*f1 + f0)**2
    w0 = 0.1  / (eps + b0)**2
    w1 = 0.6  / (eps + b1)**2
    w2 = 0.3  / (eps + b2)**2
    w_sum = w0 + w1 + w2
    return (w0*v0 + w1*v1 + w2*v2) / w_sum


@njit(cache=True)
def cons_to_prim_jit(U):
    """U = [rho, rho*u, rho*v, E] -> (rho, u, v, p)  in-place style"""
    ny, nx = U.shape[1], U.shape[2]
    rho = np.empty((ny, nx))
    u = np.empty((ny, nx))
    v = np.empty((ny, nx))
    p = np.empty((ny, nx))
    for j in range(ny):
        for i in range(nx):
            r = max(U[0,j,i], 1e-10)
            rho[j,i] = r
            u[j,i] = U[1,j,i] / r
            v[j,i] = U[2,j,i] / r
            ke = 0.5 * r * (u[j,i]*u[j,i] + v[j,i]*v[j,i])
            p[j,i] = max(GM1 * (U[3,j,i] - ke), 1e-10)
    return rho, u, v, p


@njit(cache=True)
def prim_to_cons_jit(rho, u, v, p):
    ny, nx = rho.shape[0], rho.shape[1]
    U = np.empty((4, ny, nx))
    for j in range(ny):
        for i in range(nx):
            U[0,j,i] = rho[j,i]
            U[1,j,i] = rho[j,i] * u[j,i]
            U[2,j,i] = rho[j,i] * v[j,i]
            U[3,j,i] = p[j,i] * GM1_INV + 0.5 * rho[j,i] * (u[j,i]*u[j,i] + v[j,i]*v[j,i])
    return U


@njit(cache=True, inline='always')
def mc_slope(a, b):
    """Scalar MC limiter slope: minmod(2a, 2b, (a+b)/2).

    Used for 2nd-order MUSCL reconstruction in the shock-tangential
    (Y) direction.  More dissipative than WENO5, which is exactly
    what is needed to suppress the carbuncle instability when a
    shock is grid-aligned.
    """
    if a * b <= 0.0:
        return 0.0
    two_a = 2.0 * a
    two_b = 2.0 * b
    avg = 0.5 * (a + b)
    # minmod of three same-sign values
    if abs(two_a) < abs(two_b):
        m = two_a if abs(two_a) < abs(avg) else avg
    else:
        m = two_b if abs(two_b) < abs(avg) else avg
    return m


@njit(cache=True)
def max_wave_speed_jit(U):
    """Returns (smax_x, smax_y)"""
    ny, nx = U.shape[1], U.shape[2]
    smax_x = 0.0
    smax_y = 0.0
    for j in range(ny):
        for i in range(nx):
            r = max(U[0,j,i], 1e-10)
            u = U[1,j,i] / r
            v = U[2,j,i] / r
            ke = 0.5 * r * (u*u + v*v)
            p = max(GM1 * (U[3,j,i] - ke), 1e-10)
            c = np.sqrt(GAMMA * p / r)
            ax = abs(u) + c
            ay = abs(v) + c
            if ax > smax_x:
                smax_x = ax
            if ay > smax_y:
                smax_y = ay
    return smax_x, smax_y


@njit(cache=True)
def euler_step_jit(U, dt_val):
    """One forward Euler step.
    X: WENO5 + shock-sensor -> 1st-order near shocks + HLL flux.
    Y: MUSCL-MC + HLL flux (2nd-order shock-tangential, dissipative
       enough to suppress the carbuncle instability for grid-aligned shocks).
    Boundary interfaces use piecewise-constant (1st-order).
    """
    ny, nx = U.shape[1], U.shape[2]

    # 1. Primitive variables
    rho = np.empty((ny, nx))
    u   = np.empty((ny, nx))
    v   = np.empty((ny, nx))
    p   = np.empty((ny, nx))
    for j in range(ny):
        for i in range(nx):
            r = max(U[0,j,i], 1e-10)
            rho[j,i] = r
            u[j,i]   = U[1,j,i] / r
            v[j,i]   = U[2,j,i] / r
            ke = 0.5 * r * (u[j,i]*u[j,i] + v[j,i]*v[j,i])
            p[j,i] = max(GM1 * (U[3,j,i] - ke), 1e-10)

    U_new = U.copy()
    dtdx = dt_val / dx
    dtdy = dt_val / dy

    # -------- X-fluxes: WENO5 + shock-sensor (interfaces i+1/2) --------
    for j in range(ny):
        for i in range(nx - 1):
            use_first = False
            if 2 <= i <= nx - 4:
                dp_rel = abs(p[j,i+1] - p[j,i]) / max(min(p[j,i+1], p[j,i]), 1e-10)
                if dp_rel > 0.05:
                    use_first = True

            if use_first:
                rL = rho[j,i]; rR = rho[j,i+1]
                uL =   u[j,i]; uR =   u[j,i+1]
                vL =   v[j,i]; vR =   v[j,i+1]
                pL =   p[j,i]; pR =   p[j,i+1]
            elif 2 <= i <= nx - 4:
                rL = wen5_left(rho[j,i-2], rho[j,i-1], rho[j,i], rho[j,i+1], rho[j,i+2])
                uL = wen5_left(  u[j,i-2],   u[j,i-1],   u[j,i],   u[j,i+1],   u[j,i+2])
                vL = wen5_left(  v[j,i-2],   v[j,i-1],   v[j,i],   v[j,i+1],   v[j,i+2])
                pL = wen5_left(  p[j,i-2],   p[j,i-1],   p[j,i],   p[j,i+1],   p[j,i+2])
                rR = wen5_right(rho[j,i-1], rho[j,i], rho[j,i+1], rho[j,i+2], rho[j,i+3])
                uR = wen5_right(  u[j,i-1],   u[j,i],   u[j,i+1],   u[j,i+2],   u[j,i+3])
                vR = wen5_right(  v[j,i-1],   v[j,i],   v[j,i+1],   v[j,i+2],   v[j,i+3])
                pR = wen5_right(  p[j,i-1],   p[j,i],   p[j,i+1],   p[j,i+2],   p[j,i+3])
            else:
                rL = rho[j,i]; rR = rho[j,i+1]
                uL =   u[j,i]; uR =   u[j,i+1]
                vL =   v[j,i]; vR =   v[j,i+1]
                pL =   p[j,i]; pR =   p[j,i+1]

            rL = max(rL, 1e-10); rR = max(rR, 1e-10)
            pL = max(pL, 1e-10); pR = max(pR, 1e-10)

            EL = pL*GM1_INV + 0.5*rL*(uL*uL+vL*vL)
            ER = pR*GM1_INV + 0.5*rR*(uR*uR+vR*vR)
            cL = np.sqrt(GAMMA*pL/rL); cR = np.sqrt(GAMMA*pR/rR)
            S_L = min(uL - cL, uR - cR)
            S_R = max(uL + cL, uR + cR)
            if S_L >= 0.0:
                F0 = rL*uL
                F1 = rL*uL*uL + pL
                F2 = rL*uL*vL
                F3 = uL*(EL+pL)
            elif S_R <= 0.0:
                F0 = rR*uR
                F1 = rR*uR*uR + pR
                F2 = rR*uR*vR
                F3 = uR*(ER+pR)
            else:
                FL0 = rL*uL; FR0 = rR*uR
                FL1 = rL*uL*uL + pL; FR1 = rR*uR*uR + pR
                FL2 = rL*uL*vL; FR2 = rR*uR*vR
                FL3 = uL*(EL+pL); FR3 = uR*(ER+pR)
                UR0 = rR; UL0 = rL
                UR1 = rR*uR; UL1 = rL*uL
                UR2 = rR*vR; UL2 = rL*vL
                UR3 = ER; UL3 = EL
                inv_dS = 1.0 / max(S_R - S_L, 1e-12)
                F0 = (S_R*FL0 - S_L*FR0 + S_L*S_R*(UR0-UL0)) * inv_dS
                F1 = (S_R*FL1 - S_L*FR1 + S_L*S_R*(UR1-UL1)) * inv_dS
                F2 = (S_R*FL2 - S_L*FR2 + S_L*S_R*(UR2-UL2)) * inv_dS
                F3 = (S_R*FL3 - S_L*FR3 + S_L*S_R*(UR3-UL3)) * inv_dS

            U_new[0,j,i] -= dtdx*F0; U_new[0,j,i+1] += dtdx*F0
            U_new[1,j,i] -= dtdx*F1; U_new[1,j,i+1] += dtdx*F1
            U_new[2,j,i] -= dtdx*F2; U_new[2,j,i+1] += dtdx*F2
            U_new[3,j,i] -= dtdx*F3; U_new[3,j,i+1] += dtdx*F3

    # -------- Y-fluxes: MUSCL-MC (interfaces j+1/2) --------
    for j in range(ny - 1):
        for i in range(nx):
            if 2 <= j <= ny - 4:
                sr_b = mc_slope(rho[j,i] - rho[j-1,i],
                                rho[j+1,i] - rho[j,i])
                su_b = mc_slope(u[j,i] - u[j-1,i],
                                u[j+1,i] - u[j,i])
                sv_b = mc_slope(v[j,i] - v[j-1,i],
                                v[j+1,i] - v[j,i])
                sp_b = mc_slope(p[j,i] - p[j-1,i],
                                p[j+1,i] - p[j,i])

                sr_t = mc_slope(rho[j+1,i] - rho[j,i],
                                rho[j+2,i] - rho[j+1,i])
                su_t = mc_slope(u[j+1,i] - u[j,i],
                                u[j+2,i] - u[j+1,i])
                sv_t = mc_slope(v[j+1,i] - v[j,i],
                                v[j+2,i] - v[j+1,i])
                sp_t = mc_slope(p[j+1,i] - p[j,i],
                                p[j+2,i] - p[j+1,i])

                rB = rho[j,i]   + 0.5 * sr_b
                uB = u[j,i]     + 0.5 * su_b
                vB = v[j,i]     + 0.5 * sv_b
                pB = p[j,i]     + 0.5 * sp_b

                rT = rho[j+1,i] - 0.5 * sr_t
                uT = u[j+1,i]   - 0.5 * su_t
                vT = v[j+1,i]   - 0.5 * sv_t
                pT = p[j+1,i]   - 0.5 * sp_t
            else:
                rB = rho[j,i]; rT = rho[j+1,i]
                uB =   u[j,i]; uT =   u[j+1,i]
                vB =   v[j,i]; vT =   v[j+1,i]
                pB =   p[j,i]; pT =   p[j+1,i]

            rB = max(rB, 1e-10); rT = max(rT, 1e-10)
            pB = max(pB, 1e-10); pT = max(pT, 1e-10)

            EB = pB*GM1_INV + 0.5*rB*(uB*uB+vB*vB)
            ET = pT*GM1_INV + 0.5*rT*(uT*uT+vT*vT)
            cB = np.sqrt(GAMMA*pB/rB); cT = np.sqrt(GAMMA*pT/rT)
            S_B = min(vB - cB, vT - cT)
            S_T = max(vB + cB, vT + cT)
            if S_B >= 0.0:
                G0 = rB*vB
                G1 = rB*uB*vB
                G2 = rB*vB*vB + pB
                G3 = vB*(EB+pB)
            elif S_T <= 0.0:
                G0 = rT*vT
                G1 = rT*uT*vT
                G2 = rT*vT*vT + pT
                G3 = vT*(ET+pT)
            else:
                GB0 = rB*vB; GT0 = rT*vT
                GB1 = rB*uB*vB; GT1 = rT*uT*vT
                GB2 = rB*vB*vB + pB; GT2 = rT*vT*vT + pT
                GB3 = vB*(EB+pB); GT3 = vT*(ET+pT)
                UB0 = rB; UT0 = rT
                UB1 = rB*uB; UT1 = rT*uT
                UB2 = rB*vB; UT2 = rT*vT
                UB3 = EB; UT3 = ET
                inv_dS_y = 1.0 / max(S_T - S_B, 1e-12)
                G0 = (S_T*GB0 - S_B*GT0 + S_B*S_T*(UT0-UB0)) * inv_dS_y
                G1 = (S_T*GB1 - S_B*GT1 + S_B*S_T*(UT1-UB1)) * inv_dS_y
                G2 = (S_T*GB2 - S_B*GT2 + S_B*S_T*(UT2-UB2)) * inv_dS_y
                G3 = (S_T*GB3 - S_B*GT3 + S_B*S_T*(UT3-UB3)) * inv_dS_y

            U_new[0,j,i] -= dtdy*G0; U_new[0,j+1,i] += dtdy*G0
            U_new[1,j,i] -= dtdy*G1; U_new[1,j+1,i] += dtdy*G1
            U_new[2,j,i] -= dtdy*G2; U_new[2,j+1,i] += dtdy*G2
            U_new[3,j,i] -= dtdy*G3; U_new[3,j+1,i] += dtdy*G3

    # ---- 4th-order Y-direction carbuncle hyperviscosity ----
    # 4th-order derivative selectively damps grid-scale oscillations
    # (λ ~ 2-4 dy, i.e., the carbuncle) while leaving the vortex
    # (λ ~ 25 dy) essentially unaffected.  Scale selectivity is
    # (λ_vortex / λ_carbuncle)^4 ≈ 3000×.
    # Stability: C4 * c * dt / dy ≤ 1/8 → C4 ≤ ~1.4 at our resolution.
    C4 = 0.5
    for i in range(nx):
        for j in range(2, ny - 2):
            c_local = np.sqrt(GAMMA * max(p[j,i], 1e-10) / max(rho[j,i], 1e-10))
            damp4 = C4 * c_local * dt_val / dy
            for k in range(4):
                d4 = U[k,j+2,i] - 4.0*U[k,j+1,i] + 6.0*U[k,j,i] - 4.0*U[k,j-1,i] + U[k,j-2,i]
                U_new[k,j,i] -= damp4 * d4

    return U_new


@njit(cache=True)
def apply_bc_jit(U):
    """Apply boundary conditions in place."""
    ny, nx = U.shape[1], U.shape[2]

    # Left boundary: supersonic inflow
    for j in range(ny):
        for k in range(4):
            U[k,j,0] = LEFT_BC[k]

    # Right boundary: extrapolate
    for j in range(ny):
        for k in range(4):
            U[k,j,nx-1] = U[k,j,nx-2]

    # Top boundary: reflective
    for i in range(nx):
        for k in range(4):
            U[k,ny-1,i] = U[k,ny-2,i]
        U[2,ny-1,i] = -U[2,ny-2,i]

    # Bottom boundary: reflective
    for i in range(nx):
        for k in range(4):
            U[k,0,i] = U[k,1,i]
        U[2,0,i] = -U[2,1,i]

    return U


@njit(cache=True)
def apply_sponge_jit(U, dt_val, sponge_w):
    """Apply sponge damping in place."""
    ny, nx = U.shape[1], U.shape[2]
    for j in range(ny):
        for i in range(nx):
            sw = sponge_w.ravel()[i]
            if sw > 0.0:
                damp = dt_val * sw
                for k in range(4):
                    U[k,j,i] -= damp * (U[k,j,i] - SPONGE_TARGET[k])
    return U


# =========================================================================
#  Initial condition (NumPy — vectorized)
# =========================================================================
def init_shock_vortex():
    post = Xc >= SHOCK_X0

    rho_0 = np.where(post, rR, rL)
    u_0   = np.where(post, uR, uL)
    v_0   = np.zeros((NY, NX))
    p_0   = np.where(post, pR, pL)

    # --- Colera et al. Sec 3.8: piecewise v_theta + energy integral ---
    r = np.sqrt((Xc - VORTEX_X0)**2 + (Yc - VORTEX_Y0)**2)
    mask_pre = Xc < SHOCK_X0   # vortex only upstream of the shock

    vm = VORTEX_VM * aL                       # peak tangential speed = 0.9 * c_inf
    a = VORTEX_A
    b = VORTEX_R

    # tangential velocity v_theta(r), piecewise
    v_theta = np.zeros_like(r)
    # inner region r <= a: linear growth
    r_le_a = r <= a
    v_theta[r_le_a] = vm * (r[r_le_a] / a)
    # outer region a < r < b: exponential decay
    r_gt_a_lt_b = (r > a) & (r < b)
    v_theta[r_gt_a_lt_b] = vm * np.exp(-((r[r_gt_a_lt_b] - a)**2) / (b**2))

    # convert to Cartesian u, v components
    safe_r = np.maximum(r, 1e-10)
    theta = np.arctan2(Yc - VORTEX_Y0, Xc - VORTEX_X0)
    du_v = -v_theta * np.sin(theta)
    dv_v =  v_theta * np.cos(theta)

    # energy integral (Colera et al.): e = e_inf - (1/gamma) * integral
    # of v_theta^2/r from r to b; e_inf is the upstream INTERNAL energy.
    # Precomputed radial table + cumulative sum, fully vectorized.
    e_internal_inf = pL * GM1_INV   # = p/(gamma-1) = 2.5 (rL=1)

    n_fine = 5000
    r_fine = np.linspace(0, b, n_fine)
    integrand_vals = np.zeros(n_fine)
    # inner region: v_theta = vm * r/a  ->  v_theta^2/r = vm^2 * r / a^2
    m_in = r_fine <= a
    integrand_vals[m_in] = (vm * r_fine[m_in] / a)**2 / np.maximum(r_fine[m_in], 1e-12)
    # outer region: v_theta = vm * exp(-(r-a)^2/b^2)
    m_out = (r_fine > a) & (r_fine < b)
    integrand_vals[m_out] = (vm * np.exp(-(r_fine[m_out] - a)**2 / b**2))**2 / np.maximum(r_fine[m_out], 1e-12)

    # cumulative integral; integral from r to b = total - cum
    cum_int = np.cumsum(integrand_vals) * (b / n_fine)  # midpoint rule
    total_int = cum_int[-1]
    int_from_r_to_b = total_int - cum_int
    delta_e_grid = int_from_r_to_b / GAMMA

    r_flat = r.ravel()
    delta_e = np.interp(r_flat, r_fine, delta_e_grid, right=0.0).reshape(r.shape)

    # temperature scaling: T = e / e_inf = 1 - delta_e / e_inf
    T_v = 1.0 - delta_e / e_internal_inf
    T_v = np.maximum(T_v, 0.01)

    # applied upstream of the shock only
    u_0[mask_pre] += du_v[mask_pre]
    v_0[mask_pre] += dv_v[mask_pre]
    rho_0[mask_pre] = rL * T_v[mask_pre]**(1.0/GM1)
    p_0[mask_pre]   = pL * T_v[mask_pre]**(GAMMA/GM1)

    rho_0 = np.maximum(rho_0, 1e-5)
    p_0   = np.maximum(p_0,   1e-5)

    return prim_to_cons_jit(rho_0.astype(np.float64),
                            u_0.astype(np.float64),
                            v_0.astype(np.float64),
                            p_0.astype(np.float64))


# =========================================================================
#  Main time loop
# =========================================================================
CKPT_PATH = os.path.join(OUTPUT_DIR, "shock_vortex_cfd_checkpoint_v2.npz")
CKPT_TMP  = CKPT_PATH + ".tmp"
CACHE_PATH = os.path.join(OUTPUT_DIR, "shock_vortex_cfd_cache.npz")

def _save_checkpoint(**kwargs):
    """Atomic checkpoint save to avoid corruption on interrupt."""
    try:
        np.savez_compressed(CKPT_TMP, **kwargs)
        if os.path.exists(CKPT_PATH):
            os.remove(CKPT_PATH)
        os.rename(CKPT_TMP, CKPT_PATH)
    except Exception as e:
        _log(f"  [WARN] Checkpoint save failed: {e}")

def run_cfd():
    _log(f"\nStarting shock-vortex CFD (Numba-JIT WENO5+shock-sensor/MUSCL-MC, SSP-RK3, {NX}x{NY})")
    _log(f"  Sponge x0={SPONGE_X0},  CFL={CFL},  t_end={T_END}")

    # ---- Checkpoint resume ----
    if os.path.exists(CKPT_PATH):
        _log("  Resuming from checkpoint ...")
        ckpt = np.load(CKPT_PATH, allow_pickle=True)
        U = ckpt["U"]
        t = float(ckpt["t"])
        step = int(ckpt["step"])
        snapshots = list(ckpt["snapshots"])
        snap_times = list(ckpt["snap_times"])
        next_snap = float(ckpt["next_snap"])
        _log(f"  Resumed at t={t:.4f} step={step}, {len(snapshots)} snapshots")
    else:
        U = init_shock_vortex()
        U = apply_bc_jit(U)
        t = 0.0
        step = 0
        snapshots = []
        snap_times = []
        next_snap = 0.0

    # Pre-compile JIT functions
    sw_arr = _sp_w.astype(np.float64)
    if step == 0:
        _log("  (JIT will compile on first step...)")

    # Checkpoint timer
    import time as _t
    t_ckpt = _t.time()

    while t < T_END - 1e-12:
        smax_x, smax_y = max_wave_speed_jit(U)
        dt_cfl = CFL * min(dx / max(smax_x, 1e-10), dy / max(smax_y, 1e-10))
        if t + dt_cfl > T_END:
            dt_cfl = T_END - t

        # SSP-RK3: three-stage strong-stability-preserving Runge-Kutta
        U0 = U.copy()
        U1 = euler_step_jit(U0, dt_cfl)
        U1 = apply_sponge_jit(U1, dt_cfl, sw_arr)
        U1 = apply_bc_jit(U1)
        U2 = euler_step_jit(U1, dt_cfl)
        U2 = apply_sponge_jit(U2, dt_cfl, sw_arr)
        U2 = apply_bc_jit(U2)
        U2 = 0.75 * U0 + 0.25 * U2
        U = euler_step_jit(U2, dt_cfl)
        U = apply_sponge_jit(U, dt_cfl, sw_arr)
        U = apply_bc_jit(U)
        U = (1.0 / 3.0) * U0 + (2.0 / 3.0) * U
        t += dt_cfl
        step += 1

        # Snapshot
        if t >= next_snap - 1e-9:
            rho_snap = U[0].copy()
            snapshots.append(rho_snap)
            snap_times.append(t)
            pct = t / T_END * 100
            rmin, rmax = rho_snap.min(), rho_snap.max()
            _log(f"  t={t:.4f} ({pct:.0f}%) step={step} "
                  f"rho=[{rmin:.4f},{rmax:.4f}] dt={dt_cfl:.5e}")
            next_snap += DT_OUTPUT

            # Save checkpoint after each snapshot
            _save_checkpoint(U=U, t=t, step=step,
                             snapshots=np.array(snapshots, dtype=object),
                             snap_times=np.array(snap_times, dtype=object),
                             next_snap=next_snap)
            t_ckpt = _t.time()

        if step % 10 == 0 or _t.time() - t_ckpt > 5:
            # Periodic checkpoint
            rho_c = U[0]
            _log(f"  t={t:.4f} ({t/T_END*100:.0f}%) step={step} "
                  f"rho=[{rho_c.min():.4f},{rho_c.max():.4f}] dt={dt_cfl:.5e}")
            _save_checkpoint(U=U, t=t, step=step,
                             snapshots=np.array(snapshots, dtype=object),
                             snap_times=np.array(snap_times, dtype=object),
                             next_snap=next_snap)
            t_ckpt = _t.time()

    rho_c = U[0]
    _log(f"\nCFD complete: {step} steps, t={t:.6f}")
    _log(f"  Final rho range: [{rho_c.min():.4f}, {rho_c.max():.4f}]")

    return rho_c, snapshots, snap_times


# =========================================================================
#  Main
# =========================================================================
if __name__ == "__main__":
    import time as _time
    t_start = _time.time()

    result = run_cfd()

    if result is not None:
        rho_final, snapshots, snap_times = result

        cache_path = os.path.join(OUTPUT_DIR, "shock_vortex_cfd_cache.npz")
        _log(f"\nSaving final density to: {cache_path}")
        np.savez_compressed(cache_path,
                            rho=rho_final,
                            snapshots=np.array(snapshots),
                            snap_times=np.array(snap_times),
                            nx=NX, ny=NY,
                            Ma=Ma, Rv=VORTEX_R, A=VORTEX_A, Vm=VORTEX_VM,
                            xv=VORTEX_X0, yv=VORTEX_Y0)

        # Clean up checkpoint
        try:
            if os.path.exists(CKPT_PATH):
                os.remove(CKPT_PATH)
        except Exception:
            pass

        elapsed = _time.time() - t_start
        _log(f"  Elapsed: {elapsed:.1f}s")

        # Diagnostic plot
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(2, 3, figsize=(15, 8))
        plot_indices = [0, len(snapshots)//4, len(snapshots)//2,
                        3*len(snapshots)//4, -1]
        for idx, si in enumerate(plot_indices[:5]):
            ax = axes.flat[idx]
            im = ax.imshow(snapshots[si].astype(np.float64), origin='lower',
                           extent=[DOMAIN_X[0], DOMAIN_X[1], DOMAIN_Y[0], DOMAIN_Y[1]],
                           cmap='turbo', vmin=1.0, vmax=2.0)
            ax.set_title(f"t = {snap_times[si]:.3f}")
            ax.set_aspect("equal")
            cbar = plt.colorbar(im, ax=ax)
            cbar.set_ticks([1.00, 1.33, 1.66, 2.00])
        axes.flat[-1].axis("off")
        fig.tight_layout()
        fig.savefig(os.path.join(OUTPUT_DIR, "_cfd_snapshots.png"), dpi=150)
        plt.close(fig)
        _log(f"  Snapshot diagnostic saved: _cfd_snapshots.png")
    else:
        _log("CFD FAILED.")
