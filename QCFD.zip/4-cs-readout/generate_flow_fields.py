"""
Generate classical flow fields for the quantum flow-field reconstruction project.

Case I:  Lid-driven cavity (vorticity-streamfunction CFD solver)
Case II: Shock-vortex interaction (LxF CFD + Ribner linear theory)

Saves cache files in the same directory:
  - cavity_cache.npz           : u, v, psi fields
  - shock_vortex_cfd_cache.npz : rho density field

Usage:
  python generate_flow_fields.py --case I   --res 512   # cavity only
  python generate_flow_fields.py --case II  --res 512   # shock-vortex only
  python generate_flow_fields.py --case both --res 512  # both

The CFD solver for Case I solves on a 129x129 grid and upsamples to the
target resolution (stable convergence).  Case II uses a 160x80 LxF solver
internally and constructs the final field at the target resolution.

Run this script ONCE to generate cache files, then use
quantum_reconstruction.py for all subsequent experiments.
"""

import numpy as np
import os

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))


# =========================================================================
#  Case I: Lid-driven cavity flow via CFD solver
# =========================================================================
def solve_cavity_ns(nx=129, ny=129, Re=1000, max_iter=120000, tol=1e-6):
    """
    Solve 2D lid-driven cavity flow using the vorticity-streamfunction
    formulation.  Poisson equation  ∇²ψ = -ω  is solved directly via
    the discrete sine transform (DST), which is exact for Dirichlet BCs.
    """
    from scipy.fft import dst, idst

    dx = 1.0 / (nx - 1)
    dy = 1.0 / (ny - 1)
    dx2 = dx * dx
    dy2 = dy * dy
    h_min = min(dx, dy)
    h2_min = min(dx2, dy2)

    mx = np.arange(1, nx - 1)
    my = np.arange(1, ny - 1)
    ev_x = (4.0 / dx2) * np.sin(0.5 * np.pi * mx / (nx - 1))**2
    ev_y = (4.0 / dy2) * np.sin(0.5 * np.pi * my / (ny - 1))**2
    denom = np.add.outer(ev_y, ev_x)

    psi   = np.zeros((ny, nx))
    omega = np.zeros((ny, nx))
    u = np.zeros((ny, nx))
    v = np.zeros((ny, nx))

    cfl_diff = 0.3
    dt_diff  = cfl_diff * h2_min * Re
    dt_conv  = 0.3 * h_min
    dt = min(dt_diff, dt_conv)

    ramp_end = 2000
    check_interval = 500
    max_change = 1.0

    print(f"\n  Grid: {nx}x{ny}, Re={Re}, dx={dx:.4e}, dt={dt:.6e}")
    print(f"  Poisson solver: DST (direct)")
    print(f"  Starting time-marching (lid ramped over {ramp_end} iters)...")

    for it in range(max_iter):
        if it < ramp_end:
            lid_speed = 0.5 * (1.0 - np.cos(np.pi * it / ramp_end))
        else:
            lid_speed = 1.0

        # (a) Poisson: ∇²ψ = -ω  via DST (exact)
        omega_interior = omega[1:-1, 1:-1]
        omega_dst = dst(dst(omega_interior, type=1, axis=1), type=1, axis=0)
        psi_dst = omega_dst / (denom + 1e-15)
        psi_interior = idst(idst(psi_dst, type=1, axis=0), type=1, axis=1)
        psi[1:-1, 1:-1] = psi_interior

        # (b) Velocity
        u[1:-1, 1:-1] =  (psi[2:, 1:-1] - psi[:-2, 1:-1]) / (2.0 * dy)
        v[1:-1, 1:-1] = -(psi[1:-1, 2:] - psi[1:-1, :-2]) / (2.0 * dx)
        u[0, :] = lid_speed; v[0, :] = 0.0
        u[-1, :] = 0.0; v[-1, :] = 0.0
        u[:,  0] = 0.0; v[:,  0] = 0.0
        u[:, -1] = 0.0; v[:, -1] = 0.0

        # (c) Vorticity BCs (Thom's formula)
        omega[-1, 1:-1] = -2.0 * psi[-2, 1:-1] / dy2
        omega[0,  1:-1] = -2.0 * psi[1,  1:-1] / dy2 - 2.0 * lid_speed / dy
        omega[1:-1,  0] = -2.0 * psi[1:-1,  1] / dx2
        omega[1:-1, -1] = -2.0 * psi[1:-1, -2] / dx2

        # (d) Interior vorticity — upwind convection + central diffusion
        u_int = u[1:-1, 1:-1]
        v_int = v[1:-1, 1:-1]
        w_int = omega[1:-1, 1:-1]
        w_left  = omega[1:-1, :-2]
        w_right = omega[1:-1, 2:]
        w_down  = omega[:-2, 1:-1]
        w_up    = omega[2:, 1:-1]

        u_pos = np.maximum(u_int, 0); u_neg = np.minimum(u_int, 0)
        v_pos = np.maximum(v_int, 0); v_neg = np.minimum(v_int, 0)

        dwdx = u_pos * (w_int - w_left) / dx + u_neg * (w_right - w_int) / dx
        dwdy = v_pos * (w_int - w_down) / dy + v_neg * (w_up   - w_int) / dy
        conv = dwdx + dwdy

        d2wdx2 = (omega[1:-1, 2:] - 2.0*w_int + omega[1:-1, :-2]) / dx2
        d2wdy2 = (omega[2:, 1:-1] - 2.0*w_int + omega[:-2, 1:-1]) / dy2
        diff = (1.0 / Re) * (d2wdx2 + d2wdy2)

        omega_new_interior = omega[1:-1, 1:-1] + dt * (-conv + diff)

        if it > 0:
            max_change = np.max(np.abs(omega_new_interior - omega[1:-1, 1:-1]))
        omega[1:-1, 1:-1] = omega_new_interior

        if not np.all(np.isfinite(omega)):
            raise RuntimeError(f"CFD solver diverged (NaN/Inf) at iter {it}. "
                               f"max|Δω| = {max_change:.4e}")

        if it % check_interval == 0:
            if it >= ramp_end:
                print(f"  iter {it:6d}  max|Δω| = {max_change:.4e}  dt = {dt:.4e}", flush=True)
                if max_change < tol:
                    print(f"  Converged at iteration {it}  (tol = {tol})")
                    break
            else:
                print(f"  iter {it:6d}  (ramping lid, speed={lid_speed:.3f})  dt = {dt:.4e}", flush=True)

    u[1:-1, 1:-1] =  (psi[2:, 1:-1] - psi[:-2, 1:-1]) / (2.0 * dy)
    v[1:-1, 1:-1] = -(psi[1:-1, 2:] - psi[1:-1, :-2]) / (2.0 * dx)
    u[0, :] = 1.0

    return u, v, psi, omega


def generate_cavity(nx=512, ny=512, force=False):
    """Generate lid-driven cavity flow at target resolution.

    Solves CFD on 129x129 grid (stable), upsamples to (nx, ny), saves cache.
    Set force=True to overwrite existing cache.
    """
    from scipy.ndimage import zoom

    cache_path = os.path.join(OUTPUT_DIR, "cavity_cache.npz")

    if os.path.exists(cache_path) and not force:
        print(f"\nCavity cache already exists: {cache_path}")
        data = np.load(cache_path)
        cached_shape = data["u"].shape
        if cached_shape == (ny, nx):
            print(f"  Resolution matches ({nx}x{ny}) — nothing to do.")
            return cached_shape
        else:
            print(f"  Resolution mismatch: cache={cached_shape}, target=({ny},{nx}). "
                  f"Use --force to regenerate.")
            return cached_shape

    cfd_nx = cfd_ny = 129
    print(f"\nSolving CFD on {cfd_nx}x{cfd_ny} grid (stable), upsampling to {nx}x{ny}...")

    u_cfd, v_cfd, psi_cfd, omega_cfd = solve_cavity_ns(nx=cfd_nx, ny=cfd_ny, Re=1000)

    zoom_factor = (ny / cfd_ny, nx / cfd_nx)
    u_up = zoom(u_cfd, zoom_factor, order=3)
    v_up = zoom(v_cfd, zoom_factor, order=3)
    psi_up = zoom(psi_cfd, zoom_factor, order=3)

    # Flip vertically: lid (originally at y=0) -> top (y=1)
    u_up = u_up[::-1, :]
    v_up = -v_up[::-1, :]
    psi_up = psi_up[::-1, :]

    print(f"\nSaving cavity flow to cache: {cache_path}")
    print(f"  Shape: u={u_up.shape}, v={v_up.shape}, psi={psi_up.shape}")
    np.savez_compressed(cache_path, u=u_up, v=v_up, psi=psi_up)

    return (ny, nx)


# =========================================================================
#  Case II: Shock-vortex interaction — real CFD (Rusanov + MUSCL + char BC)
# =========================================================================
def generate_shock_vortex(nx=512, ny=512, force=False):
    """Generate shock-vortex interaction density field via real CFD.

    Runs a full 2D Euler solver (Rusanov flux + MUSCL reconstruction +
    characteristic boundary conditions) on a 400x200 grid, then upsamples
    to the target resolution.  The solver captures:
      - Vortex advection toward the shock
      - Shock deformation during interaction
      - Post-shock vortex compression
      - Cylindrical acoustic wave radiation

    Set force=True to overwrite existing cache.
    """
    import time as _time
    from scipy.ndimage import zoom
    import sys
    sys.path.insert(0, OUTPUT_DIR)

    cache_path = os.path.join(OUTPUT_DIR, "shock_vortex_cfd_cache.npz")

    if os.path.exists(cache_path) and not force:
        print(f"\nShock-vortex cache already exists: {cache_path}")
        data = np.load(cache_path)
        cached_shape = data["rho"].shape
        if cached_shape == (ny, nx):
            print(f"  Resolution matches ({nx}x{ny}) — nothing to do.")
            return cached_shape
        else:
            print(f"  Resolution mismatch: cache={cached_shape}, target=({ny},{nx}). "
                  f"Use --force to regenerate.")
            return cached_shape

    # ---- Run CFD on 400x200 grid ----
    from cfd_shock_vortex import run_cfd as _run_cfd
    print(f"\nShock-vortex (real CFD: Rusanov+MUSCL+char BC, 400x200, output={nx}x{ny})")
    t_start = _time.time()
    result = _run_cfd()
    if result is None:
        raise RuntimeError("CFD solver failed!")
    rho_cfd, snapshots, snap_times = result
    elapsed = _time.time() - t_start
    print(f"  CFD elapsed: {elapsed:.1f}s")

    # ---- Upsample to target resolution ----
    if rho_cfd.shape != (ny, nx):
        zf = (ny / rho_cfd.shape[0], nx / rho_cfd.shape[1])
        rho_final = zoom(rho_cfd, zf, order=3)
        print(f"  Upsampled: {rho_cfd.shape} -> {rho_final.shape}")
    else:
        rho_final = rho_cfd

    # ---- Cache ----
    np.savez_compressed(cache_path, rho=rho_final,
                        snapshots=np.array(snapshots),
                        snap_times=np.array(snap_times),
                        cfd_nx=rho_cfd.shape[1], cfd_ny=rho_cfd.shape[0],
                        Ma=1.2, eps=0.3, Rv=0.08, xv=0.5, yv=0.5)
    print(f"  Cached: {cache_path}")

    return (ny, nx)


# =========================================================================
#  CLI
# =========================================================================
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(
        description="Generate classical flow fields (CFD) and save to cache files.")
    parser.add_argument("--res", type=int, default=512,
                        help="Target grid resolution (default: 512)")
    parser.add_argument("--case", type=str, default="both",
                        choices=["I", "II", "both"],
                        help="Which case to generate: I (cavity), II (shock-vortex), both")
    parser.add_argument("--force", action="store_true",
                        help="Force regeneration even if cache exists")
    args = parser.parse_args()
    nx = args.res
    ny_cavity = nx          # square domain [0,1]x[0,1]
    ny_shock = max(1, nx//2)  # rectangular domain [0,2]x[0,1]

    print("="*60)
    print("FLOW FIELD GENERATOR")
    print(f"Target resolution: {nx} x {ny_cavity} (Case I) / {nx} x {ny_shock} (Case II)")
    print("="*60)

    if args.case in ("I", "both"):
        print("\n" + "="*60)
        print("Case I: Lid-driven cavity (Re=1000)")
        print("="*60)
        generate_cavity(nx=nx, ny=ny_cavity, force=args.force)

    if args.case in ("II", "both"):
        print("\n" + "="*60)
        print("Case II: Shock-vortex interaction (Ma=1.2)")
        print("="*60)
        generate_shock_vortex(nx=nx, ny=ny_shock, force=args.force)

    print("\nDone. Cache files saved to:", OUTPUT_DIR)
